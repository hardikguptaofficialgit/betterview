import{t as T}from"./chunk-JWPE2WC7-CE3kxLOT.js";import{o as z}from"./mermaid.core-ViSSZdte.js";import{i as y}from"./chunk-6MUBBAK2-BwUbZX6t.js";import{C as E,H as F,U as P,_ as A,a as W,c as _,f as N,q as L,v as M,y as Y}from"./chunk-BG4553SI-Bl7WJsPm.js";import{n as B}from"./d3-selection-Cu0USziQ.js";import{n as k}from"./chunk-Y2CYZVJY-CrVYBJys.js";import{n as H}from"./mermaid-parser.core-C-Rz0q2j.js";var v,I=N.packet,C=(v=class{constructor(){this.packet=[],this.setAccTitle=P,this.getAccTitle=M,this.setDiagramTitle=L,this.getDiagramTitle=E,this.getAccDescription=A,this.setAccDescription=F}getConfig(){const t=y({...I,...Y().packet});return t.showBits&&(t.paddingY+=10),t}getPacket(){return this.packet}pushWord(t){t.length>0&&this.packet.push(t)}clear(){W(),this.packet=[]}},k(v,"PacketDB"),v),O=1e4,U=k((t,e)=>{T(t,e);let r=-1,s=[],i=1;const{bitsPerRow:l}=e.getConfig();for(let{start:a,end:o,bits:c,label:g}of t.blocks){if(a!==void 0&&o!==void 0&&o<a)throw new Error(`Packet block ${a} - ${o} is invalid. End must be greater than start.`);if(a??(a=r+1),a!==r+1)throw new Error(`Packet block ${a} - ${o??a} is not contiguous. It should start from ${r+1}.`);if(c===0)throw new Error(`Packet block ${a} is invalid. Cannot have a zero bit field.`);for(o??(o=a+(c??1)-1),c??(c=o-a+1),r=o,B.debug(`Packet block ${a} - ${r} with label ${g}`);s.length<=l+1&&e.getPacket().length<O;){const[d,p]=j({start:a,end:o,bits:c,label:g},i,l);if(s.push(d),d.end+1===i*l&&(e.pushWord(s),s=[],i++),!p)break;({start:a,end:o,bits:c,label:g}=p)}}e.pushWord(s)},"populate"),j=k((t,e,r)=>{if(t.start===void 0)throw new Error("start should have been set during first phase");if(t.end===void 0)throw new Error("end should have been set during first phase");if(t.start>t.end)throw new Error(`Block start ${t.start} is greater than block end ${t.end}.`);if(t.end+1<=e*r)return[t,void 0];const s=e*r-1,i=e*r;return[{start:t.start,end:s,label:t.label,bits:s-t.start},{start:i,end:t.end,label:t.label,bits:t.end-i}]},"getNextFittingBlock"),$={parser:{yy:void 0},parse:k(async t=>{const e=await H("packet",t),r=$.parser?.yy;if(!(r instanceof C))throw new Error("parser.parser?.yy was not a PacketDB. This is due to a bug within Mermaid, please report this issue at https://github.com/mermaid-js/mermaid/issues.");B.debug(e),U(e,r)},"parse")},q=k((t,e,r,s)=>{const i=s.db,l=i.getConfig(),{rowHeight:a,paddingY:o,bitWidth:c,bitsPerRow:g}=l,d=i.getPacket(),p=i.getDiagramTitle(),u=a+o,n=u*(d.length+1)-(p?0:a),h=c*g+2,f=z(e);f.attr("viewBox",`0 0 ${h} ${n}`),_(f,n,h,l.useMaxWidth);for(const[m,b]of d.entries())G(f,b,m,l);f.append("text").text(p).attr("x",h/2).attr("y",n-u/2).attr("dominant-baseline","middle").attr("text-anchor","middle").attr("class","packetTitle")},"draw"),G=k((t,e,r,{rowHeight:s,paddingX:i,paddingY:l,bitWidth:a,bitsPerRow:o,showBits:c,bitOrder:g})=>{const d=t.append("g"),p=r*(s+l)+l,u=g==="descending";for(const n of e){const h=n.end-n.start+1,f=n.start%o,m=(u?o-f-h:f)*a+1,b=h*a-i;if(d.append("rect").attr("x",m).attr("y",p).attr("width",b).attr("height",s).attr("class","packetBlock"),d.append("text").attr("x",m+b/2).attr("y",p+s/2).attr("class","packetLabel").attr("dominant-baseline","middle").attr("text-anchor","middle").text(n.label),!c)continue;const[S,D]=u?[n.end,n.start]:[n.start,n.end],w=h===1,x=p-2;d.append("text").attr("x",m+(w?b/2:0)).attr("y",x).attr("class","packetByte start").attr("dominant-baseline","auto").attr("text-anchor",w?"middle":"start").text(S),w||d.append("text").attr("x",m+b).attr("y",x).attr("class","packetByte end").attr("dominant-baseline","auto").attr("text-anchor","end").text(D)}},"drawWord"),K={draw:q},X={byteFontSize:"10px",startByteColor:"black",endByteColor:"black",labelColor:"black",labelFontSize:"12px",titleColor:"black",titleFontSize:"14px",blockStrokeColor:"black",blockStrokeWidth:"1",blockFillColor:"#efefef"},at={parser:$,get db(){return new C},renderer:K,styles:k(({packet:t}={})=>{const e=y(X,t);return`
	.packetByte {
		font-size: ${e.byteFontSize};
	}
	.packetByte.start {
		fill: ${e.startByteColor};
	}
	.packetByte.end {
		fill: ${e.endByteColor};
	}
	.packetLabel {
		fill: ${e.labelColor};
		font-size: ${e.labelFontSize};
	}
	.packetTitle {
		fill: ${e.titleColor};
		font-size: ${e.titleFontSize};
	}
	.packetBlock {
		stroke: ${e.blockStrokeColor};
		stroke-width: ${e.blockStrokeWidth};
		fill: ${e.blockFillColor};
	}
	`},"styles")};export{at as diagram};
