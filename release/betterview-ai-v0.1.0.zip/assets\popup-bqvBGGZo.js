(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))s(r);new MutationObserver(r=>{for(const l of r)if(l.type==="childList")for(const c of l.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&s(c)}).observe(document,{childList:!0,subtree:!0});function a(r){const l={};return r.integrity&&(l.integrity=r.integrity),r.referrerPolicy&&(l.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?l.credentials="include":r.crossOrigin==="anonymous"?l.credentials="omit":l.credentials="same-origin",l}function s(r){if(r.ep)return;r.ep=!0;const l=a(r);fetch(r.href,l)}})();var g={renderEnabled:!0,autoInject:!1,theme:"auto",watermark:!0};function We(){return new Promise(n=>{if(typeof chrome>"u"||!chrome.storage||!chrome.storage.sync){n({...g});return}chrome.storage.sync.get({...g},t=>{if(chrome.runtime?.lastError){n({...g});return}n({renderEnabled:typeof t.renderEnabled=="boolean"?t.renderEnabled:g.renderEnabled,autoInject:typeof t.autoInject=="boolean"?t.autoInject:g.autoInject,theme:t.theme==="light"||t.theme==="dark"||t.theme==="auto"?t.theme:g.theme,watermark:typeof t.watermark=="boolean"?t.watermark:g.watermark})})})}function E(n){return new Promise((t,a)=>{if(typeof chrome>"u"||!chrome.storage||!chrome.storage.sync){t();return}chrome.storage.sync.set(n,()=>{chrome.runtime?.lastError?a(chrome.runtime.lastError):t()})})}function en(n){if(typeof chrome>"u"||!chrome.storage||!chrome.storage.onChanged)return()=>{};const t=(a,s)=>{s==="sync"&&We().then(n).catch(()=>{})};return chrome.storage.onChanged.addListener(t),()=>{chrome.storage.onChanged.removeListener(t)}}var Ye=[{type:"tree",required:["type","root"],whenToUse:"Hierarchies, mind maps, org charts",schemaSnippet:'{"type":"tree","layout":"vertical","root":{"id":"r","label":"Root","children":[{"id":"a","label":"Branch"}]}}'},{type:"flow",required:["type","nodes","edges"],whenToUse:"Process flows or architecture",schemaSnippet:'{"type":"flow","title":"...","nodes":[{"id":"a","label":"User"},{"id":"b","label":"API server"}],"edges":[{"from":"a","to":"b","label":"Request"}]}'},{type:"stepper",required:["type","steps"],whenToUse:"Sequential steps or tutorials",schemaSnippet:'{"type":"stepper","title":"...","steps":[{"title":"...","detail":"..."}]}'},{type:"table",required:["type","columns","rows"],whenToUse:"Tabular data or metrics",schemaSnippet:'{"type":"table","title":"...","columns":["Metric","Value"],"rows":[["A","100"]]}'},{type:"compare",required:["type","items"],whenToUse:"Side-by-side trade-offs",schemaSnippet:'{"type":"compare","title":"...","items":[{"label":"SQL","tone":"good","points":["..."]}]}'},{type:"quiz",required:["type","questions"],whenToUse:"Multiple-choice checks",schemaSnippet:'{"type":"quiz","title":"...","questions":[{"q":"...","options":["A","B"],"answer":0,"explain":"..."}]}'},{type:"chart",required:["type","chartType","labels","datasets"],whenToUse:"Data trends or charts",schemaSnippet:'{"type":"chart","title":"...","chartType":"bar","labels":["Mon","Tue"],"datasets":[{"label":"Req","data":[10,20]}],"unit":"M"}'},{type:"mermaid",required:["type","code"],whenToUse:"Sequence, state, or ER diagram",schemaSnippet:'{"type":"mermaid","title":"...","code":"sequenceDiagram\\n  A->>B: ping"}'},{type:"callout",required:["type","tone","text"],whenToUse:"Notices, tips, or warnings",schemaSnippet:'{"type":"callout","title":"...","tone":"info|success|warning|tip","text":"...","icon":"rocket"}'},{type:"stats",required:["type","items"],whenToUse:"2-4 headline KPI metric cards",schemaSnippet:'{"type":"stats","title":"...","items":[{"label":"Uptime","value":"99.9%","delta":"+0.2%","hint":"30d","icon":"lightning"}]}'},{type:"tabs",required:["type","tabs"],whenToUse:"Categorized views or lists",schemaSnippet:'{"type":"tabs","title":"...","tabs":[{"label":"Overview","content":"..."},{"label":"Details","content":["..."]}]}'},{type:"timeline",required:["type","events"],whenToUse:"Chronological roadmaps",schemaSnippet:'{"type":"timeline","title":"...","events":[{"title":"Launch","time":"Q1","text":"...","icon":"rocket"}]}'},{type:"followups",required:["type","suggestions"],whenToUse:"2-4 suggested next prompt chips",schemaSnippet:'{"type":"followups","title":"Suggested follow-ups","suggestions":["Tell me more","How to optimize?"]}'},{type:"math",required:["type","latex"],whenToUse:"Formulas or derivations",schemaSnippet:'{"type":"math","title":"...","latex":"E = mc^2","steps":[{"latex":"...","note":"..."}]}'},{type:"code",required:["type","language","code"],whenToUse:"Syntax-highlighted code",schemaSnippet:'{"type":"code","title":"...","language":"typescript","code":"const x = 1;","filename":"main.ts"}'},{type:"checklist",required:["type","items"],whenToUse:"Interactive task lists, plans and completion tracking",schemaSnippet:'{"type":"checklist","title":"Launch checklist","items":[{"text":"Configure domain","detail":"Add DNS records","checked":false},{"text":"Run smoke tests","checked":true}]}'},{type:"form",required:["type","fields"],whenToUse:"Interactive input forms, preferences and structured responses",schemaSnippet:'{"type":"form","title":"Project preferences","fields":[{"id":"name","label":"Name","type":"text","required":true},{"id":"plan","label":"Plan","type":"radio","options":["Starter","Pro"]},{"id":"updates","label":"Email updates","type":"checkbox"}]}'},{type:"image",required:["type","src","alt"],whenToUse:"A requested illustration or infographic with a real HTTPS image URL",schemaSnippet:'{"type":"image","title":"...","src":"https://...","alt":"Describe the image","caption":"...","aspect":"wide"}'},{type:"dashboard",required:["type","items"],whenToUse:"A compact dashboard with 2-8 different visual panels",schemaSnippet:'{"type":"dashboard","title":"...","items":[{"title":"KPI","visual":{"type":"stats","items":[{"label":"Up","value":"99%"}]}}]}'}];function nn(){return Ye.map(n=>`${n.type}: ${n.schemaSnippet.replace(/^\{"type":"[^"]+",?/,"{").replace(/,"title":"\.\.\."/g,"")}`).join(" \u00b7 ")}function tn(){return Ye.map(n=>n.type==="dashboard"?`${n.type}{items:2-8 panels}`:`${n.type}{${n.required.filter(t=>t!=="type").join(",")}}`).join(" \u00b7 ")}var J="[BetterView v12] Keep the normal text answer. Add at most 1-2 ```ui blocks where they genuinely help. Short/casual replies get none. Never invent facts. Never generate or insert images for diagrams, charts, flows, tables or quizzes. Always use a ```ui block instead. Use double-quoted JSON.\n\nSTYLE: Minimal, compact; no outer container or background panel; Never nest cards. Readable labels. Keep flows to 12 nodes or fewer, use short node labels (6 words or fewer); large/branching flows may use pan/zoom. Trees: labeled root, children; vertical/horizontal/outline; max 6 levels/80 nodes. Use 3-5 quiz questions. Keep charts to 8 categories or fewer. Never invent image URLs.\nTypes: flow{nodes[id,label],edges[from,to,label?]} tree{root{id,label,children?},layout?:vertical|horizontal|outline} stepper{steps[title,detail?]} table{columns,rows} compare{items[label,tone,points]} quiz{questions[q,options,answer]} chart{chartType:bar|line|area|pie|doughnut|radar|scatter|bubble|heatmap|geo,labels,datasets} scatter/bubble data[{x,y,r?}]; geo data[{lon,lat,label?}]; heatmap numeric rows. mermaid{code} callout{tone,text} stats{items[label,value]} tabs{tabs[label,content]} timeline{events[title,text]} followups{suggestions} math{latex} code{language,code} checklist{items[text,checked?]} form{fields[id,label,type]} image{src,alt,caption?} dashboard{items:[{title?,visual:{...}}]}.",bt=`[BetterView v12] Keep normal text answer. Add at most 1-2 \`\`\`ui blocks when helpful; short/casual replies get none. Never invent facts. Never invent image URLs. Never generate images for diagrams, charts, flows, tables or quizzes; use a \`\`\`ui block. Images only when requested, with HTTPS src and descriptive alt.

VISUAL STYLE: Minimal, compact; no outer container. Never nest cards; concise labels. Flows to 12 nodes (<=6 words/label); large or branching graphs use the readable pan/zoom canvas. Trees: labeled root/children; vertical/horizontal/outline; max 6 levels/80 nodes. 3-5 quiz questions. Charts to 8 categories.

Type catalog:
${nn()}

Chart modes: bar|line|area|pie|doughnut|radar|scatter|bubble|heatmap|geo. Scatter/bubble points use {"x":number,"y":number,"r"?:number} (bubble needs r); heatmap rows are numeric. Geo datasets use {"lon":number,"lat":number,"label"?:string}. Dashboards contain 2-8 panels; do not nest dashboards.`,St=`[BetterView v12] Keep the normal text answer. Add at most 1-2 \`\`\`ui blocks where they genuinely help; casual/short: no ui; max 2 blocks; never invent facts or image URLs. Never generate or insert images for diagrams, charts, flows, tables or quizzes. Always use a \`\`\`ui block instead. Images only when requested, with real HTTPS src and descriptive alt. STYLE: compact; no outer container. No nested cards; host colors, concise readable labels. Keep flows to 12 nodes or fewer (6 words or fewer labels); large flows pan/zoom or use titled sections. 3-5 quiz questions. Charts to 8 categories or fewer.
Types: ${tn()}
Charts: bar|line|area|pie|doughnut|radar|scatter|bubble|heatmap|geo; scatter/bubble points {x,y,r?}, geo points {lon,lat,label?}, heatmap rows numeric. Dashboards: 2-8 panels; no nesting. Trees: root{id,label,children?} max depth 6 / 80 nodes; layout horizontal|vertical|outline.`,Mt=["h","ttp://www.w3.org/2000/svg"].join("");function rn(n,t,...a){const s=document.createElement(n);if(t){for(const[r,l]of Object.entries(t))if(!(l===void 0||l===!1))if(r.startsWith("on")&&typeof l=="function"){const c=r.slice(2).toLowerCase();s.addEventListener(c,l)}else r==="class"||r==="className"?s.className=String(l):l===!0?s.setAttribute(r,""):s.setAttribute(r,String(l))}for(const r of a)r==null||r===!1||(typeof r=="string"||typeof r=="number"?s.appendChild(document.createTextNode(String(r))):r instanceof Node&&s.appendChild(r));return s}function on(n){for(;n.firstChild;)n.removeChild(n.firstChild)}var sn="M11.04 19.32Q12 21.51 12 24q0-2.49.93-4.68.96-2.19 2.58-3.81t3.81-2.55Q21.51 12 24 12q-2.49 0-4.68-.93a12.3 12.3 0 0 1-3.81-2.58 12.3 12.3 0 0 1-2.58-3.81Q12 2.49 12 0q0 2.49-.96 4.68-.93 2.19-2.55 3.81a12.3 12.3 0 0 1-3.81 2.58Q2.49 12 0 12q2.49 0 4.68.96 2.19.93 3.81 2.55t2.55 3.81",q=null;function ie(n,t){if(!q&&typeof DOMParser<"u"&&(q=new DOMParser),!q)return document.createElementNS("http://www.w3.org/2000/svg","svg");const a=q.parseFromString(n,"image/svg+xml"),s=a.documentElement?document.importNode(a.documentElement,!0):document.createElementNS("http://www.w3.org/2000/svg","svg");return t!==void 0&&(s.setAttribute("width",String(t)),s.setAttribute("height",String(t))),s.setAttribute("aria-hidden","true"),s}var ln=0;function we(n=28){const t=`bvi-gemini-grad-${++ln}`;return ie(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="${n}" height="${n}" aria-hidden="true">
  <defs>
    <linearGradient id="${t}" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#4E82EE" />
      <stop offset="50%" stop-color="#8E75FF" />
      <stop offset="100%" stop-color="#DE51A8" />
    </linearGradient>
  </defs>
  <path fill="url(#${t})" d="${sn}" />
</svg>`,n)}function ge(n=28){return ie(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="${n}" height="${n}" fill="currentColor" fill-rule="evenodd" aria-hidden="true">
  <path fill-rule="evenodd" d="M9.27 15.29l7.978-5.897c.391-.29.95-.177 1.137.272.98 2.369.542 5.215-1.41 7.169-1.951 1.954-4.667 2.382-7.149 1.406l-2.711 1.257c3.889 2.661 8.611 2.003 11.562-.953 2.341-2.344 3.066-5.539 2.388-8.42l.006.007c-.983-4.232.242-5.924 2.75-9.383.06-.082.12-.164.179-.248l-3.301 3.305v-.01L9.267 15.292M7.623 16.723c-2.792-2.67-2.31-6.801.071-9.184 1.761-1.763 4.647-2.483 7.166-1.425l2.705-1.25a7.808 7.808 0 00-1.829-1A8.975 8.975 0 005.984 5.83c-2.533 2.536-3.33 6.436-1.962 9.764 1.022 2.487-.653 4.246-2.34 6.022-.599.63-1.199 1.259-1.682 1.925l7.62-6.815" />
</svg>`,n)}var ve=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-activity"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" />
</svg>
`,an=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-arrow-left"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m12 19-7-7 7-7" />
  <path d="M19 12H5" />
</svg>
`,cn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-arrow-right"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 12h14" />
  <path d="m12 5 7 7-7 7" />
</svg>
`,me=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-arrow-up-right"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M7 7h10v10" />
  <path d="M7 17 17 7" />
</svg>
`,dn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-bell"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M10.268 21a2 2 0 0 0 3.464 0" />
  <path d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326" />
</svg>
`,un=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-book-open"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 7v14" />
  <path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z" />
</svg>
`,ke=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-bot"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 8V4H8" />
  <rect width="16" height="12" x="4" y="8" rx="2" />
  <path d="M2 14h2" />
  <path d="M20 14h2" />
  <path d="M15 13v2" />
  <path d="M9 13v2" />
</svg>
`,fe=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-box"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
  <path d="m3.3 7 8.7 5 8.7-5" />
  <path d="M12 22V12" />
</svg>
`,xe=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-building-2"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z" />
  <path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2" />
  <path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2" />
  <path d="M10 6h4" />
  <path d="M10 10h4" />
  <path d="M10 14h4" />
  <path d="M10 18h4" />
</svg>
`,hn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-calendar"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M8 2v4" />
  <path d="M16 2v4" />
  <rect width="18" height="18" x="3" y="4" rx="2" />
  <path d="M3 10h18" />
</svg>
`,pn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-camera"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z" />
  <circle cx="12" cy="13" r="3" />
</svg>
`,X=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-chart-column"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 3v16a2 2 0 0 0 2 2h16" />
  <path d="M18 17V9" />
  <path d="M13 17V5" />
  <path d="M8 17v-3" />
</svg>
`,wn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-chart-no-axes-combined"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 16v5" />
  <path d="M16 14v7" />
  <path d="M20 10v11" />
  <path d="m22 3-8.646 8.646a.5.5 0 0 1-.708 0L9.354 8.354a.5.5 0 0 0-.707 0L2 15" />
  <path d="M4 18v3" />
  <path d="M8 14v7" />
</svg>
`,ye=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-chart-pie"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M21 12c.552 0 1.005-.449.95-.998a10 10 0 0 0-8.953-8.951c-.55-.055-.998.398-.998.95v8a1 1 0 0 0 1 1z" />
  <path d="M21.21 15.89A10 10 0 1 1 8 2.83" />
</svg>
`,gn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-check"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 6 9 17l-5-5" />
</svg>
`,Ce=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-chevron-down"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m6 9 6 6 6-6" />
</svg>
`,be=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-chevron-left"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m15 18-6-6 6-6" />
</svg>
`,Se=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-chevron-right"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m9 18 6-6-6-6" />
</svg>
`,Me=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-chevron-up"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m18 15-6-6-6 6" />
</svg>
`,vn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-circle-alert"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <line x1="12" x2="12" y1="8" y2="12" />
  <line x1="12" x2="12.01" y1="16" y2="16" />
</svg>
`,mn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-circle-check"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <path d="m9 12 2 2 4-4" />
</svg>
`,_e=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-circle-help"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
  <path d="M12 17h.01" />
</svg>
`,kn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-circle-x"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <path d="m15 9-6 6" />
  <path d="m9 9 6 6" />
</svg>
`,fn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-clock"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <polyline points="12 6 12 12 16 14" />
</svg>
`,xn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-cloud"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z" />
</svg>
`,yn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-code"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <polyline points="16 18 22 12 16 6" />
  <polyline points="8 6 2 12 8 18" />
</svg>
`,Cn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-columns-3"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="18" height="18" x="3" y="3" rx="2" />
  <path d="M9 3v18" />
  <path d="M15 3v18" />
</svg>
`,bn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-compass"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z" />
  <circle cx="12" cy="12" r="10" />
</svg>
`,Sn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-copy"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="14" height="14" x="8" y="8" rx="2" ry="2" />
  <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
</svg>
`,Mn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-cpu"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="16" height="16" x="4" y="4" rx="2" />
  <rect width="6" height="6" x="9" y="9" rx="1" />
  <path d="M15 2v2" />
  <path d="M15 20v2" />
  <path d="M2 15h2" />
  <path d="M2 9h2" />
  <path d="M20 15h2" />
  <path d="M20 9h2" />
  <path d="M9 2v2" />
  <path d="M9 20v2" />
</svg>
`,_n=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-credit-card"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="20" height="14" x="2" y="5" rx="2" />
  <line x1="2" x2="22" y1="10" y2="10" />
</svg>
`,In=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-database"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <ellipse cx="12" cy="5" rx="9" ry="3" />
  <path d="M3 5V19A9 3 0 0 0 21 19V5" />
  <path d="M3 12A9 3 0 0 0 21 12" />
</svg>
`,Ie=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-download"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
  <polyline points="7 10 12 15 17 10" />
  <line x1="12" x2="12" y1="15" y2="3" />
</svg>
`,Be=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-external-link"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 3h6v6" />
  <path d="M10 14 21 3" />
  <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
</svg>
`,Bn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-eye"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0" />
  <circle cx="12" cy="12" r="3" />
</svg>
`,jn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-file"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" />
  <path d="M14 2v4a2 2 0 0 0 2 2h4" />
</svg>
`,Ln=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-file-text"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" />
  <path d="M14 2v4a2 2 0 0 0 2 2h4" />
  <path d="M10 9H8" />
  <path d="M16 13H8" />
  <path d="M16 17H8" />
</svg>
`,je=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-filter"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" />
</svg>
`,An=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-folder"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z" />
</svg>
`,Tn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-globe"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" />
  <path d="M2 12h20" />
</svg>
`,Le=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-graduation-cap"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z" />
  <path d="M22 10v6" />
  <path d="M6 12.5V16a6 3 0 0 0 12 0v-3.5" />
</svg>
`,En=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-hard-drive"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <line x1="22" x2="2" y1="12" y2="12" />
  <path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z" />
  <line x1="6" x2="6.01" y1="16" y2="16" />
  <line x1="10" x2="10.01" y1="16" y2="16" />
</svg>
`,qn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-heart"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
</svg>
`,Nn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-hourglass"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 22h14" />
  <path d="M5 2h14" />
  <path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22" />
  <path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2" />
</svg>
`,Ae=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-house"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8" />
  <path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
</svg>
`,zn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-image"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
  <circle cx="9" cy="9" r="2" />
  <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
</svg>
`,Un=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-info"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <path d="M12 16v-4" />
  <path d="M12 8h.01" />
</svg>
`,Vn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-key"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4" />
  <path d="m21 2-9.6 9.6" />
  <circle cx="7.5" cy="15.5" r="5.5" />
</svg>
`,Hn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-laptop"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 16V7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v9m16 0H4m16 0 1.28 2.55a1 1 0 0 1-.9 1.45H3.62a1 1 0 0 1-.9-1.45L4 16" />
</svg>
`,On=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-layers"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z" />
  <path d="M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12" />
  <path d="M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17" />
</svg>
`,Pn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-link"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
  <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
</svg>
`,Gn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-list"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 12h.01" />
  <path d="M3 18h.01" />
  <path d="M3 6h.01" />
  <path d="M8 12h13" />
  <path d="M8 18h13" />
  <path d="M8 6h13" />
</svg>
`,Rn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-list-checks"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m3 17 2 2 4-4" />
  <path d="m3 7 2 2 4-4" />
  <path d="M13 6h8" />
  <path d="M13 12h8" />
  <path d="M13 18h8" />
</svg>
`,$n=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-list-ordered"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M10 12h11" />
  <path d="M10 18h11" />
  <path d="M10 6h11" />
  <path d="M4 10h2" />
  <path d="M4 6h1v4" />
  <path d="M6 18H4c0-1 2-2 2-3s-1-1.5-2-1" />
</svg>
`,Dn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-lock"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
  <path d="M7 11V7a5 5 0 0 1 10 0v4" />
</svg>
`,Te=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-mail"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="20" height="16" x="2" y="4" rx="2" />
  <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
</svg>
`,Fn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-map-pin"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0" />
  <circle cx="12" cy="10" r="3" />
</svg>
`,I=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-maximize"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M8 3H5a2 2 0 0 0-2 2v3" />
  <path d="M21 8V5a2 2 0 0 0-2-2h-3" />
  <path d="M3 16v3a2 2 0 0 0 2 2h3" />
  <path d="M16 21h3a2 2 0 0 0 2-2v-3" />
</svg>
`,Ee=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-message-circle"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z" />
</svg>
`,Kn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-messages-square"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M14 9a2 2 0 0 1-2 2H6l-4 4V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2z" />
  <path d="M18 9h2a2 2 0 0 1 2 2v11l-4-4h-6a2 2 0 0 1-2-2v-1" />
</svg>
`,ee=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-minimize"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M8 3v3a2 2 0 0 1-2 2H3" />
  <path d="M21 8h-3a2 2 0 0 1-2-2V3" />
  <path d="M3 16h3a2 2 0 0 1 2 2v3" />
  <path d="M16 21v-3a2 2 0 0 1 2-2h3" />
</svg>
`,Zn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-minus"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 12h14" />
</svg>
`,qe=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-monitor"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="20" height="14" x="2" y="3" rx="2" />
  <line x1="8" x2="16" y1="21" y2="21" />
  <line x1="12" x2="12" y1="17" y2="21" />
</svg>
`,Qn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-music"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M9 18V5l12-2v13" />
  <circle cx="6" cy="18" r="3" />
  <circle cx="18" cy="16" r="3" />
</svg>
`,Ne=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-network"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect x="16" y="16" width="6" height="6" rx="1" />
  <rect x="2" y="16" width="6" height="6" rx="1" />
  <rect x="9" y="2" width="6" height="6" rx="1" />
  <path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3" />
  <path d="M12 12V8" />
</svg>
`,Wn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-package"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z" />
  <path d="M12 22V12" />
  <path d="m3.3 7 7.703 4.734a2 2 0 0 0 1.994 0L20.7 7" />
  <path d="m7.5 4.27 9 5.15" />
</svg>
`,Yn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-panels-top-left"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="18" height="18" x="3" y="3" rx="2" />
  <path d="M3 9h18" />
  <path d="M9 21V9" />
</svg>
`,ze=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-pencil"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z" />
  <path d="m15 5 4 4" />
</svg>
`,Jn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-play"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <polygon points="6 3 20 12 6 21 6 3" />
</svg>
`,Xn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-plus"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 12h14" />
  <path d="M12 5v14" />
</svg>
`,ne=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-refresh-cw"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
  <path d="M21 3v5h-5" />
  <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
  <path d="M8 16H3v5" />
</svg>
`,et=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-rocket"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z" />
  <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z" />
  <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0" />
  <path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5" />
</svg>
`,Ue=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-scale"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
  <path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
  <path d="M7 21h10" />
  <path d="M12 3v18" />
  <path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2" />
</svg>
`,Ve=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-search"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="11" cy="11" r="8" />
  <path d="m21 21-4.3-4.3" />
</svg>
`,He=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-server"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="20" height="8" x="2" y="2" rx="2" ry="2" />
  <rect width="20" height="8" x="2" y="14" rx="2" ry="2" />
  <line x1="6" x2="6.01" y1="6" y2="6" />
  <line x1="6" x2="6.01" y1="18" y2="18" />
</svg>
`,Oe=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-settings"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
  <circle cx="12" cy="12" r="3" />
</svg>
`,nt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-shield"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
</svg>
`,tt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-shield-check"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
  <path d="m9 12 2 2 4-4" />
</svg>
`,Pe=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-shopping-cart"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="8" cy="21" r="1" />
  <circle cx="19" cy="21" r="1" />
  <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12" />
</svg>
`,Ge=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-smartphone"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="14" height="20" x="5" y="2" rx="2" ry="2" />
  <path d="M12 18h.01" />
</svg>
`,Re=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-sparkles"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z" />
  <path d="M20 3v4" />
  <path d="M22 5h-4" />
  <path d="M4 17v2" />
  <path d="M5 18H3" />
</svg>
`,it=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-square"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="18" height="18" x="3" y="3" rx="2" />
</svg>
`,rt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-square-function"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
  <path d="M9 17c2 0 2.8-1 2.8-2.8V10c0-2 1-3.3 3.2-3" />
  <path d="M9 11.2h5.7" />
</svg>
`,ot=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-star"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z" />
</svg>
`,st=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-table"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 3v18" />
  <rect width="18" height="18" x="3" y="3" rx="2" />
  <path d="M3 9h18" />
  <path d="M3 15h18" />
</svg>
`,lt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-tag"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z" />
  <circle cx="7.5" cy="7.5" r=".5" fill="currentColor" />
</svg>
`,at=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-target"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <circle cx="12" cy="12" r="6" />
  <circle cx="12" cy="12" r="2" />
</svg>
`,ct=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-terminal"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <polyline points="4 17 10 11 4 5" />
  <line x1="12" x2="20" y1="19" y2="19" />
</svg>
`,dt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-timer"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <line x1="10" x2="14" y1="2" y2="2" />
  <line x1="12" x2="15" y1="14" y2="11" />
  <circle cx="12" cy="14" r="8" />
</svg>
`,ut=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-trash-2"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 6h18" />
  <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
  <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
  <line x1="10" x2="10" y1="11" y2="17" />
  <line x1="14" x2="14" y1="11" y2="17" />
</svg>
`,ht=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-trending-down"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <polyline points="22 17 13.5 8.5 8.5 13.5 2 7" />
  <polyline points="16 17 22 17 22 11" />
</svg>
`,$e=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-trending-up"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <polyline points="22 7 13.5 15.5 8.5 10.5 2 17" />
  <polyline points="16 7 22 7 22 13" />
</svg>
`,De=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-triangle-alert"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3" />
  <path d="M12 9v4" />
  <path d="M12 17h.01" />
</svg>
`,pt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-upload"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
  <polyline points="17 8 12 3 7 8" />
  <line x1="12" x2="12" y1="3" y2="15" />
</svg>
`,wt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-user"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
  <circle cx="12" cy="7" r="4" />
</svg>
`,gt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-users"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
  <circle cx="9" cy="7" r="4" />
  <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
</svg>
`,vt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-video"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5" />
  <rect x="2" y="6" width="14" height="12" rx="2" />
</svg>
`,mt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-wallet"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1" />
  <path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4" />
</svg>
`,Fe=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-wifi"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 20h.01" />
  <path d="M2 8.82a15 15 0 0 1 20 0" />
  <path d="M5 12.859a10 10 0 0 1 14 0" />
  <path d="M8.5 16.429a5 5 0 0 1 7 0" />
</svg>
`,Ke=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-workflow"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="8" height="8" x="3" y="3" rx="2" />
  <path d="M7 11v4a2 2 0 0 0 2 2h4" />
  <rect width="8" height="8" x="13" y="13" rx="2" />
</svg>
`,kt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-x"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M18 6 6 18" />
  <path d="m6 6 12 12" />
</svg>
`,Ze=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-zap"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z" />
</svg>
`,ft={export:pt,download:Ie,"download-simple":Ie,image:zn,copy:Sn,code:yn,"corners-out":I,"arrows-out":I,maximize:I,"maximize-2":I,expand:I,"corners-in":ee,minimize:ee,x:kt,check:gn,"caret-down":Ce,"chevron-down":Ce,"caret-up":Me,"chevron-up":Me,"caret-left":be,"chevron-left":be,"caret-right":Se,"chevron-right":Se,"arrow-right":cn,"arrow-left":an,"arrow-up-right":me,"arrow-ne":me,"arrow-square-out":Be,"external-link":Be,robot:ke,bot:ke,sparkle:Re,sparkles:Re,"shield-check":tt,eye:Bn,play:Jn,globe:Tn,lock:Dn,server:He,"hard-drives":He,database:In,lightning:Ze,zap:Ze,rocket:et,clock:fn,users:gt,user:wt,cloud:xn,"chart-line":wn,"trending-up":$e,cpu:Mn,"wifi-high":Fe,wifi:Fe,bell:dn,calendar:hn,envelope:Te,mail:Te,"chat-circle":Ee,message:Ee,"chats-circle":Kn,heart:qn,star:ot,"magnifying-glass":Ve,search:Ve,gear:Oe,settings:Oe,"file-text":Ln,file:jn,folder:An,terminal:ct,tag:lt,compass:bn,"map-pin":Fn,"credit-card":_n,wallet:mt,"shopping-cart":Pe,cart:Pe,package:Wn,cube:fe,box:fe,"hard-drive":En,laptop:Hn,desktop:qe,monitor:qe,"device-mobile":Ge,smartphone:Ge,camera:pn,video:vt,"music-note":Qn,book:un,student:Le,"graduation-cap":Le,target:at,funnel:je,filter:je,"arrows-clockwise":ne,refresh:ne,"refresh-cw":ne,warning:De,"warning-circle":vn,"alert-triangle":De,shield:nt,key:Vn,link:Pn,activity:ve,pulse:ve,timer:dt,hourglass:Nn,"trend-down":ht,"trend-up":$e,"chart-pie":ye,"pie-chart":ye,"chart-bar":X,"bar-chart":X,chart:X,buildings:xe,building:xe,house:Ae,home:Ae,trash:ut,"pencil-simple":ze,edit:ze,"check-circle":mn,"x-circle":kn,info:Un,question:_e,"help-circle":_e,table:st,columns:Cn,scales:Ue,scale:Ue,steps:$n,"tree-structure":Ke,workflow:Ke,network:Ne,graph:Ne,tabs:Yn,layers:On,list:Gn,plus:Xn,minus:Zn,"bounding-box":it,shrink:ee,function:rt,checklist:Rn},xt=["export","download","download-simple","image","copy","code","corners-out","arrows-out","maximize","maximize-2","expand","corners-in","minimize","check","caret-down","chevron-down","caret-up","chevron-up","caret-left","chevron-left","caret-right","chevron-right","arrow-right","arrow-left","arrow-up-right","arrow-ne","arrow-square-out","external-link","robot","bot","sparkle","sparkles","shield-check","eye","play","globe","lock","server","hard-drives","database","lightning","zap","rocket","clock","users","user","cloud","chart-line","trending-up","cpu","wifi-high","wifi","bell","calendar","envelope","mail","chat-circle","message","chats-circle","heart","star","magnifying-glass","search","gear","settings","file-text","file","folder","terminal","tag","compass","map-pin","credit-card","wallet","shopping-cart","cart","package","cube","box","hard-drive","laptop","desktop","monitor","device-mobile","smartphone","camera","video","music-note","book","student","graduation-cap","target","funnel","filter","arrows-clockwise","refresh","refresh-cw","warning","warning-circle","alert-triangle","shield","key","link","activity","pulse","timer","hourglass","trend-down","trend-up","chart-pie","pie-chart","chart-bar","bar-chart","chart","buildings","building","house","home","trash","pencil-simple","edit","check-circle","x-circle","info","question","help-circle","table","columns","scales","scale","steps","tree-structure","workflow","network","graph","tabs","layers","list","plus","minus","bounding-box","shrink","function","checklist"],_t=new Set(xt);function yt(n){return n?n.trim().replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase().replace(/[\s_]+/g,"-"):""}function Ct(n,t=16,a){const s=ie(n,t);return s.setAttribute("fill","none"),s.setAttribute("stroke","currentColor"),s.setAttribute("stroke-width","1.8"),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),a&&s.setAttribute("class",a),s}function te(n,t=16,a){return Ct(ft[yt(n)]||`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-sparkles"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z" />
  <path d="M20 3v4" />
  <path d="M22 5h-4" />
  <path d="M4 17v2" />
  <path d="M5 18H3" />
</svg>
`,t,a)}function Qe(){const n=document.getElementById("status-line"),t=document.getElementById("copy-btn"),a=document.getElementById("system-instruction"),s=document.getElementById("theme-toggle-btn"),r=document.getElementById("theme-segmented"),l=document.getElementById("theme-select"),c=document.getElementById("watermark-toggle"),re=document.getElementById("logo-img"),oe=document.getElementById("logo-source"),N=document.getElementById("setup-gemini-btn"),z=document.getElementById("setup-grok-btn"),U=document.getElementById("label-gemini"),V=document.getElementById("label-grok"),se=document.getElementById("spinner-gemini"),le=document.getElementById("spinner-grok"),H=document.getElementById("setup-status"),O=document.getElementById("setup-gemini-status"),P=document.getElementById("setup-grok-status"),G=document.getElementById("gemini-update-hint"),B=document.getElementById("manual-setup-toggle"),x=document.getElementById("manual-setup-content"),R=document.getElementById("manual-setup-chevron"),$=document.getElementById("logo-gemini"),D=document.getElementById("logo-grok"),F=document.getElementById("icon-gemini"),K=document.getElementById("icon-grok"),Z=document.getElementById("check-gemini"),Q=document.getElementById("check-grok"),j=document.getElementById("try-it-btn"),L=document.getElementById("try-it-label"),u=document.getElementById("welcome-tour-link"),v=document.getElementById("whats-new-link");if($&&!$.querySelector("svg.bvi-gemini-logo")){const e=we(16);e.classList.add("bvi-gemini-logo"),$.prepend(e)}if(D&&!D.querySelector("svg.bvi-grok-logo")){const e=ge(16);e.classList.add("bvi-grok-logo"),D.prepend(e)}F&&!F.hasChildNodes()&&F.appendChild(we(16)),K&&!K.hasChildNodes()&&K.appendChild(ge(16)),Z&&!Z.hasChildNodes()&&Z.appendChild(te("check",12)),Q&&!Q.hasChildNodes()&&Q.appendChild(te("check",12)),R&&!R.querySelector("svg")&&R.appendChild(te("caret-down",12)),a&&(a.textContent=J,"value"in a&&(a.value=J));const ae=document.querySelector(".version-tag");ae&&(ae.textContent=`v${typeof chrome<"u"&&chrome.runtime?.getManifest?.()?.version||"0.1.0"}`);function h(e,o="muted"){H&&(H.textContent=e,H.className=`setup-status-line sr-only status-${o}`)}function A(e,o){const i=e==="gemini"?N:z,d=e==="gemini"?U:V,S=e==="gemini"?O:P,Xe=e==="gemini"?se:le,he=document.getElementById(`row-${e}`)?.querySelector(".site-status-dot");Xe?.classList.add("hidden"),d?.classList.remove("hidden");let f="not-set-up",M="Not set up",_="Set up",pe=!1,Y="";if(!o||!o.status)f="not-set-up",M="Not set up",_="Set up";else if(o.status==="added"||o.status==="already")(o.version??1)>=12?(f="ready",M="Ready",_="Redo",pe=!0):(f="needs-update",M="Needs update",_="Update");else if(o.status==="failed"){f="failed";const T=o.error?.trim();M=T?T.length>80?`${T.slice(0,79)}\u2026`:T:"Setup didn't finish",_="Retry",Y=o.error||"Setup didn't finish"}S&&(S.textContent=M,S.className=`site-status-text status-${f}`,Y?S.setAttribute("title",Y):S.removeAttribute("title")),he&&(he.className=`site-status-dot dot-${f}`),d&&(d.textContent=_),i&&(pe?(i.classList.add("btn-ghost"),i.classList.remove("btn-primary"),i.classList.add("is-done")):(i.classList.remove("btn-ghost"),i.classList.add("btn-primary"),i.classList.remove("is-done"))),e==="gemini"&&G&&(o?.hasOldEntry?G.classList.remove("hidden"):G.classList.add("hidden"))}typeof chrome<"u"&&chrome.storage?.local&&(chrome.storage.local.get(["gemini_setup_status","grok_setup_status","hasUpdateDot","lastSeenVersion"],e=>{const o=e.gemini_setup_status,i=e.grok_setup_status;if(o&&A("gemini",o),i&&A("grok",i),o&&i){const d=(o.timestamp||0)>=(i.timestamp||0)?o:i;h(d.status==="added"?"Added \u2713":d.status==="already"?"Already set up \u2713":d.error||"Failed",d.status==="failed"?"error":"success")}else o?h(o.status==="added"?"Added \u2713":"Already set up \u2713","success"):i&&h(i.status==="added"?"Added \u2713":"Already set up \u2713","success");(e.hasUpdateDot||e.lastSeenVersion)&&v?.classList.remove("hidden")}),chrome.storage.onChanged.addListener((e,o)=>{if(o==="local"){if(e.gemini_setup_status){const i=e.gemini_setup_status.newValue;A("gemini",i),i&&h(i.status==="added"?"Added \u2713":i.status==="already"?"Already set up \u2713":i.error||"Failed",i.status==="failed"?"error":"success")}if(e.grok_setup_status){const i=e.grok_setup_status.newValue;A("grok",i),i&&h(i.status==="added"?"Added \u2713":i.status==="already"?"Already set up \u2713":i.error||"Failed",i.status==="failed"?"error":"success")}e.hasUpdateDot&&(e.hasUpdateDot.newValue?v?.classList.remove("hidden"):v?.classList.add("hidden"))}})),N&&N.addEventListener("click",()=>{h("Adding prompt\u2026","muted"),se?.classList.remove("hidden"),U&&(U.textContent="Adding\u2026"),O&&(O.textContent="Adding prompt\u2026"),typeof chrome<"u"&&chrome.runtime?.sendMessage&&chrome.runtime.sendMessage({type:"START_AUTO_SETUP",site:"gemini"})}),z&&z.addEventListener("click",()=>{h("Adding prompt\u2026","muted"),le?.classList.remove("hidden"),V&&(V.textContent="Adding\u2026"),P&&(P.textContent="Adding prompt\u2026"),typeof chrome<"u"&&chrome.runtime?.sendMessage&&chrome.runtime.sendMessage({type:"START_AUTO_SETUP",site:"grok"})});let m=null;j&&j.addEventListener("click",async()=>{try{typeof navigator<"u"&&navigator.clipboard?.writeText&&await navigator.clipboard.writeText("Explain how a web browser loads a website after I type a URL, for a beginner. Keep the explanation short, add one simple flow diagram of the steps, and end with a 3-question quiz."),L&&(L.textContent="Copied"),j.classList.add("is-copied"),m!==null&&window.clearTimeout(m),m=window.setTimeout(()=>{L&&(L.textContent="Copy prompt"),j.classList.remove("is-copied"),m=null},1500)}catch(e){console.error("Failed to copy sample prompt:",e)}});let p=null,y;function w(e){if(n)if(on(n),e){n.className="status-line status-active";const o=rn("span",{class:"status-dot"});n.appendChild(o),n.appendChild(document.createTextNode(`Active on ${{gemini:"Gemini",grok:"Grok",chatgpt:"ChatGPT",claude:"Claude"}[e]}`)),ce(e==="gemini"||e==="grok")}else n.className="status-line status-muted",n.appendChild(document.createTextNode("Open Gemini, Grok, ChatGPT or Claude")),ce(!1)}function ce(e){u&&(e?(u.classList.remove("is-disabled"),u.removeAttribute("aria-disabled"),u.removeAttribute("title")):(u.classList.add("is-disabled"),u.setAttribute("aria-disabled","true"),u.setAttribute("title","Open on a Gemini or Grok tab")))}if(typeof chrome<"u"&&chrome.tabs&&chrome.tabs.query)try{chrome.tabs.query({active:!0,currentWindow:!0},e=>{const o=e&&e[0];y=o?.id;const i=o?.url||"";i.includes("gemini.google.com")?(p="gemini",w("gemini")):i.includes("grok.com")?(p="grok",w("grok")):i.includes("chatgpt.com")?(p=null,w("chatgpt")):i.includes("claude.ai")?(p=null,w("claude")):(p=null,w(null))})}catch{w(null)}else w(null);u&&u.addEventListener("click",e=>{e.preventDefault(),p&&(typeof chrome<"u"&&chrome.tabs?.sendMessage&&y!==void 0?chrome.tabs.sendMessage(y,{type:"OPEN_TOUR"}):typeof chrome<"u"&&chrome.tabs?.create&&chrome.tabs.create({url:"welcome.html"}))}),v&&v.addEventListener("click",e=>{e.preventDefault(),p&&typeof chrome<"u"&&chrome.tabs?.sendMessage&&y!==void 0?chrome.tabs.sendMessage(y,{type:"OPEN_WHATS_NEW"}):typeof chrome<"u"&&chrome.tabs?.create&&chrome.tabs.create({url:"welcome.html#whats-new"}),typeof chrome<"u"&&chrome.action?.setBadgeText&&chrome.action.setBadgeText({text:""}),typeof chrome<"u"&&chrome.storage?.local&&chrome.storage.local.set({hasUpdateDot:!1}),v.classList.add("hidden")});let k=null;t&&t.addEventListener("click",async()=>{try{typeof navigator<"u"&&navigator.clipboard?.writeText&&await navigator.clipboard.writeText(J),t.classList.add("is-copied");const e=t.querySelector(".copy-label");e?e.textContent="Copied \u2713":t.textContent="Copied \u2713",k!==null&&window.clearTimeout(k),k=window.setTimeout(()=>{t.classList.remove("is-copied"),e?e.textContent="Copy":t.textContent="Copy",k=null},1500)}catch(e){console.error("Failed to copy system instruction:",e)}}),B&&x&&B.addEventListener("click",()=>{const e=B.getAttribute("aria-expanded")!=="true";B.setAttribute("aria-expanded",String(e)),e?(x.classList.add("is-expanded"),x.removeAttribute("hidden")):(x.classList.remove("is-expanded"),x.setAttribute("hidden",""))});let W="auto";const C=typeof window<"u"&&window.matchMedia?window.matchMedia("(prefers-color-scheme: dark)"):null;function de(e){return e==="auto"?C&&C.matches?"dark":"light":e}function b(e){W=e;const o=de(e);document.documentElement.setAttribute("data-theme",o),re&&(re.src=o==="dark"?"/brand/mark-white.png":"/brand/mark-black.png"),oe&&(oe.srcset=o==="dark"?"/brand/mark-white.png":"/brand/mark-black.png"),s&&s.setAttribute("aria-label",o==="dark"?"Switch to light mode":"Switch to dark mode"),r&&(r.setAttribute("data-value",e),r.querySelectorAll(".segmented-btn").forEach(i=>{const d=i.getAttribute("data-value")===e;i.setAttribute("aria-checked",String(d)),d?i.classList.add("is-active"):i.classList.remove("is-active")})),l&&(l.value=e)}C&&C.addEventListener&&C.addEventListener("change",()=>{W==="auto"&&b("auto")});function ue(e){b(e.theme),c&&(c.checked=e.watermark!==!1)}We().then(ue).catch(console.error);const Je=en(ue);return c&&c.addEventListener("change",()=>{E({watermark:c.checked}).catch(console.error)}),s&&s.addEventListener("click",()=>{const e=de(W)==="dark"?"light":"dark";E({theme:e}).catch(console.error),b(e)}),r&&r.querySelectorAll(".segmented-btn").forEach(e=>{e.addEventListener("click",()=>{const o=e.getAttribute("data-value");(o==="auto"||o==="light"||o==="dark")&&(E({theme:o}).catch(console.error),b(o))})}),l&&l.addEventListener("change",()=>{const e=l.value;E({theme:e}).catch(console.error),b(e)}),()=>{Je(),k!==null&&window.clearTimeout(k),m!==null&&window.clearTimeout(m)}}typeof document<"u"&&(document.readyState==="loading"?document.addEventListener("DOMContentLoaded",()=>{Qe()}):Qe());
