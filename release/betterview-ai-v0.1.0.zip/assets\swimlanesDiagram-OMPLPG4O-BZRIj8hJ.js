import{r as t,t as o}from"./chunk-QB3YPZ4I-Cw78fn1_.js";import"./chunk-TU62E6Q5-5_H_1930.js";import"./mermaid.core-CBUxKyuQ.js";import"./chunk-HFQBQIA3-DJXqFxBN.js";import"./chunk-M57EVK23-L28uCd8J.js";import"./chunk-DQASFODM-Dpgp_5ZS.js";import"./chunk-LEVMRMFU-V3ASX15f.js";import"./chunk-AXFCVDMN-CGQPfxKE.js";import"./chunk-X4PVCEUW-DjE2x7GZ.js";import"./chunk-STOXU5M4-B33WM3pN.js";import"./chunk-R3KSYZAL-CFhcv5xE.js";import"./chunk-6MUBBAK2-DZbnY4e9.js";import"./chunk-BG4553SI-DOkk70kt.js";import"./d3-selection-Cu0USziQ.js";import{n as m}from"./chunk-Y2CYZVJY-CrVYBJys.js";var w=o({styles:m(r=>`${t(r)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${r.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles")});export{w as diagram};
