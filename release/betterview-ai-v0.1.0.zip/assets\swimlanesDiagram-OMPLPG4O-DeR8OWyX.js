import{r as t,t as o}from"./chunk-QB3YPZ4I-2TCcshsb.js";import"./chunk-TU62E6Q5-CpU6jJQz.js";import"./mermaid.core-ViSSZdte.js";import"./chunk-HFQBQIA3-zOO_CiX2.js";import"./chunk-M57EVK23-BP2oebaV.js";import"./chunk-DQASFODM-Dcfdi-gv.js";import"./chunk-LEVMRMFU-n7-5k3dw.js";import"./chunk-AXFCVDMN-cJACATNa.js";import"./chunk-X4PVCEUW-BUvsClr8.js";import"./chunk-STOXU5M4-DecKpNgC.js";import"./chunk-R3KSYZAL-Bip_JuhS.js";import"./chunk-6MUBBAK2-BwUbZX6t.js";import"./chunk-BG4553SI-Bl7WJsPm.js";import"./d3-selection-Cu0USziQ.js";import{n as m}from"./chunk-Y2CYZVJY-CrVYBJys.js";var w=o({styles:m(r=>`${t(r)}
  .swimlane.cluster:not([data-color-id]) rect {
    stroke: ${r.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles")});export{w as diagram};
