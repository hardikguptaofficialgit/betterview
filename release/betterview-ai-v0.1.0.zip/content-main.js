const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/chart-CoJ-C5d_.js","assets/defineProperty-CkKLuKw5.js","assets/mermaid.core-ViSSZdte.js","assets/rolldown-runtime-BEbyAHrr.js","assets/chunk-Y2CYZVJY-CrVYBJys.js","assets/chunk-DUW6YSOI-BgZRZDB6.js","assets/chunk-M57EVK23-BP2oebaV.js","assets/chunk-LEVMRMFU-n7-5k3dw.js","assets/chunk-AXFCVDMN-cJACATNa.js","assets/chunk-X4PVCEUW-BUvsClr8.js","assets/chunk-BG4553SI-Bl7WJsPm.js","assets/d3-selection-Cu0USziQ.js","assets/chunk-STOXU5M4-DecKpNgC.js","assets/chunk-R3KSYZAL-Bip_JuhS.js","assets/chunk-6MUBBAK2-BwUbZX6t.js","assets/dist-CkVUDKZu.js","assets/chunk-J5ZVWO5B-DHwRsH4r.js","assets/rough.esm-CSuoPZ5o.js","assets/chunk-DQASFODM-Dcfdi-gv.js"])))=>i.map(i=>d[i]);
var Qt=["flow","tree","stepper","table","compare","quiz","chart","mermaid","callout","stats","tabs","timeline","followups","math","code","checklist","form","image","dashboard","generic"],Ro=["blue","green","amber","orange","red","purple","teal","pink","gray","sky","mint","butter","peach","rose","lavender","stone"];function It(e){const t=e.slice(0,300).replace(/[\u201C\u201D]/g,'"').match(/"type"\s*:\s*"([a-z]+)"/);if(t&&Qt.includes(t[1]))return t[1]}function qe(e){const t=It(e);if(e.length>6e4)return{ok:!1,error:"Input exceeds 60,000 characters",typeHint:t};let i=e.trim();if(!i)return{ok:!1,error:"Empty input",typeHint:t};const n=i.indexOf(`
`),o=(n!==-1?i.slice(0,n):i).trim();(o==="ui"||o==="json"||o.startsWith("```"))&&(i=n!==-1?i.slice(n+1).trim():""),i.endsWith("```")&&(i=i.slice(0,-3).trim());let r="";for(;r!==i;)r=i,i=i.replace(/,\s*([}\]])/g,"$1");const a=t||It(i);try{return{ok:!0,value:JSON.parse(i)}}catch(s){if(i.includes("\u201c")||i.includes("\u201d")){const l=i.replace(/[\u201C\u201D]/g,'"');try{return{ok:!0,value:JSON.parse(l)}}catch(c){return{ok:!1,error:c instanceof Error?c.message:String(c),typeHint:a}}}return{ok:!1,error:s instanceof Error?s.message:String(s),typeHint:a}}}var Dn=[{type:"tree",required:["type","root"],whenToUse:"Hierarchies, mind maps, org charts",schemaSnippet:'{"type":"tree","layout":"vertical","root":{"id":"r","label":"Root","children":[{"id":"a","label":"Branch"}]}}'},{type:"flow",required:["type","nodes","edges"],whenToUse:"Process flows or architecture",schemaSnippet:'{"type":"flow","title":"...","nodes":[{"id":"a","label":"User"},{"id":"b","label":"API server"}],"edges":[{"from":"a","to":"b","label":"Request"}]}'},{type:"stepper",required:["type","steps"],whenToUse:"Sequential steps or tutorials",schemaSnippet:'{"type":"stepper","title":"...","steps":[{"title":"...","detail":"..."}]}'},{type:"table",required:["type","columns","rows"],whenToUse:"Tabular data or metrics",schemaSnippet:'{"type":"table","title":"...","columns":["Metric","Value"],"rows":[["A","100"]]}'},{type:"compare",required:["type","items"],whenToUse:"Side-by-side trade-offs",schemaSnippet:'{"type":"compare","title":"...","items":[{"label":"SQL","tone":"good","points":["..."]}]}'},{type:"quiz",required:["type","questions"],whenToUse:"Multiple-choice checks",schemaSnippet:'{"type":"quiz","title":"...","questions":[{"q":"...","options":["A","B"],"answer":0,"explain":"..."}]}'},{type:"chart",required:["type","chartType","labels","datasets"],whenToUse:"Data trends or charts",schemaSnippet:'{"type":"chart","title":"...","chartType":"bar","labels":["Mon","Tue"],"datasets":[{"label":"Req","data":[10,20]}],"unit":"M"}'},{type:"mermaid",required:["type","code"],whenToUse:"Sequence, state, or ER diagram",schemaSnippet:'{"type":"mermaid","title":"...","code":"sequenceDiagram\\n  A->>B: ping"}'},{type:"callout",required:["type","tone","text"],whenToUse:"Notices, tips, or warnings",schemaSnippet:'{"type":"callout","title":"...","tone":"info|success|warning|tip","text":"...","icon":"rocket"}'},{type:"stats",required:["type","items"],whenToUse:"2-4 headline KPI metric cards",schemaSnippet:'{"type":"stats","title":"...","items":[{"label":"Uptime","value":"99.9%","delta":"+0.2%","hint":"30d","icon":"lightning"}]}'},{type:"tabs",required:["type","tabs"],whenToUse:"Categorized views or lists",schemaSnippet:'{"type":"tabs","title":"...","tabs":[{"label":"Overview","content":"..."},{"label":"Details","content":["..."]}]}'},{type:"timeline",required:["type","events"],whenToUse:"Chronological roadmaps",schemaSnippet:'{"type":"timeline","title":"...","events":[{"title":"Launch","time":"Q1","text":"...","icon":"rocket"}]}'},{type:"followups",required:["type","suggestions"],whenToUse:"2-4 suggested next prompt chips",schemaSnippet:'{"type":"followups","title":"Suggested follow-ups","suggestions":["Tell me more","How to optimize?"]}'},{type:"math",required:["type","latex"],whenToUse:"Formulas or derivations",schemaSnippet:'{"type":"math","title":"...","latex":"E = mc^2","steps":[{"latex":"...","note":"..."}]}'},{type:"code",required:["type","language","code"],whenToUse:"Syntax-highlighted code",schemaSnippet:'{"type":"code","title":"...","language":"typescript","code":"const x = 1;","filename":"main.ts"}'},{type:"checklist",required:["type","items"],whenToUse:"Interactive task lists, plans and completion tracking",schemaSnippet:'{"type":"checklist","title":"Launch checklist","items":[{"text":"Configure domain","detail":"Add DNS records","checked":false},{"text":"Run smoke tests","checked":true}]}'},{type:"form",required:["type","fields"],whenToUse:"Interactive input forms, preferences and structured responses",schemaSnippet:'{"type":"form","title":"Project preferences","fields":[{"id":"name","label":"Name","type":"text","required":true},{"id":"plan","label":"Plan","type":"radio","options":["Starter","Pro"]},{"id":"updates","label":"Email updates","type":"checkbox"}]}'},{type:"image",required:["type","src","alt"],whenToUse:"A requested illustration or infographic with a real HTTPS image URL",schemaSnippet:'{"type":"image","title":"...","src":"https://...","alt":"Describe the image","caption":"...","aspect":"wide"}'},{type:"dashboard",required:["type","items"],whenToUse:"A compact dashboard with 2-8 different visual panels",schemaSnippet:'{"type":"dashboard","title":"...","items":[{"title":"KPI","visual":{"type":"stats","items":[{"label":"Up","value":"99%"}]}}]}'}];function Po(){return Dn.map(e=>`${e.type}: ${e.schemaSnippet.replace(/^\{"type":"[^"]+",?/,"{").replace(/,"title":"\.\.\."/g,"")}`).join(" \u00b7 ")}function Vo(){return Dn.map(e=>e.type==="dashboard"?`${e.type}{items:2-8 panels}`:`${e.type}{${e.required.filter(t=>t!=="type").join(",")}}`).join(" \u00b7 ")}var Ho="[BetterView v12] Keep the normal text answer. Add at most 1-2 ```ui blocks where they genuinely help. Short/casual replies get none. Never invent facts. Never generate or insert images for diagrams, charts, flows, tables or quizzes. Always use a ```ui block instead. Use double-quoted JSON.\n\nSTYLE: Minimal, compact; no outer container or background panel; Never nest cards. Readable labels. Keep flows to 12 nodes or fewer, use short node labels (6 words or fewer); large/branching flows may use pan/zoom. Trees: labeled root, children; vertical/horizontal/outline; max 6 levels/80 nodes. Use 3-5 quiz questions. Keep charts to 8 categories or fewer. Never invent image URLs.\nTypes: flow{nodes[id,label],edges[from,to,label?]} tree{root{id,label,children?},layout?:vertical|horizontal|outline} stepper{steps[title,detail?]} table{columns,rows} compare{items[label,tone,points]} quiz{questions[q,options,answer]} chart{chartType:bar|line|area|pie|doughnut|radar|scatter|bubble|heatmap|geo,labels,datasets} scatter/bubble data[{x,y,r?}]; geo data[{lon,lat,label?}]; heatmap numeric rows. mermaid{code} callout{tone,text} stats{items[label,value]} tabs{tabs[label,content]} timeline{events[title,text]} followups{suggestions} math{latex} code{language,code} checklist{items[text,checked?]} form{fields[id,label,type]} image{src,alt,caption?} dashboard{items:[{title?,visual:{...}}]}.",tu=`[BetterView v12] Keep normal text answer. Add at most 1-2 \`\`\`ui blocks when helpful; short/casual replies get none. Never invent facts. Never invent image URLs. Never generate images for diagrams, charts, flows, tables or quizzes; use a \`\`\`ui block. Images only when requested, with HTTPS src and descriptive alt.

VISUAL STYLE: Minimal, compact; no outer container. Never nest cards; concise labels. Flows to 12 nodes (<=6 words/label); large or branching graphs use the readable pan/zoom canvas. Trees: labeled root/children; vertical/horizontal/outline; max 6 levels/80 nodes. 3-5 quiz questions. Charts to 8 categories.

Type catalog:
${Po()}

Chart modes: bar|line|area|pie|doughnut|radar|scatter|bubble|heatmap|geo. Scatter/bubble points use {"x":number,"y":number,"r"?:number} (bubble needs r); heatmap rows are numeric. Geo datasets use {"lon":number,"lat":number,"label"?:string}. Dashboards contain 2-8 panels; do not nest dashboards.`,Wo=`[BetterView v12] Keep the normal text answer. Add at most 1-2 \`\`\`ui blocks where they genuinely help; casual/short: no ui; max 2 blocks; never invent facts or image URLs. Never generate or insert images for diagrams, charts, flows, tables or quizzes. Always use a \`\`\`ui block instead. Images only when requested, with real HTTPS src and descriptive alt. STYLE: compact; no outer container. No nested cards; host colors, concise readable labels. Keep flows to 12 nodes or fewer (6 words or fewer labels); large flows pan/zoom or use titled sections. 3-5 quiz questions. Charts to 8 categories or fewer.
Types: ${Vo()}
Charts: bar|line|area|pie|doughnut|radar|scatter|bubble|heatmap|geo; scatter/bubble points {x,y,r?}, geo points {lon,lat,label?}, heatmap rows numeric. Dashboards: 2-8 panels; no nesting. Trees: root{id,label,children?} max depth 6 / 80 nodes; layout horizontal|vertical|outline.`;function dt(){return Ho}var Rn=Qt.filter(e=>e!=="generic"),Uo=Rn.join("|"),ui=new RegExp(`^\\s*\\{[\\s\\S]{0,300}?["\u201c\u201d]type["\u201c\u201d]\\s*:\\s*["\u201c\u201d](${Uo})["\u201c\u201d]`);function Jt(e,t){const i=new Set,n=o=>{o.querySelectorAll(t).forEach(r=>i.add(r)),o.querySelectorAll("*").forEach(r=>{r.shadowRoot&&n(r.shadowRoot)})};return n(e),Array.from(i)}function ei(e,t){if(e===t)return!0;if(!e.contains(t))return!1;const i="p, li, ul, ol, h1, h2, h3, h4, h5, h6, table, blockquote, hr";if(e.matches(i))return!1;const n=e.querySelectorAll(i);for(const a of Array.from(n))if(!t.contains(a))return!1;let o="";function r(a){if(!(a===t||t.contains(a))&&!(a instanceof HTMLElement&&(a.tagName.toLowerCase()==="button"||a.closest("button")))){if(a.nodeType===Node.TEXT_NODE){o+=a.textContent??"";return}for(let s=0;s<a.childNodes.length;s++)r(a.childNodes[s])}}for(let a=0;a<e.childNodes.length;a++)r(e.childNodes[a]);return o.trim().length<=40}var Go={id:"gemini",matches(e){return e.hostname==="gemini.google.com"||e.hostname.endsWith(".gemini.google.com")},chatRoot(){return document.querySelector("main")??document.querySelector("model-response")??document.querySelector(".markdown.markdown-main-panel")??document.querySelector("chat-window")??document.body},findCodeBlocks(e){const t=Jt(e,"model-response code-block, .markdown.markdown-main-panel code-block, code-block, .code-block"),i=new Set,n=[];return t.forEach(o=>{const r=(o.tagName.toLowerCase()==="code-block"?o:o.closest("code-block"))??o;i.has(r)||(i.add(r),n.push(r))}),n},codeElementOf(e){return e.querySelector('code[data-test-id="code-content"]')??e.querySelector("pre code")??e.querySelector("code")??(e.tagName.toLowerCase()==="code"?e:null)},languageOf(e){const t=this.codeElementOf?this.codeElementOf(e):e.querySelector("code");if(t&&t.className){const n=t.className.match(/language-([\w-]+)/i);if(n){const o=n[1].toLowerCase();if(o&&o!=="code snippet")return o}}const i=this.wrapperOf(e);if(i){const n=i.querySelector(".code-block-decoration");if(n){const a=n.cloneNode(!0);a.querySelectorAll('button, [role="button"], .buttons').forEach(l=>l.remove());const s=(a.textContent??"").trim().toLowerCase();return s&&s!=="code snippet"?s:null}const o=new Set(["ui","json","javascript","typescript","python","html","css","bash","sh","markdown","sql","cpp","c","java","go","rust"]),r=i.querySelectorAll("*");for(const a of Array.from(r)){if(a.tagName.toLowerCase()==="button"||a.closest("button")||a.contains(t??e))continue;const s=(a.textContent??"").trim().toLowerCase();if(o.has(s))return s}}return null},wrapperOf(e){return e.closest("code-block, .code-block")??e},composer(){return document.querySelector('rich-textarea [contenteditable="true"], .ql-editor[contenteditable="true"], div[contenteditable="true"][role="textbox"]')},sendButton(){return document.querySelector('button[aria-label*="Send" i], button.send-button')},isNewChat(e){return/^\/(u\/\d+\/)?(app|gem\/[^/]+)\/?$/.test(e.pathname)}},Yo={id:"grok",matches(e){return e.hostname==="grok.com"||e.hostname.endsWith(".grok.com")},chatRoot(){return document.querySelector("main")??document.body},findCodeBlocks(e){return Jt(e,"pre")},codeElementOf(e){return e.querySelector("code")??(e.tagName.toLowerCase()==="code"?e:null)},languageOf(e){const t=this.codeElementOf?this.codeElementOf(e):e.querySelector("code");if(t&&t.className){const n=t.className.match(/language-([\w-]+)/);if(n)return n[1].toLowerCase()}const i=this.wrapperOf(e);if(i&&i!==e){const n=i.querySelectorAll("*");for(const o of Array.from(n)){if(o===e||o.contains(e)||e.contains(o)||o.tagName.toLowerCase()==="button"||o.closest("button")||o.children.length>0)continue;const r=(o.textContent??"").trim();if(r.length>=1&&r.length<=12)return r.toLowerCase()}}return null},wrapperOf(e){let t=e.parentElement,i=e,n=0;for(;t&&n<4;){n++;const o=t.querySelectorAll("pre");if(o.length===1&&(o[0]===e||o[0].contains(e)))if(ei(t,e))i=t;else break;else break;t=t.parentElement}return i},composer(){return document.querySelector('form textarea, textarea, form [contenteditable="true"]')},sendButton(){return document.querySelector('form button[type="submit"], button[aria-label*="Submit" i], button[aria-label*="Send" i]')},isNewChat(e){return e.pathname==="/"||!e.pathname.includes("/c/")}};function Pn(e,t){return{id:e,matches(i){return i.hostname===t||i.hostname.endsWith(`.${t}`)},chatRoot(){return document.querySelector("main")??document.body},findCodeBlocks(i){return Jt(i,"pre")},codeElementOf(i){return i.querySelector("code")??(i.tagName.toLowerCase()==="code"?i:null)},languageOf(i){const n=this.codeElementOf?.(i)??i,o=(typeof n.className=="string"?n.className:"").match(/language-([\w-]+)/i);if(o)return o[1].toLowerCase();const r=this.wrapperOf(i);for(const a of Array.from(r.querySelectorAll("*"))){if(a===i||a.contains(i)||i.contains(a)||a.tagName.toLowerCase()==="button"||a.closest("button")||a.children.length)continue;const s=(a.textContent??"").trim();if(s.length>0&&s.length<=12)return s.toLowerCase()}return null},wrapperOf(i){let n=i.parentElement,o=i;for(let r=0;n&&r<4;r++,n=n.parentElement){const a=n.querySelectorAll("pre");if(a.length!==1||a[0]!==i&&!a[0].contains(i)||!ei(n,i))break;o=n}return o},composer(){return e==="chatgpt"?document.querySelector('#prompt-textarea, [contenteditable="true"][role="textbox"], textarea'):document.querySelector('fieldset [contenteditable="true"], textarea, [contenteditable="true"]')},sendButton(){return e==="chatgpt"?document.querySelector('button[data-testid="send-button"], button[aria-label*="Send" i]'):document.querySelector('button[aria-label*="Send" i], button[type="submit"]')},isNewChat(i){return i.pathname==="/"||!/\/(c|chat)\//.test(i.pathname)}}}var Ko=Pn("chatgpt","chatgpt.com"),Xo=Pn("claude","claude.ai"),Zo=[Go,Yo,Ko,Xo];function Qo(e){for(const t of Zo)if(t.matches(e))return t;return null}function Jo(e,t){if(e.codeElementOf){const i=e.codeElementOf(t);if(i)return i}return t.querySelector('code[data-test-id="code-content"]')??t.querySelector("pre code")??t.querySelector("code")??t.querySelector("pre")??t}function Ft(e,t){return Jo(e,t).textContent??""}var er=/^(?:flowchart|graph|sequenceDiagram|classDiagram|stateDiagram(?:-v2)?|erDiagram|journey|gantt|pie|mindmap|timeline|gitGraph|C4Context|C4Container|C4Component|C4Dynamic|C4Deployment|requirementDiagram|kanban|packet-beta|block-beta|architecture-beta|sankey-beta|xychart-beta|quadrantChart|radar-beta|zenuml)\b/i;function $t(e,t){if(!e||e.length>12e3)return null;let i=e.replace(/^\uFEFF/,"").trim();const n=i.match(/^```\s*([\w-]*)\s*\r?\n([\s\S]*?)\r?\n```\s*$/);if(n){if(n[1]&&n[1].toLowerCase()!=="mermaid")return null;i=n[2].trim()}else if(/^```/.test(i))return null;const o=(t||"").toLowerCase()==="mermaid",r=i.split(/\r?\n/).map(a=>a.trim()).find(a=>a&&!a.startsWith("%%"))||"";return!o&&!er.test(r)||!r||i.length>8e3?null:i}function pi(e){return JSON.stringify({type:"mermaid",title:"Mermaid diagram",code:e})}function tr(e,t){const i=e.languageOf(t);if(i==="ui")return!0;const n=Ft(e,t);if($t(n,i))return!0;let o=n.replace(/^\uFEFF/,"").trimStart();o=o.replace(/^(?:```\s*ui|ui|json)\s*(?:\r?\n|$)/i,"").trimStart();const r=o.replace(/[\u201C\u201D]/g,'"'),a=r.slice(0,300);if(o.startsWith("{")&&ui.test(r.slice(0,350))||o.startsWith("{")&&ui.test(a))return!0;const s=qe(o);if(s.ok&&typeof s.value=="object"&&s.value!==null&&!Array.isArray(s.value)){const l=s.value.type;if(typeof l=="string"&&Rn.includes(l))return!0}return!1}var Te={customizeRegion:'[role="region"][aria-label*="Customize" i], region[aria-label*="Customize" i], [data-testid*="customize" i]',accountMenu:'button[aria-label*="account" i], button[aria-label*="profile" i], [data-testid*="account" i] button',menuItem:'[role="menuitem"]',dropdown:`button[aria-label="Customize Grok's Response"]`,menuitemRadio:'[role="menuitemradio"]',textarea:'textarea[aria-label="Instructions"], textarea',saveButton:"button"};function Le(e){const t=document.querySelectorAll('button, a, [role="button"], [role="menuitem"], [role="tab"]');for(const i of Array.from(t)){const n=[i.textContent,i.getAttribute("aria-label"),i.getAttribute("title")].filter(Boolean).join(" ").replace(/\s+/g," ").trim();if(e.test(n))return i}return null}function Ke(e){const t=e.matchAll(/\[betterview(?:\s+v(\d+))?\]/gi);let i=null;for(const n of t){const o=n[1]?parseInt(n[1],10):1;(i===null||o>i)&&(i=o)}return i}function jt(e){const t=e.matchAll(/\[betterview(?:\s+v(\d+))?\]/gi);for(const i of t)if((i[1]?parseInt(i[1],10):1)<12)return!0;return!1}function ir(e){const t=Ke(e);return t!==null&&t>=12}function nr(e,t){const i=e.trim(),n=Ke(i),o=Ke(t);return n!==null?o!==null&&o>n?i.replace(/\[betterview[\s\S]*$/i,t):e:i?`${i}

${t}`:t}function or(e){return/\[betterview(?:\s+v\d+)?\]/i.test(e)}function $e(e,t){const i=new Set,n=o=>{o.querySelectorAll(t).forEach(r=>i.add(r)),o.querySelectorAll("*").forEach(r=>{r.shadowRoot&&n(r.shadowRoot)})};return n(e),Array.from(i)}function me(e){const t=$e(e,'mat-dialog-container, edit-memory-dialog, [role="dialog"], dialog').filter(o=>!(o.getAttribute("aria-hidden")==="true"||o.getAttribute("inert")!==null||o instanceof HTMLElement&&(o.style.display==="none"||o.hidden)));if(t.length===0)return null;const i=t.filter(o=>!!o.querySelector('textarea.edit-memory-input, textarea[aria-label*="memory" i], textarea, [contenteditable="true"][role="textbox"], [contenteditable="true"], input[type="text"]')),n=i.length>0?i:t;return n[n.length-1]}function we(e){const t=me(e);return t?$e(t,'textarea.edit-memory-input, textarea[aria-label*="memory" i], textarea, [contenteditable="true"][role="textbox"], [contenteditable="true"], input[type="text"]').find(i=>!(i.getAttribute("aria-hidden")==="true"||i.getAttribute("inert")!==null||i instanceof HTMLElement&&(i.style.display==="none"||i.hidden)))??null:null}function hi(e){return!(!e||e.disabled||e.hasAttribute("disabled")||e.classList.contains("mat-mdc-button-disabled")||e.getAttribute("aria-disabled")==="true")}function rr(e){const t=me(e);if(!t)return null;const i=$e(t,'button, [role="button"]');for(const n of i)if([n.textContent,n.getAttribute("aria-label"),n.getAttribute("data-test-id"),n.className].filter(Boolean).map(o=>(o??"").replace(/\s+/g," ").trim()).some(o=>/^(submit|save|add|done)(?:\s+(?:memory|info|instruction|changes))?$/i.test(o)||/submit-button/i.test(o)||/edit-memory-submit-button/i.test(o)))return n;return null}function ar(e){return/^\/(u\/\d+\/)?saved-info\/?$/.test(e)}function et(e){return"body"in e&&e.body?e.body:e}function ft(e=document){const t=me(e),i=et(e);if(!i)return"";if(!t)return i.innerText||i.textContent||"";let n="";const o=r=>{if(!(r===t||t.contains(r))){if(r.nodeType===Node.TEXT_NODE){n+=" "+(r.textContent??"");return}r instanceof HTMLElement&&r.shadowRoot&&o(r.shadowRoot);for(let a=0;a<r.childNodes.length;a++)o(r.childNodes[a])}};return o(i),n.trim()}function sr(e=document){const t=$e(e,'h1, h2, h3, h4, [role="heading"]');for(const i of t){const n=(i.textContent??"").replace(/\s+/g," ").trim().toLowerCase();if(n.includes("saved info")||n.includes("instructions for gemini")||n.includes("your instructions"))return!0}return!1}function fi(e=document){const t=a=>!(a.getAttribute("aria-hidden")==="true"||a.getAttribute("inert")!==null||a.hasAttribute("disabled")||a.getAttribute("aria-disabled")==="true"||a.disabled===!0||a instanceof HTMLElement&&(a.style.display==="none"||a.style.visibility==="hidden"||a.hidden||a.closest('rich-textarea, .ql-editor, [contenteditable="true"], chat-window, model-response')||a.closest('edit-memory-dialog, [role="dialog"], mat-dialog-container, dialog'))),i=$e(e,"span.mdc-button__label");for(const a of i)if(t(a)&&(a.textContent??"").trim()==="Add"){const s=a.closest('button, [role="button"]');return s&&t(s)?s:a}const n=$e(e,'button, [role="button"]'),o=/^(\+\s*)?add( new)?( info| memory| instruction)?$/i;for(const a of n){if(!t(a))continue;const s=(a.textContent??"").replace(/\s+/g," ").trim(),l=(a.getAttribute("aria-label")??"").replace(/\s+/g," ").trim();if(o.test(s)||o.test(l)||/add/i.test(l)&&/(info|memory|instruction)/i.test(l))return a}const r=$e(e,'[data-test-id*="add" i]');for(const a of r){if(!t(a))continue;const s=a.tagName.toLowerCase()==="button"||a.getAttribute("role")==="button"?a:a.closest('button, [role="button"]');return s&&t(s)?s:a}return null}function gi(e){if(!(e instanceof HTMLElement))return!0;if(!e.isConnected||e.getAttribute("aria-hidden")==="true"||e.hidden||e.style.display==="none"||e.style.visibility==="hidden")return!1;if(e.offsetParent!==null&&e.offsetParent!==void 0)return!0;const t=typeof e.getBoundingClientRect=="function"?e.getBoundingClientRect():null;return!!(t&&(t.width>0||t.height>0)||e.offsetParent===void 0)}async function lr(e,t={}){const i=t.waitTimeoutMs??1e4,n=t.pollIntervalMs!==void 0&&t.pollIntervalMs<100?t.pollIntervalMs:250,o=t.minSettleMs??(t.pollIntervalMs!==void 0&&t.pollIntervalMs<100?t.pollIntervalMs*2:600),r=Date.now();let a=null,s=null,l=0;for(;Date.now()-r<i;){const p=we(e);if(p&&p.isConnected&&gi(p)){a===null&&(a=Date.now()),p===s?l++:(s=p,l=1);const h=Date.now()-a;if(l>=2&&h>=o)return console.info("[BetterView] gemini setup: dialog settled"),p}else s=null,l=0;await new Promise(h=>setTimeout(h,n))}const c=we(e);if(c&&c.isConnected&&gi(c))return console.info("[BetterView] gemini setup: dialog settled"),c;const d="Couldn't find the text box";throw console.warn("[BetterView]",d),new Error(d)}function cr(e,t){if(e.focus(),e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement)try{e.select()}catch{try{e.setSelectionRange(0,e.value.length)}catch{}}let i=!1;if(typeof document<"u"&&typeof document.execCommand=="function")try{i=document.execCommand("insertText",!1,t)}catch{i=!1}const n=e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement?e.value:e.textContent??"";if(!i||n!==t){if(e instanceof HTMLTextAreaElement){const o=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value");o?.set?o.set.call(e,t):e.value=t}else if(e instanceof HTMLInputElement){const o=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value");o?.set?o.set.call(e,t):e.value=t}else e.textContent=t;try{e.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:t}))}catch{e.dispatchEvent(new Event("input",{bubbles:!0}))}e.dispatchEvent(new Event("change",{bubbles:!0}));try{e.dispatchEvent(new KeyboardEvent("keyup",{bubbles:!0,key:" "}))}catch{}try{e.dispatchEvent(new FocusEvent("blur",{bubbles:!0}))}catch{e.dispatchEvent(new Event("blur",{bubbles:!0}))}}}async function dr(e=document,t={}){const i=t.waitTimeoutMs??1e4,n=t.pollIntervalMs??100;await lr(e,t);const o=dt();if(o.length>1400){const c=`Instruction too long for Gemini (${o.length} chars)`;throw console.warn("[BetterView]",c),new Error(c)}const r=t.pollIntervalMs!==void 0&&t.pollIntervalMs<100?t.pollIntervalMs:400;for(let c=1;c<=3;c++){const d=we(e);if(!d){const f="Couldn't find the text box";throw console.warn("[BetterView]",f),new Error(f)}cr(d,o);const p=d instanceof HTMLInputElement||d instanceof HTMLTextAreaElement?d.value:d.textContent??"";console.info(`[BetterView] gemini setup: fill attempt ${c} value length ${p.length}`),await new Promise(f=>setTimeout(f,r));const h=we(e);if((h instanceof HTMLInputElement||h instanceof HTMLTextAreaElement?h.value:h?.textContent??"")===o)break}const a=Math.min(i,5e3),s=Date.now();let l=null;for(;Date.now()-s<a&&(l=rr(e),!hi(l));)await new Promise(c=>setTimeout(c,n));if(!l||!hi(l)){const c="Gemini's Submit button stayed disabled after filling";throw console.warn("[BetterView]",c),new Error(c)}if(console.info("[BetterView] gemini setup: Submit enabled"),l.click(),t.waitForClose){const c=Date.now(),d=Math.min(i,8e3);let p=!1;for(;Date.now()-c<d;){const h=me(e);if(!h||!h.isConnected||h.style.display==="none"){p=!0;break}await new Promise(f=>setTimeout(f,n))}if(!p){const h="Dialog didn't close";throw console.warn("[BetterView]",h),new Error(h)}}}async function Vn(e={}){const t=e.readyTimeoutMs??15e3,i=e.addRetryMs??4e3,n=e.verifyTimeoutMs??1e4,o=e.pollMs??200,r=e.root??(typeof document<"u"?document:{});let a=!1;try{console.info("[BetterView] gemini setup: waiting for saved info page");const s=()=>!!(me(r)&&we(r)||fi(r)||sr(r)),l=Date.now();for(;Date.now()-l<t&&!s();)await new Promise(S=>setTimeout(S,o));console.info("[BetterView] gemini setup: saved info page ready check completed");let c=me(r),d=c?we(r):null,p=!!(c&&d);const h=ft(r);if(a=jt(h),p)console.info("[BetterView] gemini setup: dialog already open (skipping Add)");else{console.info("[BetterView] gemini setup: checking existing instructions");const S=Ke(h);if(S!==null&&S>=12){console.info(`[BetterView] gemini setup: instruction already present (v${S})`);const E={status:"already",version:S,hasOldEntry:a};return ce("gemini",E),E}if(c=me(r),d=c?we(r):null,c&&d)console.info("[BetterView] gemini setup: dialog already open (skipping Add)"),p=!0;else{let E=null;for(let z=1;z<=3;z++){if(c=me(r),d=c?we(r):null,c&&d){console.info("[BetterView] gemini setup: dialog already open (skipping Add)"),p=!0,E=d;break}console.info(`[BetterView] gemini setup: looking for Add button (attempt ${z}/3)`);const L=fi(r);if(!L)break;console.info(`[BetterView] gemini setup: clicking Add button (attempt ${z}/3)`),L.click();const F=Date.now();for(;Date.now()-F<i;){if(c=me(r),E=c?we(r):null,c&&E){p=!0;break}await new Promise(B=>setTimeout(B,o))}if(p)break}d=E??we(r),c=me(r),p=!!(c&&d)}if(!p||!d){const E="Couldn't find Gemini's Add button. Open gemini.google.com/saved-info, make sure you're signed in, then try again.";console.warn("[BetterView]",E);const z={status:"failed",error:E,hasOldEntry:a};return ce("gemini",z),z}}d||(d=we(r));const f=(d instanceof HTMLInputElement||d instanceof HTMLTextAreaElement?d.value:d?.textContent??"").trim();if(f!==""&&!or(f)){const S="Gemini dialog contains existing text; aborting to avoid overwriting";console.warn("[BetterView]",S);const E={status:"failed",error:S,hasOldEntry:a};return ce("gemini",E),E}const g=dt();if(g.length>1400){const S=`Instruction too long for Gemini (${g.length} chars)`;console.warn("[BetterView]",S);const E={status:"failed",error:S,hasOldEntry:a};return ce("gemini",E),E}const b=me(r);console.info("[BetterView] gemini setup: filling memory dialog"),await dr(r,{waitTimeoutMs:Math.min(n,5e3),pollIntervalMs:o,waitForClose:!1}),console.info("[BetterView] gemini setup: submitted memory dialog"),console.info("[BetterView] gemini setup: verifying saved entry");const m=Date.now(),C=/wasn't saved|couldn't save|something went wrong|try again later|too long/i,v="[BetterView v12";for(;Date.now()-m<n;){await new Promise(z=>setTimeout(z,o));const S=(et(r)?.textContent??"").match(C);if(S){const z=`Gemini rejected the entry: ${S[0]}`;console.warn("[BetterView]",z);const L={status:"failed",error:z,hasOldEntry:a};return ce("gemini",L),L}if(ft(r).includes(v)){console.info(`[BetterView] gemini setup: verified entry on page (${v})`);const z={status:"added",version:12,hasOldEntry:a};return ce("gemini",z),z}const E=me(r);if(b!==null&&(!b.isConnected||b instanceof HTMLElement&&(b.style.display==="none"||b.hidden))||!E||!E.isConnected||E instanceof HTMLElement&&(E.style.display==="none"||E.hidden)){await new Promise(F=>setTimeout(F,o));const z=(et(r)?.textContent??"").match(C);if(z){const F=`Gemini rejected the entry: ${z[0]}`;console.warn("[BetterView]",F);const B={status:"failed",error:F,hasOldEntry:a};return ce("gemini",B),B}console.info("[BetterView] gemini setup: dialog closed successfully");const L={status:"added",version:12,hasOldEntry:a};return ce("gemini",L),L}}const w=me(r),x=b!==null&&(!b.isConnected||b instanceof HTMLElement&&(b.style.display==="none"||b.hidden))||!w||!w.isConnected||w instanceof HTMLElement&&(w.style.display==="none"||w.hidden),y=(et(r)?.textContent??"").match(C);if(y){const S=`Gemini rejected the entry: ${y[0]}`;console.warn("[BetterView]",S);const E={status:"failed",error:S,hasOldEntry:a};return ce("gemini",E),E}if(ft(r).includes(v)||x){const S={status:"added",version:12,hasOldEntry:a};return ce("gemini",S),S}const k="Gemini didn't accept the entry (dialog still open)";console.warn("[BetterView]",k);const A={status:"failed",error:k,hasOldEntry:a};return ce("gemini",A),A}catch(s){const l=s instanceof Error?s.message:String(s);console.warn("[BetterView]","Gemini setup error:",l);const c={status:"failed",error:l,hasOldEntry:a};return ce("gemini",c),c}}function Ie(){try{navigator.clipboard?.writeText(dt()).catch(()=>{});const e=document.createElement("div");e.style.cssText="position:fixed;bottom:24px;right:24px;z-index:999999;background:#0A0A0A;color:#FAFAFA;padding:12px 18px;border-radius:12px;border:1px solid #262626;font-family:sans-serif;font-size:13px;box-shadow:none;",e.textContent="BetterView: open Settings > Customize > Custom and paste (copied)",document.body.appendChild(e),setTimeout(()=>e.remove(),6e3)}catch{}}async function Hn(){try{const e=()=>{const f=document.querySelector(Te.customizeRegion);if(f)return f;const g=document.querySelectorAll('h1, h2, h3, [role="heading"]');for(const b of Array.from(g))if(/^customize$/i.test((b.textContent??"").trim()))return b.closest('[role="region"], section, form')??b.parentElement?.parentElement??b.parentElement;return null};let t=null;for(let f=0;f<24;f++){t=e();const g=!!Le(/^settings$/i)||!!Le(/^customize(?: grok's response)?$/i)||!!document.querySelector(Te.accountMenu)||!!Le(/^(open )?(account|profile|menu|navigation menu)$/i);if(t||g)break;await new Promise(b=>setTimeout(b,250))}if(!t){let f=Le(/^settings$/i),g=Le(/^customize(?: grok's response)?$/i);const b=document.querySelector(Te.accountMenu)??Le(/^(open )?(account|profile|menu|navigation menu)$/i);if(!f&&!g&&b){b.click();const m=Date.now();for(;!f&&Date.now()-m<5e3;)f=Le(/^settings$/i),f||await new Promise(C=>setTimeout(C,200))}if(f&&f.click(),f||b||g){const m=Date.now();for(;!g&&Date.now()-m<7e3;)g=Le(/^customize(?: grok's response)?$/i),g||await new Promise(v=>setTimeout(v,250));g&&g.click();const C=Date.now();for(;!t&&Date.now()-C<8e3;)await new Promise(v=>setTimeout(v,250)),t=e()}}if(!t){Ie();const f="Couldn't find Customize settings";return console.warn("[BetterView]",f),{status:"failed",error:f}}const i=t.querySelector(Te.dropdown)??t.querySelector('[role="combobox"]');if(i&&!/custom/i.test(i.textContent??"")){i.click(),await new Promise(g=>setTimeout(g,300));const f=document.querySelectorAll(Te.menuitemRadio);for(const g of Array.from(f))if(/^custom$/i.test(g.textContent?.trim()??"")){g.click();break}await new Promise(g=>setTimeout(g,300))}const n=t.querySelector(Te.textarea);if(!n){Ie();const f="Couldn't find instructions textarea";return console.warn("[BetterView]",f),{status:"failed",error:f}}const o=Ke(n.value),r=jt(n.value);if(o!==null&&o>=12)return{status:"already",version:o,hasOldEntry:r};const a=nr(n.value,dt());if(n.maxLength>0&&a.length>n.maxLength){Ie();const f="Not enough room in Grok's custom instructions";console.warn("[BetterView]",f);const g={status:"failed",error:f};return ce("grok",g),g}const s=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value");s?.set?s.set.call(n,a):n.value=a,n.dispatchEvent(new Event("input",{bubbles:!0})),n.dispatchEvent(new Event("change",{bubbles:!0}));let l=null;const c=t.querySelectorAll(Te.saveButton);for(const f of Array.from(c))if(/^save$/i.test(f.textContent?.trim()??"")||/save/i.test(f.getAttribute("aria-label")??"")){l=f;break}if(!l){Ie();const f="Couldn't find Save button";console.warn("[BetterView]",f);const g={status:"failed",error:f};return ce("grok",g),g}for(let f=0;f<10&&!(!l.disabled&&!l.hasAttribute("disabled"));f++)await new Promise(g=>setTimeout(g,500));if(l.disabled){Ie();const f="Save button remained disabled";console.warn("[BetterView]",f);const g={status:"failed",error:f};return ce("grok",g),g}l.click();let d=!1;const p=Date.now();for(;Date.now()-p<2500;){await new Promise(C=>setTimeout(C,200));const f=(t.textContent??"").replace(/\s+/g," ");if(/couldn't save|failed to save|something went wrong/i.test(f))break;const g=t.querySelector(Te.textarea),b=g?.isConnected?g.value:"",m=/(?:instructions|changes|settings) (?:saved|updated)|saved successfully/i.test(f);if((ir(b)||m)&&Date.now()-p>=1e3){d=!0;break}}if(!d){Ie();const f="Grok didn't save";console.warn("[BetterView]",f);const g={status:"failed",error:f};return ce("grok",g),g}const h={status:"added",version:12,hasOldEntry:jt(n.value)};return ce("grok",h),h}catch(e){Ie();const t=e instanceof Error?e.message:String(e);console.warn("[BetterView]","Grok setup error:",t);const i={status:"failed",error:t};return ce("grok",i),i}}function ce(e,t,i){const n=typeof t=="string"?t:t.status,o=typeof t=="string"?i:t.error??i,r=typeof t=="object"&&t.version!==void 0?t.version:12,a=typeof t=="object"?t.hasOldEntry:void 0;typeof chrome<"u"&&chrome.storage?.local&&chrome.storage.local.set({[`${e}_setup_status`]:{status:n,version:r,error:o,hasOldEntry:a,timestamp:Date.now()}})}var Fe={renderEnabled:!0,autoInject:!1,theme:"auto",watermark:!0};function ti(){return new Promise(e=>{if(typeof chrome>"u"||!chrome.storage||!chrome.storage.sync){e({...Fe});return}chrome.storage.sync.get({...Fe},t=>{if(chrome.runtime?.lastError){e({...Fe});return}e({renderEnabled:typeof t.renderEnabled=="boolean"?t.renderEnabled:Fe.renderEnabled,autoInject:typeof t.autoInject=="boolean"?t.autoInject:Fe.autoInject,theme:t.theme==="light"||t.theme==="dark"||t.theme==="auto"?t.theme:Fe.theme,watermark:typeof t.watermark=="boolean"?t.watermark:Fe.watermark})})})}function Wn(e){if(typeof chrome>"u"||!chrome.storage||!chrome.storage.onChanged)return()=>{};const t=(i,n)=>{n==="sync"&&ti().then(e).catch(()=>{})};return chrome.storage.onChanged.addListener(t),()=>{chrome.storage.onChanged.removeListener(t)}}function Oe(){if(typeof document>"u")return"light";const e=document.documentElement,t=document.body,i=t?.getAttribute("data-theme")||t?.getAttribute("data-color-scheme");if(i==="dark"||i==="light")return i;if(t?.classList.contains("dark-theme")||t?.classList.contains("dark")||e?.hasAttribute("dark")||e?.classList.contains("dark")||e?.classList.contains("dark-theme"))return"dark";if(t?.classList.contains("light")||e?.classList.contains("light"))return"light";const n=e?.getAttribute("data-theme")||e?.getAttribute("data-color-scheme");if(n==="dark"||n==="light")return n;function o(s){if(!s||s==="transparent")return null;const l=s.match(/rgba?\(\s*([0-9.]+)\s*,\s*([0-9.]+)\s*,\s*([0-9.]+)(?:\s*,\s*([0-9.]+))?\s*\)/);return!l||(l[4]!==void 0?parseFloat(l[4]):1)===0?null:{r:parseFloat(l[1]),g:parseFloat(l[2]),b:parseFloat(l[3])}}const r=[document.querySelector("main"),document.querySelector('[role="main"]'),document.querySelector("app-root"),t,e].filter(s=>s instanceof HTMLElement);let a=null;for(const s of r){const l=window.getComputedStyle?.(s),c=o(l?.backgroundColor||"");if(c){a=c;break}const d=(l?.colorScheme||"").trim().split(/\s+/);if(d.includes("dark")&&!d.includes("light"))return"dark";if(d.includes("light")&&!d.includes("dark"))return"light"}return a?(.2126*a.r+.7152*a.g+.0722*a.b)/255<.5?"dark":"light":typeof window<"u"&&window.matchMedia&&window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"}function ur(e){let t=Oe();const i=()=>{const a=Oe();a!==t&&(t=a,e(a))},n=typeof MutationObserver<"u"?new MutationObserver(i):null,o={attributes:!0,attributeFilter:["class","style","dark","data-theme","data-color-scheme"]};if(n&&typeof document<"u"){document.documentElement&&n.observe(document.documentElement,{...o,subtree:!0}),document.body&&n.observe(document.body,o);const a=document.querySelector('main, [role="main"], app-root');a&&a!==document.body&&a!==document.documentElement&&n.observe(a,o)}const r=typeof window<"u"&&window.matchMedia?window.matchMedia("(prefers-color-scheme: dark)"):null;return r&&r.addEventListener("change",i),()=>{n&&n.disconnect(),r&&r.removeEventListener("change",i)}}function Ce(e,t=!1){const i=e.success??(t?"#34D399":"#16A34A"),n=e.successBg??(t?"rgba(52, 211, 153, 0.16)":"rgba(22, 163, 74, 0.12)"),o=e.danger??(t?"#F87171":"#DC2626"),r=e.dangerBg??(t?"rgba(248, 113, 113, 0.16)":"rgba(220, 38, 38, 0.10)"),a=e.warning??(t?"#FBBF24":"#D97706"),s=e.info??(t?"#60A5FA":"#2563EB"),l=e.shadowFloat??(t?"0 8px 28px rgba(0, 0, 0, 0.45)":"0 8px 24px rgba(0, 0, 0, 0.12)"),c=e.radiusPill??"999px",d=e.ease??"cubic-bezier(.2,.8,.2,1)",p=e.durFast??"120ms",h=e.durMed??"200ms";return{bg:e.bg,"--iui-bg":e.bg,surface:e.surface,"--iui-surface":e.surface,"surface-2":e.surface2,surface2:e.surface2,"--iui-surface-2":e.surface2,border:e.border,"--iui-border":e.border,text:e.text,"--iui-text":e.text,muted:e.muted,"--iui-muted":e.muted,subtle:e.subtle,"--iui-subtle":e.subtle,accent:e.accent,"--iui-accent":e.accent,"accent-bg":e.accentBg,accentBg:e.accentBg,"--iui-accent-bg":e.accentBg,"--iui-success":i,"--iui-success-bg":n,"--iui-danger":o,"--iui-danger-bg":r,"--iui-warning":a,"--iui-info":s,"--iui-shadow-float":l,"radius-card":e.radiusCard,radiusCard:e.radiusCard,"--iui-radius-card":e.radiusCard,"radius-inner":e.radiusInner,radiusInner:e.radiusInner,"--iui-radius-inner":e.radiusInner,"--iui-radius-pill":c,"--iui-ease":d,"--iui-dur-fast":p,"--iui-dur-med":h,font:e.font,"--iui-font":e.font,mono:e.mono,"--iui-mono":e.mono}}var pr={gemini:{light:Ce({bg:"#FFFFFF",surface:"#F0F4F9",surface2:"#E9EEF6",border:"#E1E3E1",text:"#1F1F1F",muted:"#444746",subtle:"#747775",accent:"#0B57D0",accentBg:"#D3E3FD",radiusCard:"12px",radiusInner:"8px",font:'"Google Sans Text", "Google Sans", Roboto, Arial, sans-serif',mono:'"Google Sans Mono", "Roboto Mono", ui-monospace, monospace'},!1),dark:Ce({bg:"#131314",surface:"#1E1F20",surface2:"#282A2C",border:"#3C4043",text:"#E3E3E3",muted:"#C4C7C5",subtle:"#8E918F",accent:"#A8C7FA",accentBg:"rgba(8,66,160,.4)",radiusCard:"12px",radiusInner:"8px",font:'"Google Sans Text", "Google Sans", Roboto, Arial, sans-serif',mono:'"Google Sans Mono", "Roboto Mono", ui-monospace, monospace'},!0)},grok:{light:Ce({bg:"#FFFFFF",surface:"#FAFAFA",surface2:"#F2F2F2",border:"rgba(0, 0, 0, 0.12)",text:"#0D0D0D",muted:"#6B6B6B",subtle:"#9A9A9A",accent:"#0D0D0D",accentBg:"#F2F2F2",radiusCard:"12px",radiusInner:"8px",font:'ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',mono:'ui-monospace, "SF Mono", Menlo, Consolas, monospace'},!1),dark:Ce({bg:"#141414",surface:"#1C1C1C",surface2:"#242424",border:"rgba(255, 255, 255, 0.12)",text:"#F5F5F5",muted:"#A3A3A3",subtle:"#737373",accent:"#F5F5F5",accentBg:"#262626",radiusCard:"12px",radiusInner:"8px",font:'ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif',mono:'ui-monospace, "SF Mono", Menlo, Consolas, monospace'},!0)},chatgpt:{light:Ce({bg:"#FFFFFF",surface:"#F9F9FB",surface2:"#F1F2F6",border:"rgba(15, 23, 42, 0.10)",text:"#0D0D0D",muted:"#5D6370",subtle:"#8E95A2",accent:"#10A37F",accentBg:"rgba(16, 163, 127, 0.12)",radiusCard:"12px",radiusInner:"8px",font:'-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',mono:"ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace"},!1),dark:Ce({bg:"#212121",surface:"#2F2F2F",surface2:"#383838",border:"rgba(255, 255, 255, 0.12)",text:"#ECECEC",muted:"#B4B4B4",subtle:"#8E8E8E",accent:"#10A37F",accentBg:"rgba(16, 163, 127, 0.20)",radiusCard:"12px",radiusInner:"8px",font:'-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',mono:"ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace"},!0)},claude:{light:Ce({bg:"#FAF9F5",surface:"#F0EEE6",surface2:"#E6E3D8",border:"rgba(61, 57, 41, 0.14)",text:"#141413",muted:"#5E5D59",subtle:"#87867F",accent:"#D97757",accentBg:"rgba(217, 119, 87, 0.14)",radiusCard:"12px",radiusInner:"8px",font:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',mono:"ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace"},!1),dark:Ce({bg:"#262624",surface:"#30302E",surface2:"#3A3A37",border:"rgba(255, 250, 235, 0.12)",text:"#FAF9F5",muted:"#C2C0B6",subtle:"#8C8A80",accent:"#D97757",accentBg:"rgba(217, 119, 87, 0.22)",radiusCard:"12px",radiusInner:"8px",font:'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',mono:"ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace"},!0)}},hr={light:Ce({bg:"#FFFFFF",surface:"#FAFAFA",surface2:"#F4F4F5",border:"rgba(0, 0, 0, 0.12)",text:"#0A0A0A",muted:"#6B6B6B",subtle:"#A3A3A3",accent:"#0A0A0A",accentBg:"#F4F4F5",radiusCard:"12px",radiusInner:"8px",font:'Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',mono:"ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace"},!1),dark:Ce({bg:"#0f0f10",surface:"#18181A",surface2:"#222225",border:"rgba(255, 255, 255, 0.12)",text:"#FAFAFA",muted:"#A3A3A3",subtle:"#71717A",accent:"#FAFAFA",accentBg:"#27272A",radiusCard:"12px",radiusInner:"8px",font:'Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',mono:"ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace"},!0)};function fr(e,t){return e==="gemini"||e==="grok"||e==="chatgpt"||e==="claude"?pr[e][t]:hr[t]}function mi(e){try{if(!e||typeof window>"u"||!window.getComputedStyle)return{};const t='message-content, .message-content, .markdown, .response-content-markdown, [class*="markdown"], .prose';let i=null;if(typeof e.closest=="function"&&(i=e.closest(t)),i||(i=e.parentElement||e),!i)return{};const n=window.getComputedStyle(i);if(!n)return{};const o=s=>{if(!s)return;const l=s.trim();if(!(!l||l==="inherit"||l==="initial"||l==="unset"))return l};let r=i,a;for(;r&&r!==document.documentElement;){const s=o(window.getComputedStyle(r)?.backgroundColor);if(s&&s!=="transparent"&&s!=="rgba(0, 0, 0, 0)"){a=s;break}r=r.parentElement}return{fontFamily:o(n.fontFamily),fontSize:o(n.fontSize),lineHeight:o(n.lineHeight),color:o(n.color),backgroundColor:a}}catch{return{}}}function tt(e){if(!e)return null;const t=e.trim().toLowerCase();if(t==="transparent")return{r:0,g:0,b:0,a:0};if(t==="white")return{r:255,g:255,b:255,a:1};if(t==="black")return{r:0,g:0,b:0,a:1};if(t.startsWith("#")){const c=t.slice(1);if(c.length===3||c.length===4){const d=[0,1,2].map(h=>parseInt(c[h]+c[h],16));if(d.some(h=>!Number.isFinite(h)))return null;const p=c.length===4?parseInt(c[3]+c[3],16)/255:1;return{r:d[0],g:d[1],b:d[2],a:p}}if(c.length===6||c.length===8){const d=[0,2,4].map(h=>parseInt(c.slice(h,h+2),16));if(d.some(h=>!Number.isFinite(h)))return null;const p=c.length===8?parseInt(c.slice(6,8),16)/255:1;return{r:d[0],g:d[1],b:d[2],a:p}}return null}const i=t.match(/^rgba?\((.*)\)$/);if(!i)return null;const n=i[1].split("/");if(n.length>2)return null;const o=n[0].includes(",")?n[0].split(",").map(c=>c.trim()):n[0].trim().split(/\s+/);let r=n[1]?.trim();if(o.length===4&&!r){const c=o.pop();if(c===void 0)return null;r=c}if(o.length!==3)return null;const a=c=>{const d=Number.parseFloat(c);if(!Number.isFinite(d))return null;const p=c.endsWith("%")?d*255/100:d;return Math.max(0,Math.min(255,p))},s=o.map(a);if(s.some(c=>c===null))return null;let l=1;if(r!==void 0){const c=Number.parseFloat(r);if(!Number.isFinite(c))return null;l=Math.max(0,Math.min(1,r.endsWith("%")?c/100:c))}return{r:s[0],g:s[1],b:s[2],a:l}}function bi(e){const[t,i,n]=[e.r/255,e.g/255,e.b/255].map(o=>o<=.03928?o/12.92:Math.pow((o+.055)/1.055,2.4));return .2126*t+.7152*i+.0722*n}function xi(e,t){return{r:e.r*e.a+t.r*(1-e.a),g:e.g*e.a+t.g*(1-e.a),b:e.b*e.a+t.b*(1-e.a)}}function gr(e,t,i="#FFFFFF"){const n=tt(e),o=tt(t),r=tt(i);if(!n||!o||!r)return 1;const a=xi(o,r),s=bi(xi(n,{...a,a:1})),l=bi(a);return(Math.max(s,l)+.05)/(Math.min(s,l)+.05)}function vi(e,t,i,n){const o=fr(t,i),r=n?.backgroundColor,a=r?tt(r):null,s=r&&a&&a.a>0?r:o.bg;e.style.setProperty("--iui-bg",s),e.style.setProperty("--iui-surface",o.surface),e.style.setProperty("--iui-surface-2",o["surface-2"]),e.style.setProperty("--iui-border",o.border),e.style.setProperty("--iui-muted",o.muted),e.style.setProperty("--iui-subtle",o.subtle),e.style.setProperty("--iui-accent",o.accent),e.style.setProperty("--iui-accent-bg",o["accent-bg"]),e.style.setProperty("--iui-success",o["--iui-success"]),e.style.setProperty("--iui-success-bg",o["--iui-success-bg"]),e.style.setProperty("--iui-danger",o["--iui-danger"]),e.style.setProperty("--iui-danger-bg",o["--iui-danger-bg"]),e.style.setProperty("--iui-warning",o["--iui-warning"]),e.style.setProperty("--iui-info",o["--iui-info"]),e.style.setProperty("--iui-shadow-float",o["--iui-shadow-float"]),e.style.setProperty("--iui-radius-card",o["radius-card"]),e.style.setProperty("--iui-radius-inner",o["radius-inner"]),e.style.setProperty("--iui-radius-pill",o["--iui-radius-pill"]),e.style.setProperty("--iui-ease",o["--iui-ease"]),e.style.setProperty("--iui-dur-fast",o["--iui-dur-fast"]),e.style.setProperty("--iui-dur-med",o["--iui-dur-med"]),e.style.setProperty("--iui-mono",o.mono);const l=n?.fontFamily&&n.fontFamily!=="inherit"&&n.fontFamily!=="initial"?n.fontFamily:o.font;e.style.setProperty("--iui-font",l),n?.fontSize&&n.fontSize!=="inherit"?e.style.setProperty("--iui-fs",n.fontSize):e.style.setProperty("--iui-fs",t==="gemini"?"15px":"13.5px"),n?.lineHeight&&n.lineHeight!=="inherit"?e.style.setProperty("--iui-lh",n.lineHeight):e.style.setProperty("--iui-lh","1.55");let c=o.text;if(n?.color){const d=t==="gemini"?o.surface:s;gr(n.color,d,o.bg)>=4.5&&(c=n.color)}e.style.setProperty("--iui-text",c)}function mr(e){let t=e.trim();if(!t)return"";const i=t.indexOf(`
`),n=(i!==-1?t.slice(0,i):t).trim();return(n==="ui"||n==="json"||n.startsWith("```"))&&(t=i!==-1?t.slice(i+1).trim():""),t.endsWith("```")&&(t=t.slice(0,-3).trim()),t}function wi(e){let t=e.trim();if(!t)return null;const i=[];let n=!1,o=!1;for(let r=0;r<t.length;r++){const a=t[r];if(n){o?o=!1:a==="\\"?o=!0:a==='"'&&(n=!1);continue}a==='"'?(n=!0,o=!1):a==="{"||a==="["?i.push(a):a==="}"?i.length>0&&i[i.length-1]==="{"&&i.pop():a==="]"?i.length>0&&i[i.length-1]==="["&&i.pop():/\s/.test(a)}n&&o&&(t=t.slice(0,-1)),n&&(t+='"'),t=t.trim(),t=t.replace(/,\s*$/,""),/:\s*$/.test(t)&&(t+='""'),t=t.replace(/,\s*$/,"");for(let r=i.length-1;r>=0;r--){const a=i[r];t=t.replace(/,\s*$/,""),a==="{"?(/:\s*$/.test(t)&&(t+='""'),t+="}"):t+="]"}return t}function yi(e){const t=mr(e);if(!t)return{ok:!1,error:"Empty input"};try{return{ok:!0,value:JSON.parse(t)}}catch{}let i=wi(t);if(i)try{return{ok:!0,value:JSON.parse(i)}}catch{}let n=t;for(let o=0;o<8;o++){const r=n.lastIndexOf(","),a=n.lastIndexOf("{"),s=n.lastIndexOf("["),l=Math.max(r,a,s);if(l<=0)break;l===r?n=n.slice(0,l).trim():n=n.slice(0,l+1).trim();const c=wi(n);if(c)try{return{ok:!0,value:JSON.parse(c)}}catch{}}return{ok:!1,error:"Could not recover partial JSON"}}var ki=["blue","green","orange","purple","amber","red"];function br(e){let t=0;for(let i=0;i<e.length;i++)t=(t<<5)-t+e.charCodeAt(i)|0;return Math.abs(t)}function Nt(e,t){if(typeof e=="string"){const n=e.trim().toLowerCase();if(n==="yellow")return"amber";if(n==="grey")return"gray";if(Ro.includes(n))return n}const i=br(t)%ki.length;return ki[i]}function N(e,t=300){return typeof e=="number"&&(e=String(e)),typeof e!="string"?"":e.trim().slice(0,t)}function xr(e,t){const i=Array.isArray(e.nodes)?e.nodes:[];if(i.length===0)return{ok:!1,error:"flow must have at least 1 node"};const n=new Map;if(Array.isArray(e.groups)){for(const c of e.groups)if(c&&typeof c=="object"){const d=N(c.id),p=N(c.label);if(d&&p){const h=c.color,f=h!==void 0?Nt(h,d||p):void 0;n.set(d,{id:d,label:p,...f?{color:f}:{}})}}}const o=new Map;for(const c of i){if(!c||typeof c!="object")continue;const d=c,p=N(d.id),h=N(d.label??d.title);if(!p||!h)return{ok:!1,error:"Node must have non-empty id and label"};if(o.has(p)){t.push(`Duplicate node id "${p}" dropped`);continue}if(o.size>=60){t.push("Nodes capped at 60");break}const f=N(d.sub??d.subtitle??d.description),g=N(d.detail,600),b=N(d.icon),m=d.color,C=m!==void 0?Nt(m,p||h):void 0;let v=N(d.group);v&&!n.has(v)&&(t.push(`Group "${v}" not found for node "${p}"`),v="");const w=typeof d.decision=="boolean"?d.decision:void 0;o.set(p,{id:p,label:h,...f?{sub:f}:{},...g?{detail:g}:{},...b?{icon:b}:{},...C?{color:C}:{},...v?{group:v}:{},...w!==void 0?{decision:w}:{}})}if(o.size===0)return{ok:!1,error:"flow must have at least 1 valid node"};const r=Array.isArray(e.edges)?e.edges:[],a=[];for(const c of r){if(!c||typeof c!="object")continue;const d=c,p=N(d.from),h=N(d.to);if(!p||!h)continue;if(p===h){t.push(`Dropped self-loop edge on "${p}"`);continue}if(!o.has(p))if(o.size<60)o.set(p,{id:p,label:p}),t.push(`Created missing node "${p}" referenced in edge`);else{t.push(`Could not create missing node "${p}": node limit reached`);continue}if(!o.has(h))if(o.size<60)o.set(h,{id:h,label:h}),t.push(`Created missing node "${h}" referenced in edge`);else{t.push(`Could not create missing node "${h}": node limit reached`);continue}const f=N(d.label),g=N(d.tone).toLowerCase(),b=g==="positive"||g==="negative"||g==="neutral"?g:void 0;if(a.push({from:p,to:h,...f?{label:f}:{},...b?{tone:b}:{}}),a.length>=120){t.push("Edges capped at 120");break}}const s=Array.from(o.values()),l=Array.from(n.values());return{ok:!0,spec:{type:"flow",nodes:s,edges:a,...l.length>0?{groups:l}:{}}}}function vr(e,t){let i=Array.isArray(e.steps)?e.steps:[];if(i.length===0)return{ok:!1,error:"stepper must have at least 1 step"};i.length>20&&(t.push("Steps capped at 20"),i=i.slice(0,20));const n=[];for(const o of i){if(!o||typeof o!="object")return{ok:!1,error:"Step must be an object"};const r=o,a=N(r.title);if(!a)return{ok:!1,error:"Step title is required"};const s=N(r.detail??r.description);n.push({title:a,...s?{detail:s}:{}})}return{ok:!0,spec:{type:"stepper",steps:n}}}function wr(e,t){const i=Array.isArray(e.columns)?e.columns:[];if(i.length===0)return{ok:!1,error:"table must have at least 1 column"};let n=i.map((s,l)=>N(s)||`Column ${l+1}`);n.length>12&&(t.push("Columns capped at 12"),n=n.slice(0,12));const o=n.length;let r=Array.isArray(e.rows)?e.rows:[];r.length>50&&(t.push("Rows capped at 50"),r=r.slice(0,50));const a=[];for(const s of r){const l=(Array.isArray(s)?s:[]).slice(0,o).map(c=>N(c));for(;l.length<o;)l.push("");a.push(l)}return{ok:!0,spec:{type:"table",columns:n,rows:a}}}function yr(e,t){let i=Array.isArray(e.items)?e.items:Array.isArray(e.panels)?e.panels:[];if(i.length===0)return{ok:!1,error:"compare must have 1-4 items"};i.length>4&&(t.push("Compare items capped at 4"),i=i.slice(0,4));const n=[];for(const o of i){if(!o||typeof o!="object")return{ok:!1,error:"Compare item must be an object"};const r=o,a=N(r.label??r.title);if(!a)return{ok:!1,error:"Compare item must have a label"};let s=N(r.tone).toLowerCase();s!=="good"&&s!=="bad"&&s!=="neutral"&&(s="neutral");const l=N(r.badge,60);let c=Array.isArray(r.points)?r.points:[];c.length>12&&(t.push("Compare points capped at 12"),c=c.slice(0,12));const d=c.map(p=>N(p)).filter(Boolean);n.push({label:a,tone:s,...l?{badge:l}:{},points:d})}return{ok:!0,spec:{type:"compare",items:n}}}function kr(e,t){let i=Array.isArray(e.questions)?e.questions:Array.isArray(e.items)?e.items:Array.isArray(e.quiz)?e.quiz:[];if(i.length===0)return{ok:!1,error:"quiz must have 1-20 questions"};i.length>20&&(t.push("Quiz questions capped at 20"),i=i.slice(0,20));const n=[];for(const o of i){if(!o||typeof o!="object")return{ok:!1,error:"Quiz question must be an object"};const r=o,a=N(r.q??r.question??r.prompt??r.title);if(!a)return{ok:!1,error:"Quiz question text is required"};const s=(Array.isArray(r.options)?r.options:Array.isArray(r.choices)?r.choices:Array.isArray(r.answers)?r.answers:[]).map(p=>{if(typeof p=="string")return N(p);if(p&&typeof p=="object"){const h=p;return N(h.text??h.option??h.label??h.value)}return""}).filter(Boolean);if(s.length<2||s.length>8)return{ok:!1,error:"Quiz question must have 2 to 8 options"};let l=r.answer??r.correctAnswer??r.correct??r.correctIndex??r.solution,c;if(typeof l=="number"&&Number.isInteger(l))if(l>=0&&l<s.length)c=l;else{const p=s.findIndex(h=>h.trim()===String(l).trim());c=p>=0?p:l}else if(typeof l=="string"){const p=l.trim(),h=s.findIndex(f=>f.trim().toLowerCase()===p.toLowerCase());if(h>=0)c=h;else if(/^[a-hA-H]$/.test(p)){const f=p.toUpperCase().charCodeAt(0)-65;f>=0&&f<s.length&&(c=f)}else{const f=p.match(/^(?:option\s+|choice\s+)?([a-hA-H])(?:[\)\.\:\s]|$)/i);if(f){const g=f[1].toUpperCase().charCodeAt(0)-65;g>=0&&g<s.length&&(c=g)}if(c===void 0)if(/^\d+$/.test(p)){const g=parseInt(p,10);g>=0&&g<s.length,c=g}else{const g=s.findIndex(b=>{const m=b.trim().toLowerCase(),C=p.toLowerCase();return m.length>3&&C.length>3&&(m.includes(C)||C.includes(m))});g>=0&&(c=g)}}}if(c===void 0||typeof c!="number"||!Number.isInteger(c)||c<0||c>=s.length)return{ok:!1,error:`Quiz answer must be an integer between 0 and ${s.length-1}`};const d=N(r.explain??r.explanation??r.rationale??r.reason);n.push({q:a,options:s,answer:c,...d?{explain:d}:{}})}return{ok:!0,spec:{type:"quiz",questions:n}}}function Cr(e,t){let i=N(e.chartType).toLowerCase();["bar","line","area","pie","doughnut","radar","scatter","bubble","heatmap","geo"].includes(i)||(t.push(`Invalid chartType "${e.chartType}", defaulting to bar`),i="bar");const n=i==="scatter"||i==="bubble"||i==="geo",o=Array.isArray(e.labels)?e.labels:[],r=i==="heatmap"?18:12,a=o.slice(0,r).map((b,m)=>N(b)||`Item ${m+1}`);if(o.length>r&&t.push(`Chart labels capped at ${r}`),!n&&a.length===0)return{ok:!1,error:"chart must have at least 1 label"};let s=Array.isArray(e.datasets)?e.datasets:[];if(s.length===0)return{ok:!1,error:"chart must have at least 1 dataset"};const l=i==="heatmap"?20:12;s.length>l&&(t.push(`Datasets capped at ${l}`),s=s.slice(0,l));const c=[];let d=0;const p=b=>{if(typeof b!="number"&&typeof b!="string"||typeof b=="string"&&!b.trim())return null;const m=Number(b);return Number.isFinite(m)?m:null};for(const b of s){if(!b||typeof b!="object"||Array.isArray(b))return{ok:!1,error:"Chart dataset must be an object"};const m=b,C=N(m.label)||"Dataset";if(!Array.isArray(m.data))return{ok:!1,error:"Chart dataset must have a data array"};const v=[];if(i==="scatter"||i==="bubble")for(const w of m.data.slice(0,100)){if(!w||typeof w!="object"||Array.isArray(w))return{ok:!1,error:"Scatter and bubble data must use {x,y} points"};const x=w,y=p(x.x),k=p(x.y),A=x.r===void 0?null:p(x.r);if(y===null||k===null||x.r!==void 0&&(A===null||A<=0))return{ok:!1,error:"Scatter and bubble points require finite x and y values (and a positive r when supplied)"};if(i==="bubble"&&A===null)return{ok:!1,error:"Bubble points require a positive r value"};v.push({x:y,y:k,...A!==null?{r:A}:{},...N(x.label)?{label:N(x.label)}:{}})}else if(i==="geo")for(const w of m.data.slice(0,60)){if(!w||typeof w!="object"||Array.isArray(w))return{ok:!1,error:"Geographic chart points must be objects with latitude and longitude"};const x=w,y=p(x.lon??x.longitude??x.x),k=p(x.lat??x.latitude??x.y),A=x.value===void 0?null:p(x.value);if(y===null||k===null||y<-180||y>180||k<-90||k>90||x.value!==void 0&&A===null)return{ok:!1,error:"Geographic points need longitude in [-180,180], latitude in [-90,90], and a finite optional value"};v.push({x:y,y:k,...A!==null?{value:A}:{},...N(x.label??x.name??x.location)?{label:N(x.label??x.name??x.location)}:{}})}else{for(const w of m.data){const x=p(w);if(x===null)return{ok:!1,error:"Invalid chart data: NaN encountered"};v.push(x)}if(v.length>a.length)v.splice(a.length);else for(;v.length<a.length;)v.push(0)}if(v.length===0)return{ok:!1,error:"Chart dataset must contain at least one data point"};if(d+=v.length,i==="geo"&&d>120)return{ok:!1,error:"Geographic charts are capped at 120 locations"};c.push({label:C,data:v})}const h=N(e.unit),f=N(e.xLabel),g=N(e.yLabel);return{ok:!0,spec:{type:"chart",chartType:i,labels:a,datasets:c,...h?{unit:h}:{},...f?{xLabel:f}:{},...g?{yLabel:g}:{}}}}function Er(e){const t=N(e.code,8e3);return t?{ok:!0,spec:{type:"mermaid",code:t}}:{ok:!1,error:"mermaid must have non-empty code"}}function Sr(e,t){const i=N(e.text??e.body??e.message,1200);if(!i)return{ok:!1,error:"callout must have non-empty text"};let n=N(e.tone).toLowerCase();["info","success","warning","tip"].includes(n)||(t.push(`Invalid callout tone "${e.tone}", defaulting to info`),n="info");const o=N(e.icon);return{ok:!0,spec:{type:"callout",tone:n,text:i,...o?{icon:o}:{}}}}function Ar(e,t){let i=Array.isArray(e.items)?e.items:Array.isArray(e.stats)?e.stats:[];if(i.length<2)return{ok:!1,error:"stats must have 2-4 metric cards"};i.length>4&&(t.push("Stats items capped at 4"),i=i.slice(0,4));const n=[];for(const o of i){if(!o||typeof o!="object")return{ok:!1,error:"Stat item must be an object"};const r=o,a=N(r.label??r.title);if(!a)return{ok:!1,error:"Stat item must have a label"};const s=r.value,l=typeof s=="number"?s:N(s);if(l===""&&typeof s!="number")return{ok:!1,error:"Stat item must have a value"};const c=N(r.delta??r.change),d=N(r.hint??r.sub??r.detail),p=N(r.icon),h=N(r.tone).toLowerCase(),f=h==="good"||h==="bad"||h==="neutral"?h:void 0;let g;if(Array.isArray(r.sparkline)){const b=r.sparkline.filter(m=>typeof m=="number"&&Number.isFinite(m)).slice(0,24);b.length>=2&&(g=b)}n.push({label:a,value:l,...c?{delta:c}:{},...d?{hint:d}:{},...p?{icon:p}:{},...g?{sparkline:g}:{},...f?{tone:f}:{}})}return{ok:!0,spec:{type:"stats",items:n}}}function Mr(e,t){let i=Array.isArray(e.tabs)?e.tabs:[];if(i.length===0)return{ok:!1,error:"tabs must have at least 1 tab"};i.length>8&&(t.push("Tabs capped at 8"),i=i.slice(0,8));const n=[];for(const o of i){if(!o||typeof o!="object")return{ok:!1,error:"Tab must be an object"};const r=o,a=N(r.label??r.title);if(!a)return{ok:!1,error:"Tab must have a label"};let s="";Array.isArray(r.content)?s=r.content.map(l=>N(l)).filter(Boolean):s=N(r.content??r.text??r.body,3e3),n.push({label:a,content:s})}return{ok:!0,spec:{type:"tabs",tabs:n}}}function Tr(e,t){let i=Array.isArray(e.events)?e.events:Array.isArray(e.steps)?e.steps:[];if(i.length===0)return{ok:!1,error:"timeline must have at least 1 event"};i.length>20&&(t.push("Timeline events capped at 20"),i=i.slice(0,20));const n=[];for(const o of i){if(!o||typeof o!="object")return{ok:!1,error:"Timeline event must be an object"};const r=o,a=N(r.title??r.label);if(!a)return{ok:!1,error:"Timeline event must have a title"};const s=N(r.text??r.detail??r.description),l=N(r.time??r.date??r.timestamp),c=N(r.icon),d=N(r.status).toLowerCase(),p=d==="done"||d==="active"||d==="upcoming"?d:void 0;n.push({title:a,text:s,...l?{time:l}:{},...c?{icon:c}:{},...p?{status:p}:{}})}return{ok:!0,spec:{type:"timeline",events:n}}}function Lr(e,t){const i=(Array.isArray(e.suggestions)?e.suggestions:Array.isArray(e.items)?e.items:Array.isArray(e.chips)?e.chips:[]).map(n=>N(n)).filter(Boolean);return i.length<2?{ok:!1,error:"followups must have 2-4 suggestion chips"}:(i.length>4&&(t.push("Followup suggestions capped at 4"),i.splice(4)),{ok:!0,spec:{type:"followups",suggestions:i}})}function zr(e,t){const i=N(e.latex,8e3);if(!i)return{ok:!1,error:"math must have non-empty latex"};let n;if(Array.isArray(e.steps)){n=[];for(const o of e.steps)if(o&&typeof o=="object"){const r=N(o.latex,4e3);if(r){const a=N(o.note,500);n.push({latex:r,...a?{note:a}:{}})}}n.length>30&&(t.push("Math steps capped at 30"),n=n.slice(0,30))}return{ok:!0,spec:{type:"math",latex:i,...n&&n.length>0?{steps:n}:{}}}}function _r(e,t){const i=e.code,n=typeof i=="string"?i:"";if(!n.trim())return{ok:!1,error:"code must have non-empty code"};const o=N(e.language??e.lang)||"text",r=N(e.filename??e.file);return{ok:!0,spec:{type:"code",language:o,code:n,...r?{filename:r}:{}}}}function Br(e,t){let i=Array.isArray(e.items)?e.items:Array.isArray(e.tasks)?e.tasks:[];if(i.length===0)return{ok:!1,error:"checklist must have at least 1 item"};i.length>40&&(t.push("Checklist items capped at 40"),i=i.slice(0,40));const n=[];for(const o of i){if(typeof o=="string"){const l=N(o,500);l&&n.push({text:l});continue}if(!o||typeof o!="object")continue;const r=o,a=N(r.text??r.title??r.label,500);if(!a)continue;const s=N(r.detail??r.description,800);n.push({text:a,...s?{detail:s}:{},...typeof r.checked=="boolean"?{checked:r.checked}:{}})}return n.length===0?{ok:!1,error:"checklist must have at least 1 valid item"}:{ok:!0,spec:{type:"checklist",items:n}}}function Ir(e,t){let i=Array.isArray(e.fields)?e.fields:[];if(i.length===0)return{ok:!1,error:"form must have at least 1 field"};i.length>20&&(t.push("Form fields capped at 20"),i=i.slice(0,20));const n=["text","email","number","textarea","select","radio","checkbox","date","range"],o=new Set,r=[];for(let a=0;a<i.length;a++){const s=i[a];if(!s||typeof s!="object")return{ok:!1,error:"Form field must be an object"};const l=s,c=N(l.label??l.title,160);if(!c)return{ok:!1,error:"Form field label is required"};const d=N(l.type).toLowerCase();if(!n.includes(d))return{ok:!1,error:`Unsupported form field type "${d}"`};let p=N(l.id,80).replace(/[^a-zA-Z0-9_-]/g,"-");for((!p||o.has(p))&&(p=`field-${a+1}`);o.has(p);)p=`${p}-${a+1}`;o.add(p);const h=Array.isArray(l.options)?l.options.map(C=>N(C,160)).filter(Boolean).slice(0,30):[];if((d==="select"||d==="radio")&&h.length<2)return{ok:!1,error:`${d} field "${c}" must have at least 2 options`};const f=typeof l.min=="number"&&Number.isFinite(l.min)?l.min:void 0,g=typeof l.max=="number"&&Number.isFinite(l.max)?l.max:void 0;if(f!==void 0&&g!==void 0&&f>g)return{ok:!1,error:`Form field "${c}" has min greater than max`};const b=typeof l.step=="number"&&Number.isFinite(l.step)&&l.step>0?l.step:void 0;if(l.value!==void 0){if(d==="select"||d==="radio"){if(typeof l.value!="string"||!h.includes(l.value))return{ok:!1,error:`Default value for "${c}" must match one of its options`}}else if(d==="checkbox"){if(typeof l.value!="boolean")return{ok:!1,error:`Default value for "${c}" must be true or false`}}else if(d==="number"||d==="range"){if(typeof l.value!="number"||!Number.isFinite(l.value)||f!==void 0&&l.value<f||g!==void 0&&l.value>g)return{ok:!1,error:`Default value for "${c}" must be a number within its bounds`}}else if(typeof l.value!="string")return{ok:!1,error:`Default value for "${c}" must be text`}}const m={id:p,label:c,type:d,...l.required===!0?{required:!0}:{},...N(l.placeholder,180)?{placeholder:N(l.placeholder,180)}:{},...N(l.help??l.description,300)?{help:N(l.help??l.description,300)}:{},...h.length?{options:h}:{},...f!==void 0?{min:f}:{},...g!==void 0?{max:g}:{},...b!==void 0?{step:b}:{}};(typeof l.value=="string"||typeof l.value=="number"||typeof l.value=="boolean")&&(m.value=l.value),r.push(m)}return{ok:!0,spec:{type:"form",fields:r,...N(e.description,500)?{description:N(e.description,500)}:{},...N(e.submitLabel,60)?{submitLabel:N(e.submitLabel,60)}:{}}}}function Fr(e,t){const i=N(e.src,2048),n=N(e.alt,500);if(!i)return{ok:!1,error:"image must have a source URL"};if(!n)return{ok:!1,error:"image must have descriptive alt text"};try{const s=new URL(i);if(s.protocol!=="https:"||s.username||s.password)return{ok:!1,error:"image source must be a credential-free HTTPS URL"}}catch{return{ok:!1,error:"image source must be a valid HTTPS URL"}}let o=N(e.aspect).toLowerCase();["auto","wide","square","portrait"].includes(o)||(e.aspect!==void 0&&t.push("Invalid image aspect, defaulting to auto"),o="auto");let r=N(e.fit).toLowerCase();["contain","cover"].includes(r)||(e.fit!==void 0&&t.push("Invalid image fit, defaulting to contain"),r="contain");const a=N(e.caption,500);return{ok:!0,spec:{type:"image",src:i,alt:n,aspect:o,fit:r,...a?{caption:a}:{}}}}function $r(e,t){let i=Array.isArray(e.items)?e.items:[];if(i.length<2)return{ok:!1,error:"dashboard must have at least 2 visual items"};i.length>8&&(t.push("Dashboard items capped at 8"),i=i.slice(0,8));const n=[];for(let o=0;o<i.length;o++){const r=i[o];if(!r||typeof r!="object"||Array.isArray(r))return{ok:!1,error:`Dashboard item ${o+1} must be an object`};const a=r,s=a.visual??a.spec;if(!s||typeof s!="object"||Array.isArray(s))return{ok:!1,error:`Dashboard item ${o+1} must contain a visual object`};const l=s.type;if(l==="dashboard"||l==="generic")return{ok:!1,error:"Dashboard panels cannot contain another dashboard or generic fallback"};const c=ze(s);if(!c.ok)return{ok:!1,error:`Dashboard item ${o+1}: ${c.error}`};if(c.spec.type==="dashboard"||c.spec.type==="generic")return{ok:!1,error:"Dashboard panels must use supported visual types"};t.push(...c.warnings);const d=N(a.title,120);n.push({visual:c.spec,...d?{title:d}:{}})}return{ok:!0,spec:{type:"dashboard",items:n}}}function jr(e,t){const i=e.root;if(!i||typeof i!="object"||Array.isArray(i))return{ok:!1,error:"tree must have a root node object"};const n=6,o=80;let r=0,a=!1,s=!1;const l=new Set;function c(f,g){if(!f||typeof f!="object"||Array.isArray(f))return null;if(r>=o)return s=!0,null;const b=f,m=N(b.label??b.title??b.name);if(!m)return null;r++;const C=N(b.id)||`node-${r}`;let v=C,w=2;for(;l.has(v);)v=`${C}-${w++}`;l.add(v);const x=N(b.note??b.description,500),y=N(b.badge,60),k=b.color!==void 0?Nt(b.color,v||m):void 0,A=typeof b.collapsed=="boolean"?b.collapsed:void 0;let S;if(Array.isArray(b.children)&&b.children.length>0)if(g>=n)a=!0;else{const E=[];for(const z of b.children){if(r>=o){s=!0;break}const L=c(z,g+1);L&&E.push(L)}E.length>0&&(S=E)}return{id:v,label:m,...x?{note:x}:{},...y?{badge:y}:{},...k?{color:k}:{},...A!==void 0?{collapsed:A}:{},...S?{children:S}:{}}}const d=c(i,1);if(!d)return{ok:!1,error:"tree root node must have a non-empty label"};a&&t.push("Tree depth capped at 6"),s&&t.push("Tree nodes capped at 80");const p=N(e.layout).toLowerCase(),h=p==="horizontal"||p==="vertical"||p==="outline"?p:void 0;return{ok:!0,spec:{type:"tree",...N(e.title)?{title:N(e.title)}:{},...h?{layout:h}:{},root:d}}}function Ci(e,t){const i=N(e.title),n=N(e.originalType);return{ok:!0,spec:{type:"generic",...i?{title:i}:{},...n?{originalType:n}:{},data:e}}}function ze(e){if(!e||typeof e!="object"||Array.isArray(e))return{ok:!1,error:"unknown type"};const t=e,i=[],n=Qt.filter(a=>a!=="generic");if(typeof t.type!="string"||!n.includes(t.type)){if(typeof t.type=="string"&&t.type.length>0){const a=Ci({...t,originalType:t.type},i);if(a.ok){const s=N(t.title);return s&&(a.spec.title=s),{ok:!0,spec:a.spec,warnings:i}}}return{ok:!1,error:"unknown type"}}let o;switch(t.type){case"flow":o=xr(t,i);break;case"tree":o=jr(t,i);break;case"stepper":o=vr(t,i);break;case"table":o=wr(t,i);break;case"compare":o=yr(t,i);break;case"quiz":o=kr(t,i);break;case"chart":o=Cr(t,i);break;case"mermaid":o=Er(t);break;case"callout":o=Sr(t,i);break;case"stats":o=Ar(t,i);break;case"tabs":o=Mr(t,i);break;case"timeline":o=Tr(t,i);break;case"followups":o=Lr(t,i);break;case"math":o=zr(t,i);break;case"code":o=_r(t,i);break;case"checklist":o=Br(t,i);break;case"form":o=Ir(t,i);break;case"image":o=Fr(t,i);break;case"dashboard":o=$r(t,i);break;case"generic":o=Ci(t,i);break;default:return{ok:!1,error:"unknown type"}}if(!o.ok)return o;const r=N(t.title);return r&&(o.spec.title=r),{ok:!0,spec:o.spec,warnings:i}}var iu=["h","ttp://www.w3.org/2000/svg"].join("");function u(e,t,...i){const n=document.createElement(e);if(t){for(const[o,r]of Object.entries(t))if(!(r===void 0||r===!1))if(o.startsWith("on")&&typeof r=="function"){const a=o.slice(2).toLowerCase();n.addEventListener(a,r)}else o==="class"||o==="className"?n.className=String(r):r===!0?n.setAttribute(o,""):n.setAttribute(o,String(r))}for(const o of i)o==null||o===!1||(typeof o=="string"||typeof o=="number"?n.appendChild(document.createTextNode(String(o))):o instanceof Node&&n.appendChild(o));return n}function de(e){for(;e.firstChild;)e.removeChild(e.firstChild)}var Nr="M11.04 19.32Q12 21.51 12 24q0-2.49.93-4.68.96-2.19 2.58-3.81t3.81-2.55Q21.51 12 24 12q-2.49 0-4.68-.93a12.3 12.3 0 0 1-3.81-2.58 12.3 12.3 0 0 1-2.58-3.81Q12 2.49 12 0q0 2.49-.96 4.68-.93 2.19-2.55 3.81a12.3 12.3 0 0 1-3.81 2.58Q2.49 12 0 12q2.49 0 4.68.96 2.19.93 3.81 2.55t2.55 3.81",Je=null;function ii(e,t){if(!Je&&typeof DOMParser<"u"&&(Je=new DOMParser),!Je)return document.createElementNS("http://www.w3.org/2000/svg","svg");const i=Je.parseFromString(e,"image/svg+xml"),n=i.documentElement?document.importNode(i.documentElement,!0):document.createElementNS("http://www.w3.org/2000/svg","svg");return t!==void 0&&(n.setAttribute("width",String(t)),n.setAttribute("height",String(t))),n.setAttribute("aria-hidden","true"),n}var qr=0;function Or(e=28){const t=`bvi-gemini-grad-${++qr}`;return ii(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="${e}" height="${e}" aria-hidden="true">
  <defs>
    <linearGradient id="${t}" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#4E82EE" />
      <stop offset="50%" stop-color="#8E75FF" />
      <stop offset="100%" stop-color="#DE51A8" />
    </linearGradient>
  </defs>
  <path fill="url(#${t})" d="${Nr}" />
</svg>`,e)}function Dr(e=28){return ii(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="${e}" height="${e}" fill="currentColor" fill-rule="evenodd" aria-hidden="true">
  <path fill-rule="evenodd" d="M9.27 15.29l7.978-5.897c.391-.29.95-.177 1.137.272.98 2.369.542 5.215-1.41 7.169-1.951 1.954-4.667 2.382-7.149 1.406l-2.711 1.257c3.889 2.661 8.611 2.003 11.562-.953 2.341-2.344 3.066-5.539 2.388-8.42l.006.007c-.983-4.232.242-5.924 2.75-9.383.06-.082.12-.164.179-.248l-3.301 3.305v-.01L9.267 15.292M7.623 16.723c-2.792-2.67-2.31-6.801.071-9.184 1.761-1.763 4.647-2.483 7.166-1.425l2.705-1.25a7.808 7.808 0 00-1.829-1A8.975 8.975 0 005.984 5.83c-2.533 2.536-3.33 6.436-1.962 9.764 1.022 2.487-.653 4.246-2.34 6.022-.599.63-1.199 1.259-1.682 1.925l7.62-6.815" />
</svg>`,e)}var Ei=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-activity"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2" />
</svg>
`,Rr=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-arrow-left"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m12 19-7-7 7-7" />
  <path d="M19 12H5" />
</svg>
`,Pr=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-arrow-right"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 12h14" />
  <path d="m12 5 7 7-7 7" />
</svg>
`,Si=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-arrow-up-right"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M7 7h10v10" />
  <path d="M7 17 17 7" />
</svg>
`,Vr=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-bell"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M10.268 21a2 2 0 0 0 3.464 0" />
  <path d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326" />
</svg>
`,Hr=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-book-open"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 7v14" />
  <path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z" />
</svg>
`,Ai=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-bot"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 8V4H8" />
  <rect width="16" height="12" x="4" y="8" rx="2" />
  <path d="M2 14h2" />
  <path d="M20 14h2" />
  <path d="M15 13v2" />
  <path d="M9 13v2" />
</svg>
`,Mi=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-box"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
  <path d="m3.3 7 8.7 5 8.7-5" />
  <path d="M12 22V12" />
</svg>
`,Ti=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-building-2"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z" />
  <path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2" />
  <path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2" />
  <path d="M10 6h4" />
  <path d="M10 10h4" />
  <path d="M10 14h4" />
  <path d="M10 18h4" />
</svg>
`,Wr=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-calendar"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M8 2v4" />
  <path d="M16 2v4" />
  <rect width="18" height="18" x="3" y="4" rx="2" />
  <path d="M3 10h18" />
</svg>
`,Ur=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-camera"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z" />
  <circle cx="12" cy="13" r="3" />
</svg>
`,it=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-chart-column"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 3v16a2 2 0 0 0 2 2h16" />
  <path d="M18 17V9" />
  <path d="M13 17V5" />
  <path d="M8 17v-3" />
</svg>
`,Un=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-chart-no-axes-combined"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 16v5" />
  <path d="M16 14v7" />
  <path d="M20 10v11" />
  <path d="m22 3-8.646 8.646a.5.5 0 0 1-.708 0L9.354 8.354a.5.5 0 0 0-.707 0L2 15" />
  <path d="M4 18v3" />
  <path d="M8 14v7" />
</svg>
`,Li=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-chart-pie"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M21 12c.552 0 1.005-.449.95-.998a10 10 0 0 0-8.953-8.951c-.55-.055-.998.398-.998.95v8a1 1 0 0 0 1 1z" />
  <path d="M21.21 15.89A10 10 0 1 1 8 2.83" />
</svg>
`,Gr=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-check"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 6 9 17l-5-5" />
</svg>
`,zi=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-chevron-down"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m6 9 6 6 6-6" />
</svg>
`,_i=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-chevron-left"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m15 18-6-6 6-6" />
</svg>
`,Bi=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-chevron-right"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m9 18 6-6-6-6" />
</svg>
`,Ii=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-chevron-up"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m18 15-6-6-6 6" />
</svg>
`,Yr=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-circle-alert"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <line x1="12" x2="12" y1="8" y2="12" />
  <line x1="12" x2="12.01" y1="16" y2="16" />
</svg>
`,Kr=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-circle-check"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <path d="m9 12 2 2 4-4" />
</svg>
`,qt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-circle-help"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
  <path d="M12 17h.01" />
</svg>
`,Xr=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-circle-x"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <path d="m15 9-6 6" />
  <path d="m9 9 6 6" />
</svg>
`,Gn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-clock"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <polyline points="12 6 12 12 16 14" />
</svg>
`,Zr=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-cloud"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z" />
</svg>
`,Yn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-code"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <polyline points="16 18 22 12 16 6" />
  <polyline points="8 6 2 12 8 18" />
</svg>
`,Qr=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-columns-3"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="18" height="18" x="3" y="3" rx="2" />
  <path d="M9 3v18" />
  <path d="M15 3v18" />
</svg>
`,Jr=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-compass"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m16.24 7.76-1.804 5.411a2 2 0 0 1-1.265 1.265L7.76 16.24l1.804-5.411a2 2 0 0 1 1.265-1.265z" />
  <circle cx="12" cy="12" r="10" />
</svg>
`,ea=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-copy"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="14" height="14" x="8" y="8" rx="2" ry="2" />
  <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2" />
</svg>
`,ta=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-cpu"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="16" height="16" x="4" y="4" rx="2" />
  <rect width="6" height="6" x="9" y="9" rx="1" />
  <path d="M15 2v2" />
  <path d="M15 20v2" />
  <path d="M2 15h2" />
  <path d="M2 9h2" />
  <path d="M20 15h2" />
  <path d="M20 9h2" />
  <path d="M9 2v2" />
  <path d="M9 20v2" />
</svg>
`,ia=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-credit-card"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="20" height="14" x="2" y="5" rx="2" />
  <line x1="2" x2="22" y1="10" y2="10" />
</svg>
`,na=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-database"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <ellipse cx="12" cy="5" rx="9" ry="3" />
  <path d="M3 5V19A9 3 0 0 0 21 19V5" />
  <path d="M3 12A9 3 0 0 0 21 12" />
</svg>
`,Fi=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-download"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
  <polyline points="7 10 12 15 17 10" />
  <line x1="12" x2="12" y1="15" y2="3" />
</svg>
`,$i=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-external-link"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 3h6v6" />
  <path d="M10 14 21 3" />
  <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
</svg>
`,oa=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-eye"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0" />
  <circle cx="12" cy="12" r="3" />
</svg>
`,ra=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-file"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" />
  <path d="M14 2v4a2 2 0 0 0 2 2h4" />
</svg>
`,aa=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-file-text"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z" />
  <path d="M14 2v4a2 2 0 0 0 2 2h4" />
  <path d="M10 9H8" />
  <path d="M16 13H8" />
  <path d="M16 17H8" />
</svg>
`,ji=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-filter"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" />
</svg>
`,sa=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-folder"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z" />
</svg>
`,la=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-globe"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" />
  <path d="M2 12h20" />
</svg>
`,Ni=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-graduation-cap"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z" />
  <path d="M22 10v6" />
  <path d="M6 12.5V16a6 3 0 0 0 12 0v-3.5" />
</svg>
`,ca=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-hard-drive"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <line x1="22" x2="2" y1="12" y2="12" />
  <path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z" />
  <line x1="6" x2="6.01" y1="16" y2="16" />
  <line x1="10" x2="10.01" y1="16" y2="16" />
</svg>
`,da=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-heart"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
</svg>
`,ua=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-hourglass"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 22h14" />
  <path d="M5 2h14" />
  <path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22" />
  <path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2" />
</svg>
`,qi=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-house"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8" />
  <path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
</svg>
`,Kn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-image"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
  <circle cx="9" cy="9" r="2" />
  <path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21" />
</svg>
`,Xn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-info"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <path d="M12 16v-4" />
  <path d="M12 8h.01" />
</svg>
`,pa=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-key"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4" />
  <path d="m21 2-9.6 9.6" />
  <circle cx="7.5" cy="15.5" r="5.5" />
</svg>
`,ha=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-laptop"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 16V7a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v9m16 0H4m16 0 1.28 2.55a1 1 0 0 1-.9 1.45H3.62a1 1 0 0 1-.9-1.45L4 16" />
</svg>
`,fa=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-layers"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83z" />
  <path d="M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12" />
  <path d="M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17" />
</svg>
`,ga=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-link"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
  <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
</svg>
`,Ot=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-list"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 12h.01" />
  <path d="M3 18h.01" />
  <path d="M3 6h.01" />
  <path d="M8 12h13" />
  <path d="M8 18h13" />
  <path d="M8 6h13" />
</svg>
`,Zn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-list-checks"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m3 17 2 2 4-4" />
  <path d="m3 7 2 2 4-4" />
  <path d="M13 6h8" />
  <path d="M13 12h8" />
  <path d="M13 18h8" />
</svg>
`,Qn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-list-ordered"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M10 12h11" />
  <path d="M10 18h11" />
  <path d="M10 6h11" />
  <path d="M4 10h2" />
  <path d="M4 6h1v4" />
  <path d="M6 18H4c0-1 2-2 2-3s-1-1.5-2-1" />
</svg>
`,ma=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-lock"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
  <path d="M7 11V7a5 5 0 0 1 10 0v4" />
</svg>
`,Oi=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-mail"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="20" height="16" x="2" y="4" rx="2" />
  <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
</svg>
`,ba=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-map-pin"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0" />
  <circle cx="12" cy="10" r="3" />
</svg>
`,Ve=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-maximize"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M8 3H5a2 2 0 0 0-2 2v3" />
  <path d="M21 8V5a2 2 0 0 0-2-2h-3" />
  <path d="M3 16v3a2 2 0 0 0 2 2h3" />
  <path d="M16 21h3a2 2 0 0 0 2-2v-3" />
</svg>
`,Di=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-message-circle"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z" />
</svg>
`,xa=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-messages-square"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M14 9a2 2 0 0 1-2 2H6l-4 4V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2z" />
  <path d="M18 9h2a2 2 0 0 1 2 2v11l-4-4h-6a2 2 0 0 1-2-2v-1" />
</svg>
`,gt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-minimize"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M8 3v3a2 2 0 0 1-2 2H3" />
  <path d="M21 8h-3a2 2 0 0 1-2-2V3" />
  <path d="M3 16h3a2 2 0 0 1 2 2v3" />
  <path d="M16 21v-3a2 2 0 0 1 2-2h3" />
</svg>
`,va=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-minus"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 12h14" />
</svg>
`,Ri=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-monitor"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="20" height="14" x="2" y="3" rx="2" />
  <line x1="8" x2="16" y1="21" y2="21" />
  <line x1="12" x2="12" y1="17" y2="21" />
</svg>
`,wa=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-music"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M9 18V5l12-2v13" />
  <circle cx="6" cy="18" r="3" />
  <circle cx="18" cy="16" r="3" />
</svg>
`,Dt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-network"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect x="16" y="16" width="6" height="6" rx="1" />
  <rect x="2" y="16" width="6" height="6" rx="1" />
  <rect x="9" y="2" width="6" height="6" rx="1" />
  <path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3" />
  <path d="M12 12V8" />
</svg>
`,ya=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-package"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z" />
  <path d="M12 22V12" />
  <path d="m3.3 7 7.703 4.734a2 2 0 0 0 1.994 0L20.7 7" />
  <path d="m7.5 4.27 9 5.15" />
</svg>
`,Rt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-panels-top-left"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="18" height="18" x="3" y="3" rx="2" />
  <path d="M3 9h18" />
  <path d="M9 21V9" />
</svg>
`,Pi=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-pencil"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z" />
  <path d="m15 5 4 4" />
</svg>
`,ka=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-play"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <polygon points="6 3 20 12 6 21 6 3" />
</svg>
`,Ca=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-plus"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M5 12h14" />
  <path d="M12 5v14" />
</svg>
`,mt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-refresh-cw"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
  <path d="M21 3v5h-5" />
  <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
  <path d="M8 16H3v5" />
</svg>
`,Ea=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-rocket"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z" />
  <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z" />
  <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0" />
  <path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5" />
</svg>
`,Pt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-scale"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m16 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
  <path d="m2 16 3-8 3 8c-.87.65-1.92 1-3 1s-2.13-.35-3-1Z" />
  <path d="M7 21h10" />
  <path d="M12 3v18" />
  <path d="M3 7h2c2 0 5-1 7-2 2 1 5 2 7 2h2" />
</svg>
`,Vi=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-search"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="11" cy="11" r="8" />
  <path d="m21 21-4.3-4.3" />
</svg>
`,Hi=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-server"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="20" height="8" x="2" y="2" rx="2" ry="2" />
  <rect width="20" height="8" x="2" y="14" rx="2" ry="2" />
  <line x1="6" x2="6.01" y1="6" y2="6" />
  <line x1="6" x2="6.01" y1="18" y2="18" />
</svg>
`,Wi=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-settings"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
  <circle cx="12" cy="12" r="3" />
</svg>
`,Sa=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-shield"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
</svg>
`,Aa=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-shield-check"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" />
  <path d="m9 12 2 2 4-4" />
</svg>
`,Ui=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-shopping-cart"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="8" cy="21" r="1" />
  <circle cx="19" cy="21" r="1" />
  <path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12" />
</svg>
`,Gi=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-smartphone"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="14" height="20" x="5" y="2" rx="2" ry="2" />
  <path d="M12 18h.01" />
</svg>
`,Vt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-sparkles"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z" />
  <path d="M20 3v4" />
  <path d="M22 5h-4" />
  <path d="M4 17v2" />
  <path d="M5 18H3" />
</svg>
`,Ma=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-square"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="18" height="18" x="3" y="3" rx="2" />
</svg>
`,Jn=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-square-function"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="18" height="18" x="3" y="3" rx="2" ry="2" />
  <path d="M9 17c2 0 2.8-1 2.8-2.8V10c0-2 1-3.3 3.2-3" />
  <path d="M9 11.2h5.7" />
</svg>
`,Ta=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-star"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z" />
</svg>
`,eo=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-table"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 3v18" />
  <rect width="18" height="18" x="3" y="3" rx="2" />
  <path d="M3 9h18" />
  <path d="M3 15h18" />
</svg>
`,La=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-tag"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z" />
  <circle cx="7.5" cy="7.5" r=".5" fill="currentColor" />
</svg>
`,za=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-target"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <circle cx="12" cy="12" r="10" />
  <circle cx="12" cy="12" r="6" />
  <circle cx="12" cy="12" r="2" />
</svg>
`,_a=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-terminal"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <polyline points="4 17 10 11 4 5" />
  <line x1="12" x2="20" y1="19" y2="19" />
</svg>
`,Ba=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-timer"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <line x1="10" x2="14" y1="2" y2="2" />
  <line x1="12" x2="15" y1="14" y2="11" />
  <circle cx="12" cy="14" r="8" />
</svg>
`,Ia=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-trash-2"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M3 6h18" />
  <path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6" />
  <path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2" />
  <line x1="10" x2="10" y1="11" y2="17" />
  <line x1="14" x2="14" y1="11" y2="17" />
</svg>
`,Fa=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-trending-down"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <polyline points="22 17 13.5 8.5 8.5 13.5 2 7" />
  <polyline points="16 17 22 17 22 11" />
</svg>
`,Yi=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-trending-up"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <polyline points="22 7 13.5 15.5 8.5 10.5 2 17" />
  <polyline points="16 7 22 7 22 13" />
</svg>
`,Ki=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-triangle-alert"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3" />
  <path d="M12 9v4" />
  <path d="M12 17h.01" />
</svg>
`,$a=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-upload"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
  <polyline points="17 8 12 3 7 8" />
  <line x1="12" x2="12" y1="3" y2="15" />
</svg>
`,ja=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-user"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2" />
  <circle cx="12" cy="7" r="4" />
</svg>
`,Na=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-users"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
  <circle cx="9" cy="7" r="4" />
  <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
  <path d="M16 3.13a4 4 0 0 1 0 7.75" />
</svg>
`,qa=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-video"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="m16 13 5.223 3.482a.5.5 0 0 0 .777-.416V7.87a.5.5 0 0 0-.752-.432L16 10.5" />
  <rect x="2" y="6" width="14" height="12" rx="2" />
</svg>
`,Oa=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-wallet"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1" />
  <path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4" />
</svg>
`,Xi=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-wifi"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M12 20h.01" />
  <path d="M2 8.82a15 15 0 0 1 20 0" />
  <path d="M5 12.859a10 10 0 0 1 14 0" />
  <path d="M8.5 16.429a5 5 0 0 1 7 0" />
</svg>
`,nt=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-workflow"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <rect width="8" height="8" x="3" y="3" rx="2" />
  <path d="M7 11v4a2 2 0 0 0 2 2h4" />
  <rect width="8" height="8" x="13" y="13" rx="2" />
</svg>
`,Da=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-x"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M18 6 6 18" />
  <path d="m6 6 12 12" />
</svg>
`,Zi=`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-zap"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z" />
</svg>
`,Ra={export:$a,download:Fi,"download-simple":Fi,image:Kn,copy:ea,code:Yn,"corners-out":Ve,"arrows-out":Ve,maximize:Ve,"maximize-2":Ve,expand:Ve,"corners-in":gt,minimize:gt,x:Da,check:Gr,"caret-down":zi,"chevron-down":zi,"caret-up":Ii,"chevron-up":Ii,"caret-left":_i,"chevron-left":_i,"caret-right":Bi,"chevron-right":Bi,"arrow-right":Pr,"arrow-left":Rr,"arrow-up-right":Si,"arrow-ne":Si,"arrow-square-out":$i,"external-link":$i,robot:Ai,bot:Ai,sparkle:Vt,sparkles:Vt,"shield-check":Aa,eye:oa,play:ka,globe:la,lock:ma,server:Hi,"hard-drives":Hi,database:na,lightning:Zi,zap:Zi,rocket:Ea,clock:Gn,users:Na,user:ja,cloud:Zr,"chart-line":Un,"trending-up":Yi,cpu:ta,"wifi-high":Xi,wifi:Xi,bell:Vr,calendar:Wr,envelope:Oi,mail:Oi,"chat-circle":Di,message:Di,"chats-circle":xa,heart:da,star:Ta,"magnifying-glass":Vi,search:Vi,gear:Wi,settings:Wi,"file-text":aa,file:ra,folder:sa,terminal:_a,tag:La,compass:Jr,"map-pin":ba,"credit-card":ia,wallet:Oa,"shopping-cart":Ui,cart:Ui,package:ya,cube:Mi,box:Mi,"hard-drive":ca,laptop:ha,desktop:Ri,monitor:Ri,"device-mobile":Gi,smartphone:Gi,camera:Ur,video:qa,"music-note":wa,book:Hr,student:Ni,"graduation-cap":Ni,target:za,funnel:ji,filter:ji,"arrows-clockwise":mt,refresh:mt,"refresh-cw":mt,warning:Ki,"warning-circle":Yr,"alert-triangle":Ki,shield:Sa,key:pa,link:ga,activity:Ei,pulse:Ei,timer:Ba,hourglass:ua,"trend-down":Fa,"trend-up":Yi,"chart-pie":Li,"pie-chart":Li,"chart-bar":it,"bar-chart":it,chart:it,buildings:Ti,building:Ti,house:qi,home:qi,trash:Ia,"pencil-simple":Pi,edit:Pi,"check-circle":Kr,"x-circle":Xr,info:Xn,question:qt,"help-circle":qt,table:eo,columns:Qr,scales:Pt,scale:Pt,steps:Qn,"tree-structure":nt,workflow:nt,network:Dt,graph:Dt,tabs:Rt,layers:fa,list:Ot,plus:Ca,minus:va,"bounding-box":Ma,shrink:gt,function:Jn,checklist:Zn},Qi={flow:nt,stepper:Qn,table:eo,compare:Pt,quiz:qt,chart:it,mermaid:Dt,callout:Xn,stats:Un,tabs:Rt,timeline:Gn,followups:Vt,math:Jn,code:Yn,checklist:Zn,form:Ot,image:Kn,dashboard:Rt,tree:nt,generic:Ot},Pa=["export","download","download-simple","image","copy","code","corners-out","arrows-out","maximize","maximize-2","expand","corners-in","minimize","check","caret-down","chevron-down","caret-up","chevron-up","caret-left","chevron-left","caret-right","chevron-right","arrow-right","arrow-left","arrow-up-right","arrow-ne","arrow-square-out","external-link","robot","bot","sparkle","sparkles","shield-check","eye","play","globe","lock","server","hard-drives","database","lightning","zap","rocket","clock","users","user","cloud","chart-line","trending-up","cpu","wifi-high","wifi","bell","calendar","envelope","mail","chat-circle","message","chats-circle","heart","star","magnifying-glass","search","gear","settings","file-text","file","folder","terminal","tag","compass","map-pin","credit-card","wallet","shopping-cart","cart","package","cube","box","hard-drive","laptop","desktop","monitor","device-mobile","smartphone","camera","video","music-note","book","student","graduation-cap","target","funnel","filter","arrows-clockwise","refresh","refresh-cw","warning","warning-circle","alert-triangle","shield","key","link","activity","pulse","timer","hourglass","trend-down","trend-up","chart-pie","pie-chart","chart-bar","bar-chart","chart","buildings","building","house","home","trash","pencil-simple","edit","check-circle","x-circle","info","question","help-circle","table","columns","scales","scale","steps","tree-structure","workflow","network","graph","tabs","layers","list","plus","minus","bounding-box","shrink","function","checklist"],nu=new Set(Pa);function Va(e){return e?e.trim().replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase().replace(/[\s_]+/g,"-"):""}function to(e,t=16,i){const n=ii(e,t);return n.setAttribute("fill","none"),n.setAttribute("stroke","currentColor"),n.setAttribute("stroke-width","1.8"),n.setAttribute("stroke-linecap","round"),n.setAttribute("stroke-linejoin","round"),i&&n.setAttribute("class",i),n}function io(e,t=16,i){return to(Qi[e]||Qi.flow,t,i)}function K(e,t=16,i){return to(Ra[Va(e)]||`<!-- @license lucide-static v0.468.0 - ISC -->
<svg
  class="lucide lucide-sparkles"
  xmlns="http://www.w3.org/2000/svg"
  width="24"
  height="24"
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width="2"
  stroke-linecap="round"
  stroke-linejoin="round"
>
  <path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z" />
  <path d="M20 3v4" />
  <path d="M22 5h-4" />
  <path d="M4 17v2" />
  <path d="M5 18H3" />
</svg>
`,t,i)}var bt={flow:{icon:"tree-structure",color:"blue",label:"Flow"},tree:{icon:"network",color:"teal",label:"Tree"},stepper:{icon:"steps",color:"blue",label:"Steps"},table:{icon:"table",color:"stone",label:"Table"},compare:{icon:"scales",color:"amber",label:"Compare"},quiz:{icon:"question",color:"green",label:"Quiz"},chart:{icon:"chart-bar",color:"purple",label:"Chart"},mermaid:{icon:"graph",color:"purple",label:"Diagram"},callout:{icon:"info",color:"blue",label:"Callout"},stats:{icon:"trend-up",color:"teal",label:"Stats"},tabs:{icon:"tabs",color:"stone",label:"Tabs"},timeline:{icon:"hourglass",color:"rose",label:"Timeline"},followups:{icon:"sparkle",color:"mint",label:"Suggestions"},math:{icon:"function",color:"purple",label:"Math"},code:{icon:"code",color:"sky",label:"Code"},checklist:{icon:"check",color:"green",label:"Checklist"},form:{icon:"list",color:"blue",label:"Form"},image:{icon:"image",color:"purple",label:"Image"},dashboard:{icon:"layout-dashboard",color:"stone",label:"Dashboard"},generic:{icon:"sparkle",color:"stone",label:"Details"}},Ha="modulepreload",Wa=function(e){return"/"+e},Ua={},Ga=function(t){return t.pathname.endsWith(".css")},Ya=function(t,i,n){if(i in t)return t[i];const o=n();if(!o){t[i]=void 0;return}const r=o.then(()=>{t[i]=void 0},a=>{throw t[i]=void 0,a});return t[i]=r,r},ni=function(t,i,n){let o=Promise.resolve();if(i&&i.length>0){let c=function(p){return Promise.all(p.map(h=>Promise.resolve(h).then(f=>({status:"fulfilled",value:f}),f=>({status:"rejected",reason:f}))))},d=function(p){return import.meta.resolve?new URL(import.meta.resolve(p)):new URL(p,import.meta.url)},a;const s=document.querySelector("meta[property=csp-nonce]"),l=s?.nonce||s?.getAttribute("nonce");o=c(i.map(p=>{p=Wa(p,n);const h=d(p),f=Ga(h);return Ya(Ua,h.href,()=>{if(a===void 0){a={all:new Set,styles:new Set};const b=document.getElementsByTagName("link");for(let m=b.length-1;m>=0;m--){const C=b[m];a.all.add(C.href),C.rel==="stylesheet"&&a.styles.add(C.href)}}if((f?a.styles:a.all).has(h.href))return;const g=document.createElement("link");if(g.rel=f?"stylesheet":Ha,f||(g.as="script"),g.crossOrigin="",g.href=h.href,l&&g.setAttribute("nonce",l),document.head.appendChild(g),f)return new Promise((b,m)=>{const C=v=>{g.removeEventListener("load",C),g.removeEventListener("error",C),v.type==="error"?m(new Error(`Unable to preload CSS for ${h}`)):b(v)};g.addEventListener("load",C),g.addEventListener("error",C)})})}).filter(p=>p!==void 0))}function r(a){const s=new Event("vite:preloadError",{cancelable:!0});if(s.payload=a,window.dispatchEvent(s),!s.defaultPrevented)throw a}return o.then(a=>{for(const s of a||[])s.status==="rejected"&&r(s.reason);return t().catch(r)})},xt=null;async function Ka(){return xt||(xt=ni(()=>import("./assets/katex-NjyUZHjF.js").then(e=>e.default||e),[])),xt}function Xa(e){const t=[];if(!e)return t;let i=0,n=0;for(;i<e.length;){if(e[i]==="\\"&&i+1<e.length&&e[i+1]==="$"){i+=2;continue}if(e[i]==="$"){if(i+1<e.length&&e[i+1]==="$"){const o=e.indexOf("$$",i+2);if(o!==-1){i>n&&t.push({type:"text",text:e.slice(n,i)});const r=e.slice(i+2,o);t.push({type:"display-math",latex:r,raw:e.slice(i,o+2)}),i=o+2,n=i;continue}}else if(i+1<e.length&&e[i+1]!==" "&&e[i+1]!=="	"&&e[i+1]!==`
`&&e[i+1]!=="$"){let o=-1;for(let r=i+1;r<e.length&&e[r]!==`
`;r++){if(e[r]==="\\"&&r+1<e.length){r++;continue}if(e[r]==="$"&&e[r-1]!==" "&&e[r-1]!=="	"){o=r;break}}if(o!==-1&&o>i+1){i>n&&t.push({type:"text",text:e.slice(n,i)});const r=e.slice(i+1,o);t.push({type:"inline-math",latex:r,raw:e.slice(i,o+1)}),i=o+1,n=i;continue}}}i++}n<e.length&&t.push({type:"text",text:e.slice(n)});for(const o of t)o.type==="text"&&(o.text=o.text.replace(/\\\$/g,"$"));return t}function Ht(e,t,i=!1){Ka().then(n=>{try{n.render(t,e,{displayMode:i,throwOnError:!1})}catch{e.textContent=t}}).catch(()=>{e.textContent=t})}function xe(e,t){if(!t){e.textContent="";return}if(!t.includes("$")){e.textContent=t;return}const i=Xa(t);if(!i.some(n=>n.type!=="text")){e.textContent=t;return}de(e);for(const n of i)if(n.type==="text")e.appendChild(document.createTextNode(n.text));else{const o=n.type==="display-math",r=u(o?"div":"span",{class:o?"iui-math-display":"iui-math-inline"});r.textContent=n.latex,e.appendChild(r),Ht(r,n.latex,o)}}function Za(e){return e?e.replace(/@import\s+[^;]+;/g,"").replace(/@font-face\s*\{[^}]*\}/g,"").replace(/url\(\s*['"]?(?!data:)[^'")]+['"]?\s*\)/gi,"none"):""}function Ae(e,t){e.querySelectorAll(".iui-toast").forEach(n=>n.remove());const i=document.createElement("div");i.className="iui-toast",i.setAttribute("role","status"),i.textContent=t,e.appendChild(i),window.setTimeout(()=>{i.classList.add("is-hiding"),window.setTimeout(()=>{i.remove()},200)},1600)}function ot(e){const t=typeof e.getBoundingClientRect=="function"?e.getBoundingClientRect():null;let i=Math.max(Math.round(t?.width||e.offsetWidth||640),200),n=Math.max(Math.round(t?.height||e.offsetHeight||380),80);const o=".iui-card-toolbar, .iui-source-panel, .iui-toast, .iui-export-menu";for(const r of Array.from(e.querySelectorAll("*")))r.matches(o)||r.closest(o)||(i=Math.max(i,r.scrollWidth||0),n=Math.max(n,r.scrollHeight||0));return{width:i,height:n}}function ut(e,t){const i=t?"#0A0A0A":"#FFFFFF",n=t?"#18181A":"#FAFAFA",o=t?"#FAFAFA":"#0A0A0A",r=t?"#A3A3A3":"#6B7280",a=t?"#454545":"#D8DDE5";try{const s=e.closest(".iui-root")||e,l=typeof getComputedStyle=="function"?getComputedStyle(s):null;if(!l)return{bg:i,surface:n,text:o,muted:r,border:a};const c=(p,h)=>l.getPropertyValue(p).trim()||h,d=c("--iui-bg",i);return{bg:d,surface:c("--iui-surface",d||n),text:c("--iui-text",o),muted:c("--iui-muted",r),border:c("--iui-border",a)}}catch{return{bg:i,surface:n,text:o,muted:r,border:a}}}function Ji(e,t={}){const i=ut(e,t.theme==="dark"),n=i.bg,o=i.muted,r=t.watermark!==!1,a=e.cloneNode(!0);a.querySelectorAll(".iui-card-toolbar, .iui-source-panel, .iui-toast, .iui-partial-error-note, .iui-export-menu").forEach(v=>v.remove());const{width:s}=ot(e);a.style.width=`${s}px`,a.style.maxWidth="none",a.style.overflow="visible";const l=e.querySelectorAll(".flow-diagram, .iui-table-wrap"),c=a.querySelectorAll(".flow-diagram, .iui-table-wrap");l.forEach((v,w)=>{const x=c[w];if(!x)return;const y=v.scrollWidth;y>x.clientWidth&&(x.style.width=`${y}px`,x.style.maxWidth="none",x.style.overflow="visible")});const{width:d,height:p}=ot(e),h=24,f=d+48,g=p+48,b=Za((t.allStyles||[]).join(`
`)),m=r?`<text x="${f-24}" y="${g-10}" text-anchor="end" font-family="Inter, system-ui, -apple-system, sans-serif" font-size="12" fill="${o}" opacity="0.85">BetterView AI</text>`:"",C=a.outerHTML;return`<svg xmlns="http://www.w3.org/2000/svg" width="${f}" height="${g}" viewBox="0 0 ${f} ${g}">
  <style>
    ${b}
  </style>
  <rect width="100%" height="100%" fill="${n}"/>
  <foreignObject x="${h}" y="${h}" width="${d}" height="${p}">
    <div xmlns="http://www.w3.org/1999/xhtml" class="iui-root" data-theme="${t.theme||"light"}"${t.host?` data-host="${t.host}"`:""} style="margin:0;padding:0;width:100%;height:100%;background:transparent;">
      ${C}
    </div>
  </foreignObject>
  ${m}
</svg>`}function en(e,t={}){const i=t.theme==="dark",n=ut(e,i),o=n.bg,r=n.text,a=n.muted,s=n.border,l=28,c=e.querySelector(".flow-inner"),d=e.querySelector(".flow-diagram");if(!c||!d)throw new Error("The flowchart is still being laid out");const p=Math.max(320,Math.ceil(Math.max(c.scrollWidth,c.clientWidth,d.scrollWidth,d.clientWidth))),h=Math.max(180,Math.ceil(Math.max(c.scrollHeight,c.clientHeight,d.scrollHeight,d.clientHeight))),f=e.querySelector(".flow-title")?.textContent?.trim()||t.title||"",g=f?34:0,b=p+56,m=h+g+56,C=c.getBoundingClientRect(),v=no,w=Array.from(c.querySelectorAll(".flow-svg-overlay path")).map(S=>{const E=getComputedStyle(S).stroke||a;return`<path d="${v(S.getAttribute("d")||"")}" fill="none" stroke="${v(E)}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" marker-end="url(#flow-export-arrow)"/>`}).join(""),x=Array.from(c.querySelectorAll(".flow-node")).map(S=>{const E=S.getBoundingClientRect(),z=E.left-C.left+l,L=E.top-C.top+l+g,F=E.width,B=E.height,O=getComputedStyle(S),D=O.backgroundColor&&O.backgroundColor!=="rgba(0, 0, 0, 0)"?O.backgroundColor:i?"#202124":"#FFFFFF",P=O.borderColor||s,R=S.querySelector(".flow-node-label")?.textContent?.trim()||"",Q=S.querySelector(".flow-node-sub")?.textContent?.trim()||"",ee=getComputedStyle(S.querySelector(".flow-node-label")||S).color||r,X=getComputedStyle(S.querySelector(".flow-node-sub")||S).color||a,j=L+(Q?B/2-3:B/2+5),$=z+48,_=S.querySelector(".flow-node-iconbox svg");let I="";if(_){const M=_.cloneNode(!0);M.setAttribute("x",String(z+16)),M.setAttribute("y",String(L+B/2-9)),M.setAttribute("width","18"),M.setAttribute("height","18"),M.setAttribute("color",getComputedStyle(S.querySelector(".flow-node-iconbox")||S).color||r),I=M.outerHTML}return`<g><rect x="${z}" y="${L}" width="${F}" height="${B}" rx="11" fill="${v(D)}" stroke="${v(P)}"/>${I}<text x="${$}" y="${j}" font-family="Arial,sans-serif" font-size="13.5" font-weight="600" fill="${v(ee)}">${v(R)}</text>${Q?`<text x="${$}" y="${j+19}" font-family="Arial,sans-serif" font-size="11.5" fill="${v(X)}">${v(Q)}</text>`:""}</g>`}).join(""),y=Array.from(c.querySelectorAll(".flow-edge-label")).map(S=>{const E=S.getBoundingClientRect(),z=E.left+E.width/2-C.left+l,L=E.top+E.height/2-C.top+l+g,F=S.textContent?.trim()||"",B=Math.max(44,F.length*7+20);return`<g><rect x="${z-B/2}" y="${L-12}" width="${B}" height="24" rx="12" fill="${o}" stroke="${s}"/><text x="${z}" y="${L+4}" text-anchor="middle" font-family="Arial,sans-serif" font-size="11" fill="${r}">${v(F)}</text></g>`}).join(""),k=f?`<text x="${l}" y="46" font-family="Arial,sans-serif" font-size="16" font-weight="600" fill="${r}">${v(f)}</text>`:"",A=t.watermark===!1?"":`<text x="${b-l}" y="${m-10}" text-anchor="end" font-family="Arial,sans-serif" font-size="12" fill="${a}">BetterView AI</text>`;return`<svg xmlns="http://www.w3.org/2000/svg" width="${b}" height="${m}" viewBox="0 0 ${b} ${m}"><defs><marker id="flow-export-arrow" viewBox="0 0 8 8" refX="6" refY="4" markerWidth="6" markerHeight="6" orient="auto"><path d="M1 2 L6 4 L1 6 Z" fill="${a}"/></marker></defs><rect width="100%" height="100%" fill="${o}"/>${k}<g transform="translate(${l} ${l+g})">${w}</g>${x}${y}${A}</svg>`}async function Qa(e,t,i){const n=document.createElement("canvas"),o=Math.min(2,16384/Math.max(t,i),Math.sqrt(64e6/Math.max(1,t*i)));n.width=Math.max(1,Math.floor(t*o)),n.height=Math.max(1,Math.floor(i*o));const r=n.getContext("2d");if(!r)throw new Error("Could not get canvas 2d context");r.scale(o,o);const a=new Blob([e],{type:"image/svg+xml;charset=utf-8"}),s=URL.createObjectURL(a),l=new Image;return await new Promise((c,d)=>{l.onload=()=>{r.drawImage(l,0,0,t,i),URL.revokeObjectURL(s),c()},l.onerror=p=>{URL.revokeObjectURL(s),d(p)},l.src=s}),n}async function Ja(e,t,i={}){const n=ut(e,i.theme==="dark"),o=n.bg,r=n.text,a=n.muted,s=i.watermark!==!1,l=t.toBase64Image(),c=new Image;await new Promise((E,z)=>{c.onload=()=>E(),c.onerror=z,c.src=l});const d=Math.max(1,Math.round(t.width||c.naturalWidth||c.width)),p=Math.max(1,Math.round(t.height||c.naturalHeight||c.height)),{width:h}=ot(e),f=Math.max(h,d),g=e.querySelector(".iui-title"),b=g?g.textContent:"",m=24,C=b?36:0,v=p+C,w=f+48,x=v+48,y=document.createElement("canvas");y.width=w*2,y.height=x*2;const k=y.getContext("2d");if(!k)throw new Error("Could not get canvas 2d context");k.scale(2,2),k.fillStyle=o,k.fillRect(0,0,w,x),b&&(k.fillStyle=r,k.font="600 15px Inter, system-ui, sans-serif",k.fillText(b,m,40));const A=m+Math.max(0,(f-d)/2),S=m+C;return k.drawImage(c,A,S,d,p),s&&(k.fillStyle=a,k.font="12px Inter, system-ui, sans-serif",k.textAlign="right",k.fillText("BetterView AI",w-24,x-10)),y}function tn(e,t){const i=URL.createObjectURL(e),n=document.createElement("a");n.href=i,n.download=t,document.body.appendChild(n),n.click(),n.remove(),window.setTimeout(()=>URL.revokeObjectURL(i),1e4)}function es(e,t="betterview-card"){return e&&e.trim().toLowerCase().replace(/[^a-z0-9_-]+/g,"-").replace(/^-+|-+$/g,"")||t}function no(e){return e.replace(/[&<>"']/g,t=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&apos;"})[t])}function ts(e,t,i){const n=ut(e,i.theme==="dark"),o=n.bg,r=n.text,a=n.muted,s=24,l=Math.max(1,Math.round(t.width||640)),c=Math.max(1,Math.round(t.height||300)),d=e.querySelector(".iui-title")?.textContent?.trim()??"",p=d?36:0,h=l+48,f=c+p+48,g=t.toBase64Image(),b=d?`<text x="${s}" y="41" font-family="Inter,system-ui,sans-serif" font-size="15" font-weight="600" fill="${r}">${no(d)}</text>`:"",m=i.watermark===!1?"":`<text x="${h-s}" y="${f-10}" text-anchor="end" font-family="Inter,system-ui,sans-serif" font-size="12" fill="${a}">BetterView AI</text>`;return`<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="${h}" height="${f}" viewBox="0 0 ${h} ${f}"><rect width="100%" height="100%" fill="${o}"/>${b}<image x="${s}" y="${s+p}" width="${l}" height="${c}" href="${g}" xlink:href="${g}"/>${m}</svg>`}async function vt(e,t,i={}){const n=es(i.title||i.cardType);try{const o=e.__chartReady;o&&await o;const r=e.__chartInstance||e.querySelector("canvas")?.__chartInstance;if(e.classList.contains("iui-chart-card")&&!r)throw new Error("The chart is not ready to export yet");if(t==="svg"){const l=r&&typeof r.toBase64Image=="function"?ts(e,r,i):e.classList.contains("flow-card")?en(e,i):Ji(e,i);tn(new Blob([l],{type:"image/svg+xml;charset=utf-8"}),`${n}.svg`),Ae(e,"SVG downloaded");return}let a;if(r&&typeof r.toBase64Image=="function")a=await Ja(e,r,i);else{const l=e.classList.contains("flow-card"),c=l?en(e,i):Ji(e,i),{width:d,height:p}=ot(e),h=l?c.match(/<svg[^>]*width="(\d+)"[^>]*height="(\d+)"/):null;a=await Qa(c,h?Number(h[1]):d+48,h?Number(h[2]):p+48)}const s=await new Promise(l=>a.toBlob(l,"image/png"));if(!s)throw new Error("The browser could not create the PNG image");if(t==="copy"){if(typeof ClipboardItem<"u"&&navigator.clipboard?.write)await navigator.clipboard.write([new ClipboardItem({"image/png":s})]);else if(navigator.clipboard?.writeText)await navigator.clipboard.writeText(a.toDataURL("image/png"));else throw new Error("Image clipboard access is unavailable");Ae(e,"Image copied")}else tn(s,`${n}.png`),Ae(e,"PNG downloaded")}catch(o){console.warn("[IUI] Image export failed:",o),Ae(e,`Export failed: ${o instanceof Error?o.message.slice(0,90):"Unknown error"}`)}}function Ne(e,t={}){const i=document.createElementNS("http://www.w3.org/2000/svg",e);for(const[n,o]of Object.entries(t))i.setAttribute(n,o);return i}function oo(e,t){t&&e.appendChild(u("div",{class:"iui-title"},t))}function wt(e){const t=Math.abs(e)>=1e4?"compact":"standard";return new Intl.NumberFormat(void 0,{maximumFractionDigits:2,notation:t}).format(e)}function is(e,t){const i=u("div",{class:"iui-card iui-chart-card iui-heatmap-card","data-theme":t.theme});oo(i,e.title);const n=e.labels,o=e.datasets.map(d=>({label:d.label,values:d.data.map(p=>typeof p=="number"?p:NaN)})),r=o.flatMap(d=>d.values).filter(Number.isFinite),a=Math.min(...r),s=Math.max(...r),l=t.theme==="dark",c=u("div",{class:"iui-heatmap-grid",role:"table","aria-label":e.title||"Heatmap"});c.style.setProperty("--iui-heatmap-columns",String(n.length)),c.appendChild(u("span",{class:"iui-heatmap-corner",role:"presentation"}));for(const d of n)c.appendChild(u("span",{class:"iui-heatmap-col-label",role:"columnheader",title:d},d));if(o.forEach(d=>{c.appendChild(u("span",{class:"iui-heatmap-row-label",role:"rowheader",title:d.label},d.label)),d.values.forEach((p,h)=>{const f=s===a?.5:Math.max(0,Math.min(1,(p-a)/(s-a))),g=210-f*35,b=l?22+f*32:96-f*30,m=u("span",{class:"iui-heatmap-cell",role:"cell",title:`${d.label} / ${n[h]}: ${Number.isFinite(p)?p:"\u2014"}${e.unit?` ${e.unit}`:""}`,"aria-label":`${d.label}, ${n[h]}: ${Number.isFinite(p)?p:"no value"}`},Number.isFinite(p)?wt(p):"\u2014");m.style.backgroundColor=`hsl(${g} 52% ${b}%)`,m.style.color=f>.63?l?"#101010":"#fff":l?"#f5f5f5":"#292929",m.style.padding="2px 5px",c.appendChild(m)})}),i.appendChild(c),r.length){const d=u("span",{class:"iui-heatmap-legend-bar"});d.style.background=l?"linear-gradient(90deg, hsl(210 52% 22%), hsl(175 52% 54%))":"linear-gradient(90deg, hsl(210 52% 96%), hsl(175 52% 66%))";const p=u("div",{class:"iui-heatmap-legend","aria-hidden":"true"},u("span",{},wt(a)),d,u("span",{},`${wt(s)}${e.unit?` ${e.unit}`:""}`));i.appendChild(p)}return i}var nn={minLon:-180,maxLon:180,minLat:-90,maxLat:90};function ns(e,t,i,n){if(!e.length)return nn;const o=e.map(x=>x.point.x),r=e.map(x=>x.point.y),a=Math.min(...o),s=Math.max(...o),l=Math.min(...r),c=Math.max(...r),d=s-a,p=c-l;if(d>=200||p>=100)return nn;let h=Math.max(d,8)*1.36,f=Math.max(p,6)*1.36;const g=(t-n*2)/(i-n*2);h/f<g?h=Math.min(360,f*g):f=Math.min(180,h/g);const b=(a+s)/2,m=(l+c)/2,C=Math.max(-180,Math.min(180-h,b-h/2)),v=Math.min(180,C+h),w=Math.max(-90,Math.min(90-f,m-f/2));return{minLon:C,maxLon:v,minLat:w,maxLat:Math.min(90,w+f)}}function yt(e,t,i,n,o,r){const a=r.maxLon-r.minLon||1,s=r.maxLat-r.minLat||1;return{x:o+(e-r.minLon)/a*(i-o*2),y:o+(r.maxLat-t)/s*(n-o*2)}}function on(e,t,i){const n=[],o=Math.ceil(e/i)*i;for(let r=o;r<t;r+=i)r>e&&n.push(r);return n}function os(e){const t=u("div",{class:"iui-card iui-chart-card iui-geo-card"});oo(t,e.title);const i=720,n=330,o=22,r=[],a=["#5488c7","#48a477","#c88445","#8c75bd","#c45f75","#4d9ca4"];e.datasets.forEach((m,C)=>m.data.forEach((v,w)=>{typeof v!="number"&&r.push({point:v,label:v.label||`${m.label} ${w+1}`,series:C,color:a[C%a.length]})}));const s=ns(r,i,n,o),l=s.maxLon-s.minLon,c=l>=180?60:l>=45?15:l>=15?5:2,d=l>=180?30:l>=45?10:l>=15?5:2,p=Ne("svg",{class:"iui-geo-map",viewBox:`0 0 ${i} ${n}`,role:"img","aria-label":e.title?`Geographic chart: ${e.title}`:"Geographic chart of locations"});p.appendChild(Ne("rect",{x:String(o),y:String(o),width:String(676),height:String(286),rx:"10",class:"iui-geo-frame"}));for(const m of on(s.minLon,s.maxLon,c)){const C=yt(m,s.minLat,i,n,o,s);p.appendChild(Ne("line",{x1:String(C.x),y1:String(o),x2:String(C.x),y2:String(308),class:"iui-geo-graticule"}))}for(const m of on(s.minLat,s.maxLat,d)){const C=yt(s.minLon,m,i,n,o,s);p.appendChild(Ne("line",{x1:String(o),y1:String(C.y),x2:String(698),y2:String(C.y),class:"iui-geo-graticule"}))}const h=r.map(m=>m.point.value).filter(m=>m!==void 0&&Number.isFinite(m)),f=h.length?Math.min(...h):0,g=h.length?Math.max(...h):0;for(const m of r){const{x:C,y:v}=yt(m.point.x,m.point.y,i,n,o,s),w=m.point.value===void 0||g===f?.5:(m.point.value-f)/(g-f),x=Math.max(4,Math.min(16,m.point.r||5+w*10)),y=Ne("circle",{cx:String(C),cy:String(v),r:String(x),fill:m.color,class:"iui-geo-point"}),k=Ne("title");k.textContent=`${m.label}: ${m.point.y.toFixed(2)}\u00b0, ${m.point.x.toFixed(2)}\u00b0${m.point.value!==void 0?` \u00b7 ${m.point.value}${e.unit?` ${e.unit}`:""}`:""}`,y.appendChild(k),p.appendChild(y)}t.appendChild(p);const b=u("div",{class:"iui-geo-key","aria-label":"Mapped locations"});if(e.datasets.length>1)e.datasets.forEach((m,C)=>{const v=r.filter(y=>y.series===C).length;if(!v)return;const w=u("span",{class:"iui-geo-key-dot","aria-hidden":"true"});w.style.backgroundColor=a[C%a.length];const x=v>1?`${m.label} (${v})`:m.label;b.appendChild(u("span",{class:"iui-geo-key-item",title:x},w,x))});else{for(const m of r.slice(0,12)){const C=u("span",{class:"iui-geo-key-dot","aria-hidden":"true"});C.style.backgroundColor=m.color,b.appendChild(u("span",{class:"iui-geo-key-item",title:m.label},C,m.label))}r.length>12&&b.appendChild(u("span",{class:"iui-geo-key-more"},`+${r.length-12} more`))}return t.appendChild(b),t}var kt=null;async function rs(){return kt||(kt=ni(()=>import("./assets/chart-CoJ-C5d_.js").then(e=>(e.Chart.register(e.BarController,e.LineController,e.PieController,e.DoughnutController,e.RadarController,e.ScatterController,e.BubbleController,e.CategoryScale,e.LinearScale,e.RadialLinearScale,e.BarElement,e.LineElement,e.PointElement,e.ArcElement,e.Tooltip,e.Legend,e.Title,e.Filler),e.Chart)),__vite__mapDeps([0,1]))),kt}var as='ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Google Sans", Inter, sans-serif',ro=["#A9D3F5","#A6DEC0","#F6C0A0","#C6B9F2","#F2DC8A","#F2B1C0","#D6D6D3"],ss=["#6FA8D6","#6DBF95","#D9946C","#9585D6","#CDB45A","#D47F95","#8F8F8B"],ls=["#1F5F8F","#1E6B48","#8C4A20","#4C3D91","#7A5E10","#8E2E46","#4A4A47"],cs=[...ro];function rn(e,t){const i=e.replace("#","");return`rgba(${parseInt(i.substring(0,2),16)}, ${parseInt(i.substring(2,4),16)}, ${parseInt(i.substring(4,6),16)}, ${t})`}function ds(e,t,i=!1,n){const o=t==="dark";let r=o?ss:ro,a=o?cs:ls,s=o?"#0A0A0A":"#FFFFFF",l=o?"#A3A3A3":"#6B6B6B",c=o?"#262626":"#E7E7E7",d=o?"#FAFAFA":"#0A0A0A",p=o?"#0A0A0A":"#FAFAFA",h=as;n==="gemini"?(r=o?["#A8C7FA","#81C995","#FDD663","#F28B82","#0B57D0","#137333","#C4C7C5"]:["#0B57D0","#1E8E3E","#A8C7FA","#F9AB00","#D93025","#81C995","#747775"],a=o?["#D3E3FD","#C4EED0","#FFE082","#F9DEDC","#A8C7FA","#81C995","#E3E3E3"]:["#041E49","#072711","#0B57D0","#3F2E00","#410E0B","#137333","#1F1F1F"],s=o?"#1E1F20":"#F0F4F9",l=o?"#C4C7C5":"#444746",c=o?"#3C4043":"#E1E3E1",d=o?"#E3E3E3":"#1F1F1F",p=o?"#131314":"#FFFFFF",h='"Google Sans Text", "Google Sans", Roboto, Arial, sans-serif'):n==="grok"&&(r=o?["#F5F5F5","#A3A3A3","#737373","#525252","#383838","#262626"]:["#0D0D0D","#525252","#737373","#9A9A9A","#C4C4C4","#E0E0E0"],a=o?["#FFFFFF","#D4D4D4","#A3A3A3","#737373","#525252","#404040"]:["#0D0D0D","#262626","#404040","#525252","#737373","#8A8A8A"],s=o?"#141414":"#FFFFFF",l=o?"#A3A3A3":"#6B6B6B",c=o?"rgba(255,255,255,.08)":"rgba(0,0,0,.08)",d=o?"#F5F5F5":"#0D0D0D",p=o?"#141414":"#FFFFFF",h='ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif');const f=e.chartType==="pie"||e.chartType==="doughnut";let g=[];if(e.chartType==="bar")g=e.datasets.map((w,x)=>({label:w.label,data:w.data,backgroundColor:r[x%r.length],borderColor:a[x%a.length],borderWidth:1,borderRadius:4,borderSkipped:"bottom",maxBarThickness:28,barPercentage:.72,categoryPercentage:.78,grouped:!0}));else if(e.chartType==="line"||e.chartType==="area")g=e.datasets.map((w,x)=>({label:w.label,data:w.data,borderColor:a[x%a.length],borderWidth:2.5,tension:.35,pointRadius:2.5,pointHoverRadius:6,pointBackgroundColor:r[x%r.length],pointBorderColor:a[x%a.length],pointBorderWidth:1,pointHoverBorderWidth:2,fill:e.chartType==="area"?"origin":!1}));else if(e.chartType==="scatter"||e.chartType==="bubble")g=e.datasets.map((w,x)=>({label:w.label,data:w.data,backgroundColor:rn(r[x%r.length],.72),borderColor:a[x%a.length],borderWidth:1.5,pointRadius:e.chartType==="scatter"?4:void 0,pointHoverRadius:7}));else if(f){const w=e.labels.map((x,y)=>r[y%r.length]);g=e.datasets.map(x=>({label:x.label,data:x.data,backgroundColor:w,borderColor:s,borderWidth:2,borderRadius:4,hoverOffset:8}))}else e.chartType==="radar"&&(g=e.datasets.map((w,x)=>({label:w.label,data:w.data,borderColor:a[x%a.length],borderWidth:1.5,backgroundColor:rn(r[x%r.length],.35),fill:!0,pointRadius:3,pointBackgroundColor:r[x%r.length],pointBorderColor:a[x%a.length],pointBorderWidth:1})));let b;e.chartType==="bar"||e.chartType==="line"||e.chartType==="area"?b={x:{stacked:!1,title:{display:!!e.xLabel,text:e.xLabel||"",color:l,font:{family:h,size:11},padding:{top:6}},grid:{display:!1},border:{display:!1},ticks:{color:l,maxRotation:35,minRotation:0,autoSkip:!0,autoSkipPadding:14,padding:6,font:{family:h,size:11}}},y:{stacked:!1,beginAtZero:e.chartType==="bar",title:{display:!!e.yLabel,text:e.yLabel||"",color:l,font:{family:h,size:11},padding:{bottom:6}},grid:{display:!0,color:"color-mix(in srgb, var(--iui-text, #000) 6%, transparent)",lineWidth:1,drawTicks:!1},border:{display:!1},ticks:{color:l,padding:8,font:{family:h,size:11}}}}:e.chartType==="scatter"||e.chartType==="bubble"?b={x:{type:"linear",title:{display:!!e.xLabel,text:e.xLabel||"",color:l},grid:{color:c,drawTicks:!1},border:{display:!1},ticks:{color:l,maxTicksLimit:8,font:{family:h,size:11}}},y:{type:"linear",title:{display:!!e.yLabel,text:e.yLabel||"",color:l},grid:{color:c,drawTicks:!1},border:{display:!1},ticks:{color:l,maxTicksLimit:8,font:{family:h,size:11}}}}:e.chartType==="radar"&&(b={r:{grid:{color:c,lineWidth:1},angleLines:{color:c,lineWidth:1},border:{display:!1},ticks:{color:l,backdropColor:"transparent",maxTicksLimit:5,font:{family:h,size:10}},pointLabels:{color:l,padding:10,font:{family:h,size:11}}}});const m=f?e.labels.length>1:e.datasets.length>1,C=e.chartType==="radar"?14:f?{top:10,right:14,bottom:10,left:14}:{top:8,right:10,bottom:6,left:6},v=i?{duration:800,easing:"easeOutQuart"}:!1;return{type:e.chartType==="area"?"line":e.chartType,data:{labels:e.labels,datasets:g},options:{responsive:!0,maintainAspectRatio:!1,animation:v,plugins:{legend:{display:m,position:f?"bottom":"top",align:f?"center":"start",labels:{usePointStyle:!0,pointStyle:"circle",color:l,font:{family:h,size:11},padding:f?14:12,boxWidth:f?10:6,boxHeight:f?10:6}},title:{display:!1},tooltip:{backgroundColor:d,titleColor:p,bodyColor:p,cornerRadius:8,padding:{top:8,right:12,bottom:8,left:12},displayColors:!0,boxPadding:5,caretSize:5,titleFont:{family:h,size:12,weight:600},bodyFont:{family:h,size:12},callbacks:{label:w=>{const x=w.raw;if(x&&typeof x=="object"&&"x"in x&&"y"in x){const E=x,z=w.dataset?.label||"",L=`(${E.x}, ${E.y})`;return`${z?`${z}: `:""}${L}`}const y=typeof x=="number"?x:Number(x),k=Number.isNaN(y)?String(x??""):y.toLocaleString(),A=e.unit?` ${e.unit}`:"";if(f){const E=w.label||"";return E?`${E}: ${k}${A}`:`${k}${A}`}const S=w.dataset?.label||"";return S?`${S}: ${k}${A}`:`${k}${A}`}}}},...b?{scales:b}:{},interaction:{mode:e.chartType==="scatter"||e.chartType==="bubble"?"nearest":"index",intersect:!1},layout:{padding:C}}}}function ao(e,t){if(e.chartType==="heatmap")return is(e,t);if(e.chartType==="geo")return os(e);const i=u("div",{class:"iui-card iui-chart-card"});e.title&&i.appendChild(u("div",{class:"iui-title"},e.title));const n=e.chartType==="pie"||e.chartType==="doughnut"?e.labels.length>1:e.datasets.length>1,o=["bar","line","area","pie","doughnut","radar"].includes(e.chartType);if(o){const h=u("div",{class:"iui-chart-controls"});let f="chart",g=null;const b=(C,v)=>u("button",{type:"button",class:`iui-chart-view-btn${v==="chart"?" is-active":""}`,"aria-pressed":v==="chart"?"true":"false",onClick:()=>{if(f!==v&&(f=v,h.querySelectorAll(".iui-chart-view-btn").forEach((w,x)=>{const y=x===0&&v==="chart"||x===1&&v==="table";w.classList.toggle("is-active",y),w.setAttribute("aria-pressed",String(y))}),s.hidden=v!=="chart",g&&(g.hidden=v!=="table"),v==="table"&&g&&g.childElementCount===0)){const w=e.datasets.length>1?[e.xLabel||"Label",...e.datasets.map(A=>A.label)]:[e.xLabel||"Label",e.datasets[0]?.label||"Value"],x=e.labels.map((A,S)=>e.datasets.length>1?[A,...e.datasets.map(E=>String(E.data[S]??""))]:[A,String(e.datasets[0]?.data[S]??"")]),y={type:"table",title:e.title,columns:w,rows:x},k=lo(y,t,{allowViewSwitch:!1});g.appendChild(k)}}},C),m=u("div",{class:"iui-chart-view-switch",role:"group","aria-label":"Chart view mode"},b("Chart","chart"),b("Table","table"));h.appendChild(m),i.appendChild(h),g=u("div",{class:"iui-chart-table-view",role:"region","aria-label":e.title?`${e.title} data table`:"Chart data table",hidden:!0}),i.__chartTableHost=g}const r=e.title?`${e.chartType} chart: ${e.title}`:`${e.chartType} chart`,a=u("canvas",{role:"img","aria-label":r}),s=u("div",{class:"iui-chart-plot",role:"region","aria-label":r,"data-chart-type":e.chartType,"data-has-legend":n?"true":"false",style:"position: relative;"},a);i.appendChild(s),o&&i.__chartTableHost&&(i.appendChild(i.__chartTableHost),delete i.__chartTableHost);const l=typeof window<"u"&&window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches,c=ds(e,t.theme,!l,t.host);let d=!1,p=null;return t.onCleanup(()=>{if(d=!0,p)try{p.destroy()}catch{}}),i.__chartReady=rs().then(h=>{if(d)return null;try{return p=new h(a,c),i.__chartInstance=p,a.__chartInstance=p,p}catch(f){return console.warn("[IUI] Chart initialization failed:",f),null}}).catch(h=>(console.warn("[IUI] Failed to load Chart.js:",h),null)),i}function _e(e){if(typeof e!="string")return null;const t=e.trim();if(!t)return null;const i=t.replace(/[\s,\u20B9$\u20AC%]/g,""),n=/^([+-]?(?:\d+\.?\d*|\.\d+))([kKmMbB])?$/.exec(i);if(!n)return null;const o=parseFloat(n[1]);if(Number.isNaN(o))return null;const r=n[2]?.toLowerCase();return r==="k"?o*1e3:r==="m"?o*1e6:r==="b"?o*1e9:o}function Wt(e){if(typeof e!="string")return null;const t=e.trim();if(!t||t.length<4||/^[+-]?\d+(?:\.\d+)?$/.test(t)||/[\$\u20AC\u20B9%]/.test(t)||!(/^\d{4}[-/.]\d{1,2}[-/.]\d{1,2}/.test(t)||/^\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}/.test(t)||/^[A-Za-z]{3,}\.?\s+\d{1,2}/.test(t)||/^\d{1,2}\s+[A-Za-z]{3,}/.test(t)||/^\d{4}-\d{2}-\d{2}T/.test(t)))return null;const i=Date.parse(t);return Number.isNaN(i)?null:i}function so(e,t){const i=n=>String(n??"").replace(/[\t\r\n]+/g," ").trim();return[e,...t].map(n=>n.map(i).join("	")).join(`
`)}function us(e,t){let i=!1,n=!0,o=!0;for(const r of e){const a=r[t];a!==void 0&&a.trim()!==""&&(i=!0,_e(a)===null&&(n=!1),Wt(a)===null&&(o=!1))}return i&&n?"numeric":i&&o?"date":"string"}function ps(e,t,i){if(i==="numeric"){const n=_e(e),o=_e(t);if(n!==null&&o!==null)return n-o}else if(i==="date"){const n=Wt(e),o=Wt(t);if(n!==null&&o!==null)return n-o}return e.localeCompare(t,void 0,{numeric:!0})}function lo(e,t,i={}){const n=u("div",{class:"iui-card iui-table-card"});e.title&&n.appendChild(u("div",{class:"iui-title"},e.title));const o=e.columns||[],r=e.rows||[],a=o.map((I,M)=>us(r,M)),s=a.map(I=>I==="numeric"),l=s.some(Boolean),c=i.allowViewSwitch!==!1&&o.length>=2&&l&&r.length>0,d=o.map((I,M)=>{if(!s[M]||r.length<2)return null;let q=0,V=0;for(const U of r){const G=_e(U[M]??"");if(G!==null){if(G<0)return null;G>q&&(q=G),V++}}return V>=2&&q>0?q:null}),p=o.map((I,M)=>{if(!s[M]||r.length<2)return null;let q=0,V=0;for(const U of r){const G=_e(U[M]??"");G!==null&&(q+=G,V++)}return V>=2?{sum:q,avg:q/V,count:V}:null}),h=r.map((I,M)=>({row:I,idx:M}));let f=null,g="none",b="",m="table",C=[...h];const v=u("div",{class:"iui-table-actions"}),w=u("div",{class:"iui-table-actions-right"}),x=u("button",{class:"iui-table-copy-btn",type:"button","aria-label":"Copy table data as plain text",onClick:async()=>{const I=so(o,r);try{if(navigator.clipboard?.writeText)await navigator.clipboard.writeText(I);else{const M=u("textarea",{class:"iui-table-copy-fallback",readonly:!0});M.value=I,n.appendChild(M),M.select();const q=document.execCommand("copy");if(M.remove(),!q)throw new Error("Clipboard access is unavailable")}Ae(n,"Table data copied \u00b7 Paste into Sheets or Excel")}catch{Ae(n,"Could not copy table data. Check clipboard permissions.")}}},K("copy",14),"Copy data");w.appendChild(x);let y,k=null,A=null,S=null;const E=[];function z(I){if(!A)return;if(de(A),I.length===0){A.appendChild(u("div",{class:"iui-table-cards-empty"},"No matching rows"));return}const M=Math.max(0,s.findIndex(V=>!V)),q=u("div",{class:"iui-table-cards-grid"});for(const V of I){const U=u("div",{class:"iui-table-kv-card"}),G=u("div",{class:"iui-table-kv-head"});xe(G,V.row[M]??""),U.appendChild(G);const te=u("div",{class:"iui-table-kv-body"});for(let H=0;H<o.length;H++){if(H===M)continue;const J=u("div",{class:"iui-table-kv-row"});J.appendChild(u("span",{class:"iui-table-kv-key"},o[H]??""));const oe=u("span",{class:`iui-table-kv-val${s[H]?" is-numeric":""}`});xe(oe,V.row[H]??""),J.appendChild(oe),te.appendChild(J)}U.appendChild(te),q.appendChild(U)}A.appendChild(q)}function L(I){if(!k)return;S?.(),S=null,de(k);const M=Math.max(0,s.findIndex(H=>!H)),q=o.map((H,J)=>J).filter(H=>H!==M&&s[H]),V=q.length>0?q:o.map((H,J)=>J).filter(H=>H!==M),U={type:"chart",chartType:a[M]==="date"?"line":"bar",labels:I.map(H=>H.row[M]??""),datasets:V.map(H=>({label:o[H]??`Col ${H+1}`,data:I.map(J=>_e(J.row[H]??"")??0)}))},G={...t,onCleanup:H=>{S=H,t.onCleanup(H)}},te=ao(U,G);k.appendChild(te)}function F(I){m=I;for(const M of E){const q=M.mode===m;M.btn.classList.toggle("is-active",q),M.btn.setAttribute("aria-pressed",String(q))}y.hidden=m!=="table",k&&(k.hidden=m!=="chart",m==="chart"&&L(C)),A&&(A.hidden=m!=="cards",m==="cards"&&z(C))}if(c){const I=u("div",{class:"iui-table-view-switch",role:"group","aria-label":"Table view mode"});for(const M of[{mode:"table",label:"Table"},{mode:"chart",label:"Chart"},{mode:"cards",label:"Cards"}]){const q=u("button",{type:"button",class:`iui-table-view-btn${M.mode==="table"?" is-active":""}`,"aria-pressed":M.mode==="table"?"true":"false",onClick:()=>F(M.mode)},M.label);E.push({mode:M.mode,btn:q}),I.appendChild(q)}w.prepend(I)}v.appendChild(w);let B=null;if(r.length>6){const I=u("div",{class:"iui-table-filter-bar"}),M=u("div",{class:"iui-table-filter-wrap"}),q=K("magnifying-glass",14,"iui-table-filter-icon"),V=u("input",{class:"iui-table-filter-input",type:"search",placeholder:"Filter rows...","aria-label":"Filter table rows",onInput:U=>{b=U.target.value.trim().toLowerCase(),_()}});B=u("span",{class:"iui-table-filter-count"},`${r.length} of ${r.length} rows`),M.appendChild(q),M.appendChild(V),I.appendChild(M),I.appendChild(B),v.prepend(I)}n.appendChild(v),y=u("div",{class:"iui-table-wrap"});const O=u("div",{class:"iui-table-scroll"}),D=u("table",{class:"iui-table"}),P=u("thead",{class:"iui-table-header c-stone"}),R=u("tr",{class:"iui-table-header-tr"}),Q=u("tbody",{class:"iui-table-tbody"});function ee(I){if(de(Q),I.length===0){const M=u("tr",{class:"iui-table-empty-tr"}),q=u("td",{class:"iui-table-empty-td",colspan:String(Math.max(o.length,1))},"No matching rows");M.appendChild(q),Q.appendChild(M);return}for(const M of I){const q=u("tr",{class:"iui-table-tr"});q.style.setProperty("--row-idx",String(M.idx));let V=null;if(e.highlight){const U=e.highlight==="min";let G=U?1/0:-1/0,te=0;for(let H=0;H<o.length;H++){const J=_e(M.row[H]??"");J!==null&&(te++,(U?J<G:J>G)&&(G=J,V=H))}te<2&&(V=null)}for(let U=0;U<o.length;U++){const G=M.row[U]??"",te=["iui-table-td"];s[U]&&te.push("is-numeric");const H=e.highlight&&U===V;H&&te.push("is-highlighted");const J=u("td",{class:te.join(" ")}),oe=d[U];if(oe!==null){J.style.position="relative";const ae=_e(G);if(ae!==null&&ae>=0){const fe=Math.min(100,Math.max(0,ae/oe*100)),ue=u("span",{class:"iui-table-cell-bar","aria-hidden":"true"});ue.style.width=`${fe.toFixed(1)}%`,J.appendChild(ue)}}if(H){const ae=u("span",{class:"iui-table-highlight-pill c-mint"});xe(ae,G),J.appendChild(ae)}else{const ae=oe!==null?u("span",{class:"iui-table-cell-val"}):J;xe(ae,G),ae!==J&&J.appendChild(ae)}q.appendChild(J)}Q.appendChild(q)}}const X=[],j=[],$=[];function _(){let I=h;b&&(I=h.filter(q=>q.row.some(V=>V.toLowerCase().includes(b)))),B&&(B.textContent=`${I.length} of ${r.length} rows`);let M;if(f===null||g==="none")M=[...I];else{const q=f,V=g,U=a[q];M=[...I].sort((G,te)=>{const H=ps(G.row[q]??"",te.row[q]??"",U);return H===0?G.idx-te.idx:V==="asc"?H:-H})}C=M,ee(M),m==="chart"&&L(M),m==="cards"&&z(M);for(let q=0;q<o.length;q++){const V=X[q],U=j[q],G=$[q];if(de(G),f===q&&g!=="none"){const te=g==="asc"?"ascending":"descending";V.setAttribute("aria-sort",te),U.setAttribute("aria-sort",te);const H=g==="asc"?"caret-up":"caret-down";G.appendChild(K(H,12,"iui-table-caret-svg"))}else V.setAttribute("aria-sort","none"),U.setAttribute("aria-sort","none")}}for(let I=0;I<o.length;I++){const M=o[I]??"",q=["iui-table-th"];s[I]&&q.push("is-numeric");const V=u("span",{class:"iui-table-sort-arrow"});$.push(V);const U=u("button",{class:"iui-table-th-btn",type:"button","aria-sort":"none",onClick:()=>{f!==I?(f=I,g="asc"):g==="asc"?g="desc":g==="desc"?(g="none",f=null):g="asc",_()},onKeyDown:te=>{const H=te;(H.key==="Enter"||H.key===" ")&&(te.preventDefault(),U.click())}},M,V);j.push(U);const G=u("th",{class:q.join(" "),scope:"col","aria-sort":"none"},U);X.push(G),R.appendChild(G)}if(P.appendChild(R),D.appendChild(P),D.appendChild(Q),p.some(Boolean)){const I=u("tfoot",{class:"iui-table-tfoot"}),M=u("tr",{class:"iui-table-summary-tr"}),q=Math.max(0,s.findIndex(V=>!V));for(let V=0;V<o.length;V++){const U=p[V];if(U){const G=te=>te.toLocaleString(void 0,{maximumFractionDigits:2});M.appendChild(u("td",{class:"iui-table-summary-td is-numeric"},u("span",{class:"iui-table-summary-sum"},`\u03a3 ${G(U.sum)}`),u("span",{class:"iui-table-summary-avg"},`Avg ${G(U.avg)}`)))}else V===q?M.appendChild(u("td",{class:"iui-table-summary-td is-label"},"Summary")):M.appendChild(u("td",{class:"iui-table-summary-td"}))}I.appendChild(M),D.appendChild(I)}return O.appendChild(D),y.appendChild(O),n.appendChild(y),c&&(k=u("div",{class:"iui-table-chart-view",hidden:!0}),A=u("div",{class:"iui-table-cards-view",hidden:!0}),n.appendChild(k),n.appendChild(A)),_(),n}function hs(e,t){const i=u("div",{class:"iui-card iui-compare-card"});e.title&&i.appendChild(u("div",{class:"iui-title"},e.title));const n=e.items||[],o=n.reduce((d,p)=>d+(p.points?.length||0),0);let r="",a=null;function s(){return Array.from(i.querySelectorAll(".iui-compare-panel"))}function l(){const d=s();for(let p=0;p<d.length;p++){const h=d[p];a!==null?(h.classList.toggle("is-dimmed",p!==a),h.classList.toggle("is-focused",p===a)):h.classList.remove("is-dimmed","is-focused"),h.setAttribute("aria-pressed",String(a===p));const f=h.querySelectorAll(".iui-compare-point");for(const g of f)r?g.hidden=!(g.textContent?.toLowerCase()??"").includes(r):g.hidden=!1}}if(o>8){const d=u("div",{class:"iui-compare-filter-wrap"}),p=u("input",{class:"iui-compare-filter-input",type:"search",placeholder:"Filter points\u2026","aria-label":"Filter comparison points",onInput:h=>{r=h.target.value.trim().toLowerCase(),l()}});d.appendChild(K("magnifying-glass",13,"iui-compare-filter-icon")),d.appendChild(p),i.appendChild(d)}const c=u("div",{class:"iui-compare-grid"});for(let d=0;d<n.length;d++){const p=n[d],h=p.tone||"neutral";let f="c-stone",g="info";h==="good"?(f="c-mint",g="check-circle"):h==="bad"&&(f="c-rose",g="x-circle");const b=u("div",{class:`iui-compare-panel ${f}`,role:"button",tabindex:"0","aria-label":`${p.label}, focus comparison panel`,"aria-pressed":"false",onClick:()=>{a===d?a=null:a=d,l()},onKeyDown:k=>{const A=k;(A.key==="Enter"||A.key===" ")&&(k.preventDefault(),b.click())}}),m=u("div",{class:"iui-compare-header"}),C=u("div",{class:"iui-compare-iconbox"},K(g,16)),v=u("span",{class:"iui-compare-label"},p.label);m.appendChild(C),m.appendChild(v);const w=p.badge;w&&m.appendChild(u("span",{class:"iui-compare-badge"},w)),b.appendChild(m);const x=u("div",{class:"iui-compare-points"}),y=p.points||[];for(const k of y){const A=u("div",{class:"iui-compare-point"});let S;h==="good"?S=u("span",{class:"iui-compare-point-icon"},K("check",14)):h==="bad"?S=u("span",{class:"iui-compare-point-icon"},K("x",14)):S=u("span",{class:"iui-compare-dot"});const E=u("span",{class:"iui-compare-point-text"},k);A.appendChild(S),A.appendChild(E),x.appendChild(A)}b.appendChild(x),c.appendChild(b)}return i.appendChild(c),i}function fs(e){return(e||"").replace(/^\s*(step\s*)?\d+\s*[.):-]\s*/i,"").trim()}function gs(e,t){const i=u("div",{class:"iui-card iui-stepper-card"});e.title&&i.appendChild(u("div",{class:"iui-title"},e.title));const n=e.steps||[],o=n.length,r=new Set,a=u("div",{class:"iui-stepper-progress-wrap","aria-hidden":"true"}),s=u("div",{class:"iui-stepper-progress-fill"});s.style.width="0%",a.appendChild(s),i.appendChild(a);function l(){const d=o>0?Math.round(r.size/o*100):0;s.style.width=`${d}%`}const c=u("div",{class:"iui-stepper-list"});for(let d=0;d<n.length;d++){const p=n[d],h=d===n.length-1,f=u("div",{class:"iui-stepper-step"});f.style.setProperty("--step-idx",String(d));const g=u("div",{class:"iui-stepper-track"}),b=u("button",{type:"button",class:"iui-stepper-circle c-sky","aria-label":`Mark step ${d+1} complete`,"aria-pressed":"false",onClick:()=>{r.has(d)?(r.delete(d),b.setAttribute("aria-pressed","false"),b.classList.remove("is-done"),b.textContent="",b.appendChild(u("span",{},String(d+1))),f.classList.remove("is-completed")):(r.add(d),b.setAttribute("aria-pressed","true"),b.classList.add("is-done"),b.textContent="",b.appendChild(K("check",11)),f.classList.add("is-completed")),l()}},String(d+1));if(g.appendChild(b),!h){const w=u("div",{class:"iui-stepper-line"});g.appendChild(w)}f.appendChild(g);const m=u("div",{class:`iui-stepper-content${h?" is-last":""}`}),C=fs(p.title),v=u("div",{class:"iui-stepper-title"});if(xe(v,C),m.appendChild(v),p.detail!==void 0&&p.detail!==""){const w=u("div",{class:"iui-stepper-detail"});xe(w,p.detail),m.appendChild(w)}f.appendChild(m),c.appendChild(f)}return i.appendChild(c),i}function ms(e,t){const i=u("div",{class:"iui-card iui-quiz-card"}),n=e.questions||[];let o=0;const r=new Map;let a=!1;function s(){let c=0;for(let d=0;d<n.length;d++)r.get(d)===n[d].answer&&c++;return c}function l(){if(de(i),n.length===0){e.title&&i.appendChild(u("div",{class:"iui-title iui-quiz-title"},e.title)),i.appendChild(u("div",{class:"iui-quiz-empty"},"No quiz questions available."));return}const c=u("div",{class:"iui-quiz-header"}),d=e.title||"",p=d?u("div",{class:"iui-title iui-quiz-title"},d):u("div",{class:"iui-quiz-title-spacer"});c.appendChild(p);const h=u("div",{class:"iui-quiz-header-right"});if(a){const x=u("span",{class:"iui-quiz-counter"},"Completed");h.appendChild(x)}else{const x=u("span",{class:"iui-quiz-counter","aria-live":"polite"},`${o+1} of ${n.length}`);h.appendChild(x);const y=u("div",{class:"iui-quiz-nav",role:"group","aria-label":"Quiz navigation"}),k=u("button",{type:"button",class:"iui-quiz-nav-btn","aria-label":"Previous question",title:"Previous question",disabled:o===0,onClick:()=>{o>0&&(o--,l())}},K("chevron-left",14)),A=u("button",{type:"button",class:"iui-quiz-nav-btn","aria-label":"Next question",title:"Next question",disabled:o>=n.length-1,onClick:()=>{o<n.length-1&&(o++,l())}},K("chevron-right",14));y.appendChild(k),y.appendChild(A),h.appendChild(y)}if(c.appendChild(h),i.appendChild(c),a){const x=s(),y=u("div",{class:"iui-quiz-results"}),k=u("div",{class:"iui-quiz-score-text"},`You scored ${x} of ${n.length}`),A=u("button",{type:"button",class:"iui-btn-ghost iui-quiz-retry-btn",onClick:()=>{r.clear(),o=0,a=!1,l()}},"Retry");y.appendChild(k),y.appendChild(A),i.appendChild(y);return}const f=n[o],g=u("div",{class:"iui-quiz-q-container"}),b=u("div",{class:"iui-quiz-q-text"},f.q);g.appendChild(b);const m=u("div",{class:"iui-quiz-options"}),C=r.get(o),v=C!==void 0,w=f.options||[];for(let x=0;x<w.length;x++){const y=w[x],k=String.fromCharCode(65+x),A=C===x,S=x===f.answer,E=["iui-quiz-opt-row"];v&&(S?E.push("is-correct"):A&&E.push("is-incorrect"));const z=u("span",{class:"iui-quiz-letter-circle"},k),L=u("span",{class:"iui-quiz-opt-text"},y),F=u("button",{type:"button",class:E.join(" "),disabled:v,onClick:()=>{v||(r.set(o,x),l(),r.size===n.length&&setTimeout(()=>{if(i.isConnected&&!i.querySelector(".iui-quiz-finish-prompt")){const B=u("div",{class:"iui-quiz-finish-bar"},u("button",{type:"button",class:"iui-btn-ghost iui-quiz-finish-btn",onClick:()=>{a=!0,l()}},"View final score \u2192"));i.appendChild(B)}},400))}},z,L);m.appendChild(F)}if(g.appendChild(m),v&&f.explain){const x=u("div",{class:"iui-quiz-explain"},u("span",{class:"iui-quiz-explain-icon"},K("info",14)),u("span",{class:"iui-quiz-explain-text"},f.explain));g.appendChild(x)}i.appendChild(g)}return l(),i}var co=Object.defineProperty,bs=(e,t,i)=>t in e?co(e,t,{enumerable:!0,configurable:!0,writable:!0,value:i}):e[t]=i,xs=(e,t)=>{for(var i in t)co(e,i,{get:t[i],enumerable:!0})},vs=(e,t,i)=>bs(e,typeof t!="symbol"?t+"":t,i),uo={};xs(uo,{Graph:()=>ye,alg:()=>ri});var ws=Object.defineProperty,po=(e,t)=>{for(var i in t)ws(e,i,{get:t[i],enumerable:!0})},oi=class{constructor(e){this._isDirected=!0,this._isMultigraph=!1,this._isCompound=!1,this._nodes={},this._in={},this._preds={},this._out={},this._sucs={},this._edgeObjs={},this._edgeLabels={},this._nodeCount=0,this._edgeCount=0,this._defaultNodeLabelFn=()=>{},this._defaultEdgeLabelFn=()=>{},e&&(this._isDirected="directed"in e?e.directed:!0,this._isMultigraph="multigraph"in e?e.multigraph:!1,this._isCompound="compound"in e?e.compound:!1),this._isCompound&&(this._parent={},this._children={},this._children["\0"]={})}isDirected(){return this._isDirected}isMultigraph(){return this._isMultigraph}isCompound(){return this._isCompound}setGraph(e){return this._label=e,this}graph(){return this._label}setDefaultNodeLabel(e){return typeof e!="function"?this._defaultNodeLabelFn=()=>e:this._defaultNodeLabelFn=e,this}nodeCount(){return this._nodeCount}nodes(){return Object.keys(this._nodes)}sources(){return this.nodes().filter(e=>Object.keys(this._in[e]).length===0)}sinks(){return this.nodes().filter(e=>Object.keys(this._out[e]).length===0)}setNodes(e,t){return e.forEach(i=>{t!==void 0?this.setNode(i,t):this.setNode(i)}),this}setNode(e,t){return e in this._nodes?(arguments.length>1&&(this._nodes[e]=t),this):(this._nodes[e]=arguments.length>1?t:this._defaultNodeLabelFn(e),this._isCompound&&(this._parent[e]="\0",this._children[e]={},this._children["\0"][e]=!0),this._in[e]={},this._preds[e]={},this._out[e]={},this._sucs[e]={},++this._nodeCount,this)}node(e){return this._nodes[e]}hasNode(e){return e in this._nodes}removeNode(e){if(e in this._nodes){let t=i=>this.removeEdge(this._edgeObjs[i]);delete this._nodes[e],this._isCompound&&(this._removeFromParentsChildList(e),delete this._parent[e],this.children(e).forEach(i=>{this.setParent(i)}),delete this._children[e]),Object.keys(this._in[e]).forEach(t),delete this._in[e],delete this._preds[e],Object.keys(this._out[e]).forEach(t),delete this._out[e],delete this._sucs[e],--this._nodeCount}return this}setParent(e,t){if(!this._isCompound)throw new Error("Cannot set parent in a non-compound graph");if(t===void 0)t="\0";else{t+="";for(let i=t;i!==void 0;i=this.parent(i))if(i===e)throw new Error("Setting "+t+" as parent of "+e+" would create a cycle");this.setNode(t)}return this.setNode(e),this._removeFromParentsChildList(e),this._parent[e]=t,this._children[t][e]=!0,this}parent(e){if(this._isCompound){let t=this._parent[e];if(t!=="\0")return t}}children(e="\0"){if(this._isCompound){let t=this._children[e];if(t)return Object.keys(t)}else{if(e==="\0")return this.nodes();if(this.hasNode(e))return[]}return[]}predecessors(e){let t=this._preds[e];if(t)return Object.keys(t)}successors(e){let t=this._sucs[e];if(t)return Object.keys(t)}neighbors(e){let t=this.predecessors(e);if(t){let i=new Set(t),n=this.successors(e);if(n)for(let o of n)i.add(o);return Array.from(i.values())}}isLeaf(e){var t;let i;return this.isDirected()?i=this.successors(e):i=this.neighbors(e),((t=i?.length)!=null?t:0)===0}filterNodes(e){let t=new this.constructor({directed:this._isDirected,multigraph:this._isMultigraph,compound:this._isCompound});t.setGraph(this.graph()),Object.entries(this._nodes).forEach(([o,r])=>{e(o)&&t.setNode(o,r)}),Object.values(this._edgeObjs).forEach(o=>{t.hasNode(o.v)&&t.hasNode(o.w)&&t.setEdge(o,this.edge(o))});let i={},n=o=>{let r=this.parent(o);return!r||t.hasNode(r)?(i[o]=r,r):r in i?i[r]:n(r)};return this._isCompound&&t.nodes().forEach(o=>t.setParent(o,n(o))),t}setDefaultEdgeLabel(e){return typeof e!="function"?this._defaultEdgeLabelFn=()=>e:this._defaultEdgeLabelFn=e,this}edgeCount(){return this._edgeCount}edges(){return Object.values(this._edgeObjs)}setPath(e,t){return e.reduce((i,n)=>(t!==void 0?this.setEdge(i,n,t):this.setEdge(i,n),n)),this}setEdge(e,t,i,n){let o,r,a,s,l=!1;typeof e=="object"&&e!==null&&"v"in e?(o=e.v,r=e.w,a=e.name,arguments.length===2&&(s=t,l=!0)):(o=e,r=t,a=n,arguments.length>2&&(s=i,l=!0)),o=""+o,r=""+r,a!==void 0&&(a=""+a);let c=He(this._isDirected,o,r,a);if(c in this._edgeLabels)return l&&(this._edgeLabels[c]=s),this;if(a!==void 0&&!this._isMultigraph)throw new Error("Cannot set a named edge when isMultigraph = false");this.setNode(o),this.setNode(r),this._edgeLabels[c]=l?s:this._defaultEdgeLabelFn(o,r,a);let d=ys(this._isDirected,o,r,a);return o=d.v,r=d.w,Object.freeze(d),this._edgeObjs[c]=d,an(this._preds[r],o),an(this._sucs[o],r),this._in[r][c]=d,this._out[o][c]=d,this._edgeCount++,this}edge(e,t,i){let n=arguments.length===1?Ct(this._isDirected,e):He(this._isDirected,e,t,i);return this._edgeLabels[n]}edgeAsObj(e,t,i){let n=arguments.length===1?this.edge(e):this.edge(e,t,i);return typeof n!="object"||n===null?{label:n}:n}hasEdge(e,t,i){return(arguments.length===1?Ct(this._isDirected,e):He(this._isDirected,e,t,i))in this._edgeLabels}removeEdge(e,t,i){let n=arguments.length===1?Ct(this._isDirected,e):He(this._isDirected,e,t,i),o=this._edgeObjs[n];if(o){let r=o.v,a=o.w;delete this._edgeLabels[n],delete this._edgeObjs[n],sn(this._preds[a],r),sn(this._sucs[r],a),delete this._in[a][n],delete this._out[r][n],this._edgeCount--}return this}inEdges(e,t){return this.isDirected()?this.filterEdges(this._in[e],e,t):this.nodeEdges(e,t)}outEdges(e,t){return this.isDirected()?this.filterEdges(this._out[e],e,t):this.nodeEdges(e,t)}nodeEdges(e,t){if(e in this._nodes)return this.filterEdges({...this._in[e],...this._out[e]},e,t)}_removeFromParentsChildList(e){delete this._children[this._parent[e]][e]}filterEdges(e,t,i){if(!e)return;let n=Object.values(e);return i?n.filter(o=>o.v===t&&o.w===i||o.v===i&&o.w===t):n}};function an(e,t){e[t]?e[t]++:e[t]=1}function sn(e,t){e[t]!==void 0&&!--e[t]&&delete e[t]}function He(e,t,i,n){let o=""+t,r=""+i;if(!e&&o>r){let a=o;o=r,r=a}return o+""+r+""+(n===void 0?"\0":n)}function ys(e,t,i,n){let o=""+t,r=""+i;if(!e&&o>r){let s=o;o=r,r=s}let a={v:o,w:r};return n&&(a.name=n),a}function Ct(e,t){return He(e,t.v,t.w,t.name)}po({},{read:()=>Ss,write:()=>ks});function ks(e){let t={options:{directed:e.isDirected(),multigraph:e.isMultigraph(),compound:e.isCompound()},nodes:Cs(e),edges:Es(e)},i=e.graph();return i!==void 0&&(t.value=structuredClone(i)),t}function Cs(e){return e.nodes().map(t=>{let i=e.node(t),n=e.parent(t),o={v:t};return i!==void 0&&(o.value=i),n!==void 0&&(o.parent=n),o})}function Es(e){return e.edges().map(t=>{let i=e.edge(t),n={v:t.v,w:t.w};return t.name!==void 0&&(n.name=t.name),i!==void 0&&(n.value=i),n})}function Ss(e){let t=new oi(e.options);return e.value!==void 0&&t.setGraph(e.value),e.nodes.forEach(i=>{t.setNode(i.v,i.value),i.parent&&t.setParent(i.v,i.parent)}),e.edges.forEach(i=>{t.setEdge({v:i.v,w:i.w,name:i.name},i.value)}),t}var ri={};po(ri,{CycleException:()=>at,bellmanFord:()=>ho,components:()=>Ts,dijkstra:()=>rt,dijkstraAll:()=>_s,findCycles:()=>Bs,floydWarshall:()=>Fs,isAcyclic:()=>js,postorder:()=>qs,preorder:()=>Os,prim:()=>Ds,shortestPaths:()=>Rs,tarjan:()=>go,topsort:()=>mo});var As=()=>1;function ho(e,t,i,n){return Ms(e,String(t),i||As,n||function(o){var r;return(r=e.outEdges(o))!=null?r:[]})}function Ms(e,t,i,n){let o={},r,a=0,s=e.nodes(),l=function(p){let h=o[p.v],f=o[p.w];if(!h||!f)return;let g=i(p);h.distance+g<f.distance&&(o[p.w]={distance:h.distance+g,predecessor:p.v},r=!0)},c=function(){s.forEach(function(p){n(p).forEach(function(h){let f=h.v===p?h.v:h.w,g=f===h.v?h.w:h.v;l({v:f,w:g})})})};s.forEach(function(p){o[p]={distance:p===t?0:Number.POSITIVE_INFINITY,predecessor:""}});let d=s.length;for(let p=1;p<d&&(r=!1,a++,c(),!!r);p++);if(a===d-1&&(r=!1,c(),r))throw new Error("The graph contains a negative weight cycle");return o}function Ts(e){let t={},i=[],n;function o(r){var a,s;r in t||(t[r]=!0,n.push(r),(a=e.successors(r))==null||a.forEach(o),(s=e.predecessors(r))==null||s.forEach(o))}return e.nodes().forEach(function(r){n=[],o(r),n.length&&i.push(n)}),i}var fo=class{constructor(){this._arr=[],this._keyIndices={}}size(){return this._arr.length}keys(){return this._arr.map(e=>e.key)}has(e){return e in this._keyIndices}priority(e){let t=this._keyIndices[e];if(t!==void 0)return this._arr[t].priority}min(){if(this.size()===0)throw new Error("Queue underflow");return this._arr[0].key}add(e,t){let i=this._keyIndices,n=String(e);if(!(n in i)){let o=this._arr,r=o.length;return i[n]=r,o.push({key:n,priority:t}),this._decrease(r),!0}return!1}removeMin(){if(this.size()===0)throw new Error("Queue underflow");this._swap(0,this._arr.length-1);let e=this._arr.pop();return delete this._keyIndices[e.key],this._heapify(0),e.key}decrease(e,t){let i=this._keyIndices[e];if(i===void 0)throw new Error(`Key not found: ${e}`);let n=this._arr[i].priority;if(t>n)throw new Error(`New priority is greater than current priority. Key: ${e} Old: ${n} New: ${t}`);this._arr[i].priority=t,this._decrease(i)}_heapify(e){let t=this._arr,i=2*e,n=i+1,o=e;i<t.length&&(o=t[i].priority<t[o].priority?i:o,n<t.length&&(o=t[n].priority<t[o].priority?n:o),o!==e&&(this._swap(e,o),this._heapify(o)))}_decrease(e){let t=this._arr,i=t[e].priority,n;for(;e!==0&&(n=e>>1,!(t[n].priority<i));)this._swap(e,n),e=n}_swap(e,t){let i=this._arr,n=this._keyIndices,o=i[e],r=i[t];i[e]=r,i[t]=o,n[r.key]=e,n[o.key]=t}},Ls=()=>1;function rt(e,t,i,n){let o=function(r){var a;return(a=e.outEdges(r))!=null?a:[]};return zs(e,String(t),i||Ls,n||o)}function zs(e,t,i,n){let o={},r=new fo,a,s,l=function(c){let d=c.v!==a?c.v:c.w,p=o[d];if(!p)return;let h=i(c),f=s.distance+h;if(h<0)throw new Error("dijkstra does not allow negative edge weights. Bad edge: "+c+" Weight: "+h);f<p.distance&&(p.distance=f,p.predecessor=a,r.decrease(d,f))};for(e.nodes().forEach(function(c){let d=c===t?0:Number.POSITIVE_INFINITY;o[c]={distance:d,predecessor:""},r.add(c,d)});r.size()>0;){a=r.removeMin();let c=o[a];if(!c||c.distance===Number.POSITIVE_INFINITY)break;s=c,n(a).forEach(l)}return o}function _s(e,t,i){return e.nodes().reduce(function(n,o){return n[o]=rt(e,o,t,i),n},{})}function go(e){let t=0,i=[],n={},o=[];function r(a){var s;let l=n[a]={onStack:!0,lowlink:t,index:t++};if(i.push(a),(s=e.successors(a))==null||s.forEach(function(c){if(c in n){let d=n[c];d!=null&&d.onStack&&(l.lowlink=Math.min(l.lowlink,d.index))}else{r(c);let d=n[c];d&&(l.lowlink=Math.min(l.lowlink,d.lowlink))}}),l.lowlink===l.index){let c=[],d;do{d=i.pop();let p=n[d];p&&(p.onStack=!1),c.push(d)}while(a!==d);o.push(c)}}return e.nodes().forEach(function(a){a in n||r(a)}),o}function Bs(e){return go(e).filter(function(t){var i;let n=t[0];return n?t.length>1||t.length===1&&((i=e.outEdges(n,n))!=null?i:[]).length>0:!1})}var Is=()=>1;function Fs(e,t,i){return $s(e,t||Is,i||function(n){var o;return(o=e.outEdges(n))!=null?o:[]})}function $s(e,t,i){let n={},o=e.nodes();return o.forEach(function(r){let a={};n[r]=a,a[r]={distance:0,predecessor:""},o.forEach(function(s){r!==s&&(a[s]={distance:Number.POSITIVE_INFINITY,predecessor:""})}),i(r).forEach(function(s){let l=s.v===r?s.w:s.v,c=t(s);a[l]={distance:c,predecessor:r}})}),o.forEach(function(r){let a=n[r];a&&o.forEach(function(s){let l=n[s];l&&o.forEach(function(c){let d=l[r],p=a[c],h=l[c];if(d&&p&&h){let f=d.distance+p.distance;f<h.distance&&(h.distance=f,h.predecessor=p.predecessor)}})})}),n}var at=class extends Error{constructor(e){super(e),this.name="CycleException"}};function mo(e){let t={},i={},n=[];function o(r){var a;if(r in i)throw new at;r in t||(i[r]=!0,t[r]=!0,(a=e.predecessors(r))==null||a.forEach(o),delete i[r],n.push(r))}if(e.sinks().forEach(o),Object.keys(t).length!==e.nodeCount())throw new at;return n}function js(e){try{mo(e)}catch(t){if(t instanceof at)return!1;throw t}return!0}function Ns(e,t,i,n,o){Array.isArray(t)||(t=[t]);let r=(s=>{var l;return(l=e.isDirected()?e.successors(s):e.neighbors(s))!=null?l:[]}),a={};return t.forEach(function(s){if(!e.hasNode(s))throw new Error("Graph does not have node: "+s);o=bo(e,s,i==="post",a,r,n,o)}),o}function bo(e,t,i,n,o,r,a){return t in n||(n[t]=!0,i||(a=r(a,t)),o(t).forEach(function(s){a=bo(e,s,i,n,o,r,a)}),i&&(a=r(a,t))),a}function xo(e,t,i){return Ns(e,t,i,function(n,o){return n.push(o),n},[])}function qs(e,t){return xo(e,t,"post")}function Os(e,t){return xo(e,t,"pre")}function Ds(e,t){var i;let n=new oi,o={},r=new fo,a;function s(d){let p=d.v===a?d.w:d.v,h=r.priority(p);if(h!==void 0){let f=t(d);f<h&&(o[p]=a,r.decrease(p,f))}}if(e.nodeCount()===0)return n;e.nodes().forEach(function(d){r.add(d,Number.POSITIVE_INFINITY),n.setNode(d)});let l=e.nodes()[0];l!==void 0&&r.decrease(l,0);let c=!1;for(;r.size()>0;){if(a=r.removeMin(),a in o)n.setEdge(a,o[a]);else{if(c)throw new Error("Input graph is not connected: "+e);c=!0}(i=e.nodeEdges(a))==null||i.forEach(s)}return n}function Rs(e,t,i,n){return Ps(e,t,i,n??(o=>{var r;return(r=e.outEdges(o))!=null?r:[]}))}function Ps(e,t,i,n){if(i===void 0)return rt(e,t,i,n);let o=!1,r=e.nodes();for(let a=0;a<r.length;a++){let s=r[a];if(s===void 0)continue;let l=n(s);for(let c=0;c<l.length;c++){let d=l[c];if(!d)continue;let p=d.v===s?d.v:d.w;i({v:p,w:p===d.v?d.w:d.v})<0&&(o=!0)}if(o)return ho(e,t,i,n)}return rt(e,t,i,n)}var ye=oi;function Pe(e,t,i,n){let o=n;for(;e.hasNode(o);)o=ai(n);return i.dummy=t,e.setNode(o,i),o}function Vs(e){let t=new ye().setGraph(e.graph());return e.nodes().forEach(i=>t.setNode(i,e.node(i))),e.edges().forEach(i=>{let n=t.edge(i.v,i.w)||{weight:0,minlen:1},o=e.edge(i);t.setEdge(i.v,i.w,{weight:n.weight+o.weight,minlen:Math.max(n.minlen,o.minlen)})}),t}function vo(e){let t=new ye({multigraph:e.isMultigraph()}).setGraph(e.graph());return e.nodes().forEach(i=>{e.children(i).length||t.setNode(i,e.node(i))}),e.edges().forEach(i=>{t.setEdge(i,e.edge(i))}),t}function ln(e,t){let i=e.x,n=e.y,o=t.x-i,r=t.y-n,a=e.width/2,s=e.height/2;if(!o&&!r)throw new Error("Not possible to find intersection inside of the rectangle");let l,c;return o===0||Math.abs(r)*a>Math.abs(o)*s?(r<0&&(s=-s),l=s*o/r,c=s):(o<0&&(a=-a),l=a,c=a*r/o),{x:i+l,y:n+c}}function Ze(e){let t=Xe(yo(e)+1).map(()=>[]);return e.nodes().forEach(i=>{let n=e.node(i),o=n.rank;o!==void 0&&(t[o]||(t[o]=[]),t[o][n.order]=i)}),t}function Hs(e){let t=e.nodes().map(n=>{let o=e.node(n).rank;return o===void 0?Number.MAX_VALUE:o}),i=Ee(Math.min,t);e.nodes().forEach(n=>{let o=e.node(n);Object.hasOwn(o,"rank")&&(o.rank-=i)})}function Ws(e){let t=e.nodes().map(a=>e.node(a).rank).filter(a=>a!==void 0),i=Ee(Math.min,t),n=[];e.nodes().forEach(a=>{let s=e.node(a).rank-i;n[s]||(n[s]=[]),n[s].push(a)});let o=0,r=e.graph().nodeRankFactor;Array.from(n).forEach((a,s)=>{a===void 0&&s%r!==0?--o:a!==void 0&&o&&a.forEach(l=>e.node(l).rank+=o)})}function cn(e,t,i,n){let o={width:0,height:0};return arguments.length>=4&&(o.rank=i,o.order=n),Pe(e,"border",o,t)}function Us(e,t=wo){let i=[];for(let n=0;n<e.length;n+=t){let o=e.slice(n,n+t);i.push(o)}return i}var wo=65535;function Ee(e,t){return t.length>wo?e(...Us(t).map(i=>e(...i))):e(...t)}function yo(e){let t=e.nodes().map(i=>{let n=e.node(i).rank;return n===void 0?Number.MIN_VALUE:n});return Ee(Math.max,t)}function Gs(e,t){let i={lhs:[],rhs:[]};return e.forEach(n=>{t(n)?i.lhs.push(n):i.rhs.push(n)}),i}function Ys(e,t){let i=Date.now();try{return t()}finally{console.log(e+" time: "+(Date.now()-i)+"ms")}}function ko(e,t){return t()}var Ks=0;function ai(e){return e+(""+ ++Ks)}function Xe(e,t,i=1){t??(t=e,e=0);let n=r=>r<t;i<0&&(n=r=>t<r);let o=[];for(let r=e;n(r);r+=i)o.push(r);return o}function st(e,t){let i={};for(let n of t)e[n]!==void 0&&(i[n]=e[n]);return i}function pt(e,t){let i;return typeof t=="string"?i=n=>n[t]:i=t,Object.entries(e).reduce((n,[o,r])=>(n[o]=i(r,o),n),{})}function Xs(e,t){return e.reduce((i,n,o)=>(i[n]=t[o],i),{})}var ht="\0";function Co(e,t,i){var n,o,r,a,s,l;if(!(e&&t&&i&&t.dummy==="edge"&&i.dummy==="edge"&&t.edgeObj&&i.edgeObj&&e[t.edgeObj.v]&&e[i.edgeObj.v]&&e[t.edgeObj.w]&&e[i.edgeObj.w]))return 0;let c=!0;t.edgeObj.w===i.edgeObj.w&&(c=!1);let d=c?(o=(n=e[t.edgeObj.v])==null?void 0:n.rank)!=null?o:NaN:(a=(r=e[t.edgeObj.w])==null?void 0:r.rank)!=null?a:NaN,p=Object.entries(e).find(b=>{var m,C;return((m=b[1].edgeObj)==null?void 0:m.v)===t.edgeObj.v&&((C=b[1].edgeObj)==null?void 0:C.w)===t.edgeObj.w&&b[1].rank===d}),h=Object.entries(e).find(b=>{var m,C;return((m=b[1].edgeObj)==null?void 0:m.v)===i.edgeObj.v&&((C=b[1].edgeObj)==null?void 0:C.w)===i.edgeObj.w&&b[1].rank===d});if(!p||!h)return 0;let f=(s=p[1].order)!=null?s:NaN,g=(l=h[1].order)!=null?l:NaN;return isNaN(f-g)?0:f-g}var Zs="3.1.3",Qs=class{constructor(){vs(this,"_sentinel");let e={};e._next=e._prev=e,this._sentinel=e}dequeue(){let e=this._sentinel,t=e._prev;if(t!==e)return dn(t),t}enqueue(e){let t=this._sentinel;e._prev&&e._next&&dn(e),e._next=t._next,t._next._prev=e,t._next=e,e._prev=t}toString(){let e=[],t=this._sentinel,i=t._prev;for(;i!==t;)e.push(JSON.stringify(i,Js)),i=i._prev;return"["+e.join(", ")+"]"}};function dn(e){e._prev._next=e._next,e._next._prev=e._prev,delete e._next,delete e._prev}function Js(e,t){if(e!=="_next"&&e!=="_prev")return t}var el=Qs,tl=()=>1;function il(e,t){if(e.nodeCount()<=1)return[];let i=ol(e,t||tl);return nl(i.graph,i.buckets,i.zeroIdx).flatMap(n=>e.outEdges(n.v,n.w)||[])}function nl(e,t,i){var n;let o=[],r=t[t.length-1],a=t[0],s;for(;e.nodeCount();){for(;s=a.dequeue();)Et(e,t,i,s);for(;s=r.dequeue();)Et(e,t,i,s);if(e.nodeCount()){for(let l=t.length-2;l>0;--l)if(s=(n=t[l])==null?void 0:n.dequeue(),s){o=o.concat(Et(e,t,i,s,!0)||[]);break}}}return o}function Et(e,t,i,n,o){let r=[],a=o?r:void 0;return(e.inEdges(n.v)||[]).forEach(s=>{let l=e.edge(s),c=e.node(s.v);o&&r.push({v:s.v,w:s.w}),c.out-=l,Ut(t,i,c)}),(e.outEdges(n.v)||[]).forEach(s=>{let l=e.edge(s),c=s.w,d=e.node(c);d.in-=l,Ut(t,i,d)}),e.removeNode(n.v),a}function ol(e,t){let i=new ye,n=0,o=0;e.nodes().forEach(s=>{i.setNode(s,{v:s,in:0,out:0})}),e.edges().forEach(s=>{let l=i.edge(s.v,s.w)||0,c=t(s),d=l+c;i.setEdge(s.v,s.w,d);let p=i.node(s.v),h=i.node(s.w);o=Math.max(o,p.out+=c),n=Math.max(n,h.in+=c)});let r=rl(o+n+3).map(()=>new el),a=n+1;return i.nodes().forEach(s=>{Ut(r,a,i.node(s))}),{graph:i,buckets:r,zeroIdx:a}}function Ut(e,t,i){var n,o,r;i.out?i.in?(r=e[i.out-i.in+t])==null||r.enqueue(i):(o=e[e.length-1])==null||o.enqueue(i):(n=e[0])==null||n.enqueue(i)}function rl(e){let t=[];for(let i=0;i<e;i++)t.push(i);return t}function al(e,t){(e.graph().acyclicer==="greedy"?il(e,i(e)):sl(e,t??null)).forEach(n=>{let o=e.edge(n);e.removeEdge(n),o.forwardName=n.name,o.reversed=!0,e.setEdge(n.w,n.v,o,ai("rev"))});function i(n){return o=>n.edge(o).weight}}function sl(e,t){let i=[],n={},o={};function r(l){Object.hasOwn(o,l)||(o[l]=!0,n[l]=!0,e.outEdges(l).forEach(c=>{Object.hasOwn(n,c.w)?i.push(c):r(c.w)}),delete n[l])}function a(l){var c;Object.hasOwn(o,l)||(o[l]=!0,n[l]=!0,(c=e.outEdges(l))==null||c.forEach(d=>{var p,h;Object.hasOwn(n,d.w)||((p=t.node(l))==null?void 0:p.rank)>((h=t.node(d.w))==null?void 0:h.rank)&&cl(e,d.w,d)?i.push(d):a(d.w)}),delete n[l])}let s=r;return t&&typeof t.node=="function"&&(s=a),e.sources().forEach(s),e.nodes().forEach(s),i}function ll(e){e.edges().forEach(t=>{let i=e.edge(t);if(i.reversed){e.removeEdge(t);let n=i.forwardName;delete i.reversed,delete i.forwardName,e.setEdge(t.w,t.v,i,n)}})}function cl(e,t,i){let n=new Set;function o(r){var a;if(e.sources().includes(r))return!0;n.add(r);for(let s of(a=e.inEdges(r))!=null?a:[])if(!(s.v===i.v&&s.w===i.w)&&!n.has(s.v)&&o(s.v))return!0;return!1}return o(t)}function dl(e){e.graph().dummyChains=[],e.edges().forEach(t=>ul(e,t))}function ul(e,t){let i=t.v,n=e.node(i).rank,o=t.w,r=e.node(o).rank,a=t.name,s=e.edge(t),l=s.labelRank;if(r===n+1)return;e.removeEdge(t);let c,d,p=0;for(++n;n<r;++p,++n)s.points=[],d={width:0,height:0,edgeLabel:s,edgeObj:t,rank:n},c=Pe(e,"edge",d,"_d"),n===l&&(d.width=s.width,d.height=s.height,d.dummy="edge-label",d.labelpos=s.labelpos),e.setEdge(i,c,{weight:s.weight},a),p===0&&e.graph().dummyChains.push(c),i=c;e.setEdge(i,o,{weight:s.weight},a)}function pl(e){e.graph().dummyChains.forEach(t=>{let i=e.node(t),n=i.edgeLabel,o;for(e.setEdge(i.edgeObj,n);i.dummy;)o=e.successors(t)[0],e.removeNode(t),n.points.push({x:i.x,y:i.y}),i.dummy==="edge-label"&&(n.x=i.x,n.y=i.y,n.width=i.width,n.height=i.height),t=o,i=e.node(t)})}function si(e){let t={};function i(n){let o=e.node(n);if(Object.hasOwn(t,n))return o.rank;t[n]=!0;let r=e.outEdges(n),a=r?r.map(l=>l==null?Number.POSITIVE_INFINITY:i(l.w)-e.edge(l).minlen):[],s=Ee(Math.min,a);return s===Number.POSITIVE_INFINITY&&(s=0),o.rank=s}e.sources().forEach(i)}function De(e,t){return e.node(t.w).rank-e.node(t.v).rank-e.edge(t).minlen}var Eo=hl;function hl(e){let t=new ye({directed:!1}),i=e.nodes();if(i.length===0)throw new Error("Graph must have at least one node");let n=i[0],o=e.nodeCount();t.setNode(n,{});let r,a;for(;fl(t,e)<o&&(r=gl(t,e),!!r);)a=t.hasNode(r.v)?De(e,r):-De(e,r),ml(t,e,a);return t}function fl(e,t){function i(n){let o=t.nodeEdges(n);o&&o.forEach(r=>{let a=r.v,s=n===a?r.w:a;!e.hasNode(s)&&!De(t,r)&&(e.setNode(s,{}),e.setEdge(n,s,{}),i(s))})}return e.nodes().forEach(i),e.nodeCount()}function gl(e,t){return t.edges().reduce((i,n)=>{let o=Number.POSITIVE_INFINITY;return e.hasNode(n.v)!==e.hasNode(n.w)&&(o=De(t,n)),o<i[0]?[o,n]:i},[Number.POSITIVE_INFINITY,null])[1]}function ml(e,t,i){e.nodes().forEach(n=>t.node(n).rank+=i)}var{preorder:bl,postorder:xl}=ri,vl=je;je.initLowLimValues=ci;je.initCutValues=li;je.calcCutValue=So;je.leaveEdge=Mo;je.enterEdge=To;je.exchangeEdges=Lo;function je(e){e=Vs(e),si(e);let t=Eo(e);ci(t),li(t,e);let i,n;for(;i=Mo(t);)n=To(t,e,i),Lo(t,e,i,n)}function li(e,t){let i=xl(e,e.nodes());i=i.slice(0,i.length-1),i.forEach(n=>wl(e,t,n))}function wl(e,t,i){let n=e.node(i).parent,o=e.edge(i,n);o.cutvalue=So(e,t,i)}function So(e,t,i){let n=e.node(i).parent,o=!0,r=t.edge(i,n),a=0;r||(o=!1,r=t.edge(n,i)),a=r.weight;let s=t.nodeEdges(i);return s&&s.forEach(l=>{let c=l.v===i,d=c?l.w:l.v;if(d!==n){let p=c===o,h=t.edge(l).weight;if(a+=p?h:-h,kl(e,i,d)){let f=e.edge(i,d).cutvalue;a+=p?-f:f}}}),a}function ci(e,t){arguments.length<2&&(t=e.nodes()[0]),Ao(e,{},1,t)}function Ao(e,t,i,n,o){let r=i,a=e.node(n);t[n]=!0;let s=e.neighbors(n);return s&&s.forEach(l=>{Object.hasOwn(t,l)||(i=Ao(e,t,i,l,n))}),a.low=r,a.lim=i++,o?a.parent=o:delete a.parent,i}function Mo(e){return e.edges().find(t=>e.edge(t).cutvalue<0)}function To(e,t,i){let n=i.v,o=i.w;t.hasEdge(n,o)||(n=i.w,o=i.v);let r=e.node(n),a=e.node(o),s=r,l=!1;return r.lim>a.lim&&(s=a,l=!0),t.edges().filter(c=>l===un(e,e.node(c.v),s)&&l!==un(e,e.node(c.w),s)).reduce((c,d)=>De(t,d)<De(t,c)?d:c)}function Lo(e,t,i,n){let o=i.v,r=i.w;e.removeEdge(o,r),e.setEdge(n.v,n.w,{}),ci(e),li(e,t),yl(e,t)}function yl(e,t){let i=e.nodes().find(o=>!e.node(o).parent);if(!i)return;let n=bl(e,[i]);n=n.slice(1),n.forEach(o=>{let r=e.node(o).parent,a=t.edge(o,r),s=!1;a||(a=t.edge(r,o),s=!0),t.node(o).rank=t.node(r).rank+(s?a.minlen:-a.minlen)})}function kl(e,t,i){return e.hasEdge(t,i)}function un(e,t,i){return i.low<=t.lim&&t.lim<=i.lim}var Cl=El;function El(e){let t=e.graph().ranker;if(typeof t=="function")return t(e);switch(t){case"network-simplex":pn(e);break;case"tight-tree":Al(e);break;case"longest-path":Sl(e);break;case"none":break;default:pn(e)}}var Sl=si;function Al(e){si(e),Eo(e)}function pn(e){vl(e)}var Ml=Tl;function Tl(e){let t=zl(e),i=e.graph();Array.isArray(i.dummyChains)&&i.dummyChains.forEach(n=>{let o=e.node(n),r=o.edgeObj,a=Ll(e,t,r.v,r.w),s=a.path,l=a.lca,c=0,d=s[c],p=!0;for(;n!==r.w;){if(o=e.node(n),p){for(;(d=s[c])!==l&&e.node(d).maxRank<o.rank;)c++;d===l&&(p=!1)}if(!p){for(;c<s.length-1&&e.node(s[c+1]).minRank<=o.rank;)c++;d=s[c]}d!==void 0&&e.setParent(n,d),n=e.successors(n)[0]}})}function Ll(e,t,i,n){let o=[],r=[],a=Math.min(t[i].low,t[n].low),s=Math.max(t[i].lim,t[n].lim),l;l=i;do l=e.parent(l),o.push(l);while(l&&(t[l].low>a||s>t[l].lim));let c=l,d=n;for(;(d=e.parent(d))!==c;)r.push(d);return{path:o.concat(r.reverse()),lca:c}}function zl(e){let t={},i=0;function n(o){let r=i;e.children(o).forEach(n),t[o]={low:r,lim:i++}}return e.children(ht).forEach(n),t}function _l(e){let t=Pe(e,"root",{},"_root"),i=Bl(e),n=Object.values(i),o=Ee(Math.max,n)-1,r=2*o+1;e.graph().nestingRoot=t,e.edges().forEach(s=>e.edge(s).minlen*=r);let a=Il(e)+1;e.children(ht).forEach(s=>{zo(e,t,r,a,o,i,s)}),e.graph().nodeRankFactor=r}function zo(e,t,i,n,o,r,a){var s;let l=e.children(a);if(!l.length){a!==t&&e.setEdge(t,a,{weight:0,minlen:i});return}let c=cn(e,"_bt"),d=cn(e,"_bb"),p=e.node(a);e.setParent(c,a),p.borderTop=c,e.setParent(d,a),p.borderBottom=d,l.forEach(h=>{var f;zo(e,t,i,n,o,r,h);let g=e.node(h),b=g.borderTop?g.borderTop:h,m=g.borderBottom?g.borderBottom:h,C=g.borderTop?n:2*n,v=b!==m?1:o-((f=r[a])!=null?f:0)+1;e.setEdge(c,b,{weight:C,minlen:v,nestingEdge:!0}),e.setEdge(m,d,{weight:C,minlen:v,nestingEdge:!0})}),e.parent(a)||e.setEdge(t,c,{weight:0,minlen:o+((s=r[a])!=null?s:0)})}function Bl(e){let t={};function i(n,o){let r=e.children(n);r&&r.length&&r.forEach(a=>i(a,o+1)),t[n]=o}return e.children(ht).forEach(n=>i(n,1)),t}function Il(e){return e.edges().reduce((t,i)=>t+e.edge(i).weight,0)}function Fl(e){let t=e.graph();e.removeNode(t.nestingRoot),delete t.nestingRoot,e.edges().forEach(i=>{e.edge(i).nestingEdge&&e.removeEdge(i)})}var $l=jl;function jl(e){function t(i){let n=e.children(i),o=e.node(i);if(n.length&&n.forEach(t),o&&Object.hasOwn(o,"minRank")){o.borderLeft=[],o.borderRight=[];for(let r=o.minRank,a=o.maxRank+1;r<a;++r)hn(e,"borderLeft","_bl",i,o,r),hn(e,"borderRight","_br",i,o,r)}}e.children(ht).forEach(t)}function hn(e,t,i,n,o,r){let a={width:0,height:0,rank:r,borderType:t},s=o[t][r-1],l=Pe(e,"border",a,i);o[t][r]=l,e.setParent(l,n),s&&e.setEdge(s,l,{weight:1})}function Nl(e){var t;let i=(t=e.graph().rankdir)==null?void 0:t.toLowerCase();(i==="lr"||i==="rl")&&_o(e)}function ql(e){var t;let i=(t=e.graph().rankdir)==null?void 0:t.toLowerCase();(i==="bt"||i==="rl")&&Ol(e),(i==="lr"||i==="rl")&&(Dl(e),_o(e))}function _o(e){e.nodes().forEach(t=>fn(e.node(t))),e.edges().forEach(t=>fn(e.edge(t)))}function fn(e){let t=e.width;e.width=e.height,e.height=t}function Ol(e){e.nodes().forEach(t=>St(e.node(t))),e.edges().forEach(t=>{var i;let n=e.edge(t);(i=n.points)==null||i.forEach(St),Object.hasOwn(n,"y")&&St(n)})}function St(e){e.y=-e.y}function Dl(e){e.nodes().forEach(t=>At(e.node(t))),e.edges().forEach(t=>{var i;let n=e.edge(t);(i=n.points)==null||i.forEach(At),Object.hasOwn(n,"x")&&At(n)})}function At(e){let t=e.x;e.x=e.y,e.y=t}function Rl(e,t=null){let i={},n=e.nodes().filter(l=>!e.children(l).length),o=n.map(l=>e.node(l).rank),r=Xe(Ee(Math.max,o)+1).map(()=>[]);function a(l){if(i[l])return;i[l]=!0;let c=e.node(l);r[c.rank].push(l);let d=e.successors(l);d&&[...d].sort((p,h)=>s(p,h)).forEach(a)}n.sort((l,c)=>e.node(l).rank-e.node(c).rank).forEach(a);function s(l,c){return Co(t,e.node(l),e.node(c))}return r}function Pl(e,t){let i=0;for(let n=1;n<t.length;++n)i+=Vl(e,t[n-1],t[n]);return i}function Vl(e,t,i){let n=Xs(i,i.map((c,d)=>d)),o=t.flatMap(c=>{let d=e.outEdges(c);return d?d.map(p=>({pos:n[p.w],weight:e.edge(p).weight})).sort((p,h)=>p.pos-h.pos):[]}),r=1;for(;r<i.length;)r<<=1;let a=2*r-1;r-=1;let s=new Array(a).fill(0),l=0;return o.forEach(c=>{let d=c.pos+r;s[d]+=c.weight;let p=0;for(;d>0;)d%2&&(p+=s[d+1]),d=d-1>>1,s[d]+=c.weight;l+=c.weight*p}),l}function Hl(e,t=[]){return t.map(i=>{let n=e.inEdges(i);if(!n||!n.length)return{v:i};{let o=n.reduce((r,a)=>{let s=e.edge(a),l=e.node(a.v);return{sum:r.sum+s.weight*l.order,weight:r.weight+s.weight}},{sum:0,weight:0});return{v:i,barycenter:o.sum/o.weight,weight:o.weight}}})}function Wl(e,t){let i={};return e.forEach((n,o)=>{let r={indegree:0,in:[],out:[],vs:[n.v],i:o};n.barycenter!==void 0&&(r.barycenter=n.barycenter,r.weight=n.weight),i[n.v]=r}),t.edges().forEach(n=>{let o=i[n.v],r=i[n.w];o!==void 0&&r!==void 0&&(r.indegree++,o.out.push(r))}),Ul(Object.values(i).filter(n=>!n.indegree))}function Ul(e){let t=[];function i(o){return r=>{r.merged||(r.barycenter===void 0||o.barycenter===void 0||r.barycenter>=o.barycenter)&&Gl(o,r)}}function n(o){return r=>{r.in.push(o),--r.indegree===0&&e.push(r)}}for(;e.length;){let o=e.pop();t.push(o),o.in.reverse().forEach(i(o)),o.out.forEach(n(o))}return t.filter(o=>!o.merged).map(o=>st(o,["vs","i","barycenter","weight"]))}function Gl(e,t){let i=0,n=0;e.weight&&(i+=e.barycenter*e.weight,n+=e.weight),t.weight&&(i+=t.barycenter*t.weight,n+=t.weight),e.vs=t.vs.concat(e.vs),e.barycenter=i/n,e.weight=n,e.i=Math.min(t.i,e.i),t.merged=!0}function Yl(e,t,i,n,o){let r={},a=null,s=null,l=o;typeof t=="boolean"?(l=t,r={}):t&&(r=t,a=i??null,s=n??null);let c=Gs(e,C=>Object.hasOwn(C,"barycenter")),d=c.lhs,p=c.rhs.sort((C,v)=>v.i-C.i),h=[],f=0,g=0,b=0;d.sort(Kl(s,a,!!l));for(let[C,v]of Object.entries(r)){let w=d.findIndex(x=>x.vs[0]===C);d.splice(w+1,0,v)}b=gn(h,p,b),d.forEach(C=>{b+=C.vs.length,h.push(C.vs),f+=C.barycenter*C.weight,g+=C.weight,b=gn(h,p,b)});let m={vs:h.flat(1)};return g&&(m.barycenter=f/g,m.weight=g),m}function gn(e,t,i){let n;for(;t.length&&(n=t[t.length-1]).i<=i;)t.pop(),e.push(n.vs),i++;return i}function Kl(e,t,i){return(n,o)=>{if(n.barycenter<o.barycenter)return-1;if(n.barycenter>o.barycenter)return 1;if(e&&(typeof n.vs[0]=="string"||typeof o.vs[0]=="string")){let r=Co(t,e.node(n.vs[0]),e.node(o.vs[0]));if(r!==0)return r}return i?o.i-n.i:n.i-o.i}}function Bo(e,t,i,n,o){var r,a,s,l,c,d,p,h,f,g,b;let m=null,C=o;typeof n=="boolean"?(C=n,m=null):n!==void 0&&(m=n);let v=e.children(t),w=e.node(t),x=w?w.borderLeft:void 0,y=w?w.borderRight:void 0,k={};x&&(v=v.filter(F=>F!==x&&F!==y));let A=Hl(e,v);A.forEach(F=>{if(e.children(F.v).length){let{result:B}=Bo(e,F.v,i,m,C);k[F.v]=B,Object.hasOwn(B,"barycenter")&&Zl(F,B)}});let S=Wl(A,i);Xl(S,k);let E={},z=!1;for(let F=0;F<S.length;F++)for(let B=F+1;B<S.length;B++)if(!(!S[F]||!S[B]||!((r=S[F])!=null&&r.barycenter)||!((a=S[B])!=null&&a.barycenter))&&((s=S[F])==null?void 0:s.barycenter)===S[B].barycenter){let O=(c=(l=S[F])==null?void 0:l.vs[0])!=null?c:"",D=(p=(d=S[B])==null?void 0:d.vs[0])!=null?p:"",P=e.node(O),R=e.node(D);if(P.dummy==="edge"&&R.dummy==="edge"&&((h=P.edgeObj)==null?void 0:h.v)===((f=R.edgeObj)==null?void 0:f.v)&&((g=P.edgeObj)==null?void 0:g.w)===((b=R.edgeObj)==null?void 0:b.w))if(P.edgeLabel.reversed){E[D]=S[F],S.splice(F,1),F--;break}else E[O]||(E[O]=S[B],S.splice(B,1),B--);else z=!0}let L=Yl(S,E,m,e,C);if(x&&y){L.vs=[x,L.vs,y].flat(1);let F=e.predecessors(x);if(F&&F.length){let B=e.node(F[0]),O=e.predecessors(y),D=e.node(O[0]);Object.hasOwn(L,"barycenter")||(L.barycenter=0,L.weight=0),L.barycenter=(L.barycenter*L.weight+B.order+D.order)/(L.weight+2),L.weight+=2}}return Object.defineProperty(L,"result",{value:L,enumerable:!1,configurable:!0,writable:!0}),Object.defineProperty(L,"usedBias",{value:z,enumerable:!1,configurable:!0,writable:!0}),L}function Xl(e,t){e.forEach(i=>{i.vs=i.vs.flatMap(n=>t[n]?t[n].vs:n)})}function Zl(e,t){e.barycenter!==void 0?(e.barycenter=(e.barycenter*e.weight+t.barycenter*t.weight)/(e.weight+t.weight),e.weight+=t.weight):(e.barycenter=t.barycenter,e.weight=t.weight)}function Ql(e,t,i,n){n||(n=e.nodes());let o=Jl(e),r=new ye({compound:!0}).setGraph({root:o}).setDefaultNodeLabel(a=>e.node(a));return n.forEach(a=>{let s=e.node(a),l=e.parent(a);if(s.rank===t||s.minRank<=t&&t<=s.maxRank){r.setNode(a),r.setParent(a,l||o);let c=e[i](a);c&&c.forEach(d=>{let p=d.v===a?d.w:d.v,h=r.edge(p,a),f=h!==void 0?h.weight:0;r.setEdge(p,a,{weight:e.edge(d).weight+f})}),Object.hasOwn(s,"minRank")&&r.setNode(a,{borderLeft:s.borderLeft[t],borderRight:s.borderRight[t]})}}),r}function Jl(e){let t;for(;e.hasNode(t=ai("_root")););return t}function ec(e,t,i){let n={},o;i.forEach(r=>{let a=e.parent(r),s,l;for(;a;){if(s=e.parent(a),s?(l=n[s],n[s]=a):(l=o,o=a),l&&l!==a){t.setEdge(l,a);return}a=s}})}function Io(e,t={},i=null){if(typeof t.customOrder=="function"){t.customOrder(e,Io);return}let n=yo(e),o=mn(e,Xe(1,n+1),"inEdges"),r=mn(e,Xe(n-1,-1,-1),"outEdges"),a=Rl(e,i);if(bn(e,a),t.disableOptimalOrderHeuristic)return;let s=Number.POSITIVE_INFINITY,l,c=t.constraints||[];for(let d=0,p=0;p<4;++d,++p){tc(d%2?o:r,d%4>=2,c,i),a=Ze(e);let h=Pl(e,a);h<s?(p=0,l=Object.assign({},a),s=h):h===s&&(l=structuredClone(a))}bn(e,l)}function mn(e,t,i){let n=new Map,o=(r,a)=>{n.has(r)||n.set(r,[]),n.get(r).push(a)};for(let r of e.nodes()){let a=e.node(r);if(typeof a.rank=="number"&&o(a.rank,r),typeof a.minRank=="number"&&typeof a.maxRank=="number")for(let s=a.minRank;s<=a.maxRank;s++)s!==a.rank&&o(s,r)}return t.map(function(r){return Ql(e,r,i,n.get(r)||[])})}function tc(e,t,i,n){let o=!0,r=new ye;e.forEach(function(a){i.forEach(d=>r.setEdge(d.left,d.right));let s=a.graph().root,{result:l,usedBias:c}=Bo(a,s,r,n,o);t&&c&&(o=!o),l.vs.forEach((d,p)=>a.node(d).order=p),ec(a,r,l.vs)})}function bn(e,t){Object.values(t).forEach(i=>i.forEach((n,o)=>e.node(n).order=o))}function ic(e,t){let i={};function n(o,r){let a=0,s=0,l=o.length,c=r[r.length-1];return r.forEach((d,p)=>{let h=oc(e,d),f=h?e.node(h).order:l;(h||d===c)&&(r.slice(s,p+1).forEach(g=>{let b=e.predecessors(g);b&&b.forEach(m=>{let C=e.node(m),v=C.order;(v<a||f<v)&&!(C.dummy&&e.node(g).dummy)&&Fo(i,m,g)})}),s=p+1,a=f)}),r}return t.length&&t.reduce(n),i}function nc(e,t){let i={};function n(a){var s;return((s=e.node(a))==null?void 0:s.dummy)==="border"}if(!e.nodes().some(n))return i;function o(a,s,l,c,d){Xe(s,l).forEach(p=>{let h=a[p];if(h!==void 0&&e.node(h).dummy){let f=e.predecessors(h);f&&f.forEach(g=>{if(g===void 0)return;let b=e.node(g);b.dummy&&(b.order<c||b.order>d)&&Fo(i,g,h)})}})}function r(a,s){let l=-1,c=-1,d=0;return s.forEach((p,h)=>{if(n(p)){let f=e.predecessors(p);if(f&&f.length){let g=f[0];if(g===void 0)return;c=e.node(g).order,o(s,d,h,l,c),d=h,l=c}}o(s,d,s.length,c,a.length)}),s}return t.length&&t.reduce(r),i}function oc(e,t){if(e.node(t).dummy){let i=e.predecessors(t);if(i)return i.find(n=>e.node(n).dummy)}}function Fo(e,t,i){if(t>i){let o=t;t=i,i=o}let n=e[t];n||(e[t]=n={}),n[i]=!0}function rc(e,t,i){if(t>i){let o=t;t=i,i=o}let n=e[t];return n!==void 0&&Object.hasOwn(n,i)}function ac(e,t,i,n,o){let r={},a={},s={};return t.forEach(l=>{l.forEach((c,d)=>{r[c]=c,a[c]=c,s[c]=d})}),t.forEach(l=>{let c=-1,d=-1,p=!1,h=l,f=l.findIndex(g=>o?.includes(g)||xn(g,e,o));f>0&&(h=[l[f],...l.slice(0,f),...l.slice(f+1)],p=!0),h.forEach(g=>{var b;let m=n(g);if(m&&m.length){o!=null&&o.includes(g)&&(m=m.filter(w=>xn(w,e,o)));let C=m.sort((w,x)=>{let y=s[w],k=s[x];return(y!==void 0?y:0)-(k!==void 0?k:0)}),v=(C.length-1)/2;for(let w=Math.floor(v),x=Math.ceil(v);w<=x;++w){let y=C[w];if(y===void 0)continue;let k=s[y];if(k!==void 0&&a[g]===g&&c<k&&s[y]!==d&&!rc(i,g,y)){let A=r[y];A!==void 0&&(a[y]=g,a[g]=r[g]=A,c=k,p&&(c=-1,d=(b=s[y])!=null?b:-1,p=!1))}}}})}),{root:r,align:a}}function sc(e,t,i,n,o=!1){let r={},a=lc(e,t,i,o),s=o?"borderLeft":"borderRight";function l(f,g){let b=a.nodes().slice(),m={},C=b.pop();for(;C;){if(m[C])f(C);else{m[C]=!0,b.push(C);for(let v of g(C))b.push(v)}C=b.pop()}}function c(f){let g=a.inEdges(f);g?r[f]=g.reduce((b,m)=>{var C;let v=(C=r[m.v])!=null?C:0,w=a.edge(m);return Math.max(b,v+(w!==void 0?w:0))},0):r[f]=0}function d(f){let g=a.outEdges(f),b=Number.POSITIVE_INFINITY;g&&(b=g.reduce((C,v)=>{let w=r[v.w],x=a.edge(v);return Math.min(C,(w!==void 0?w:0)-(x!==void 0?x:0))},Number.POSITIVE_INFINITY));let m=e.node(f);b!==Number.POSITIVE_INFINITY&&m.borderType!==s&&(r[f]=Math.max(r[f]!==void 0?r[f]:0,b))}function p(f){return a.predecessors(f)||[]}function h(f){return a.successors(f)||[]}return l(c,p),l(d,h),Object.keys(n).forEach(f=>{var g;let b=i[f];b!==void 0&&(r[f]=(g=r[b])!=null?g:0)}),r}function lc(e,t,i,n){let o=new ye,r=e.graph(),a=hc(r.nodesep,r.edgesep,n);return t.forEach(s=>{let l;s.forEach(c=>{let d=i[c];if(d!==void 0){if(o.setNode(d),l!==void 0){let p=i[l];if(p!==void 0){let h=o.edge(p,d);o.setEdge(p,d,Math.max(a(e,c,l),h||0))}}l=c}})}),o}function cc(e,t){return Object.values(t).reduce((i,n)=>{let o=Number.NEGATIVE_INFINITY,r=Number.POSITIVE_INFINITY;Object.entries(n).forEach(([s,l])=>{let c=fc(e,s)/2;o=Math.max(l+c,o),r=Math.min(l-c,r)});let a=o-r;return a<i[0]&&(i=[a,n]),i},[Number.POSITIVE_INFINITY,null])[1]}function dc(e,t){let i=Object.values(t),n=Ee(Math.min,i),o=Ee(Math.max,i);["u","d"].forEach(r=>{["l","r"].forEach(a=>{let s=r+a,l=e[s];if(!l||l===t)return;let c=Object.values(l),d=n-Ee(Math.min,c);a!=="l"&&(d=o-Ee(Math.max,c)),d&&(e[s]=pt(l,p=>p+d))})})}function uc(e,t=void 0){let i=e.ul;return i?pt(i,(n,o)=>{var r,a;if(t){let l=e[t.toLowerCase()];if(l&&l[o]!==void 0)return l[o]}let s=Object.values(e).map(l=>{let c=l[o];return c!==void 0?c:0}).sort((l,c)=>l-c);return(((r=s[1])!=null?r:0)+((a=s[2])!=null?a:0))/2}):{}}function pc(e,t){let i=Ze(e),n=Object.assign(ic(e,i),nc(e,i)),o={},r;return["u","d"].forEach(a=>{r=a==="u"?i:Object.values(i).reverse(),["l","r"].forEach(s=>{s==="r"&&(r=r.map(d=>Object.values(d).reverse()));let l=ac(e,r,n,d=>(a==="u"?e.predecessors(d):e.successors(d))||[],t),c=sc(e,r,l.root,l.align,s==="r");s==="r"&&(c=pt(c,d=>-d)),o[a+s]=c})}),dc(o,cc(e,o)),uc(o,e.graph().align)}function hc(e,t,i){return(n,o,r)=>{let a=n.node(o),s=n.node(r),l=0,c;if(l+=a.width/2,Object.hasOwn(a,"labelpos"))switch(a.labelpos.toLowerCase()){case"l":c=-a.width/2;break;case"r":c=a.width/2}if(c&&(l+=i?c:-c),c=void 0,l+=(a.dummy?t:e)/2,l+=(s.dummy?t:e)/2,l+=s.width/2,Object.hasOwn(s,"labelpos"))switch(s.labelpos.toLowerCase()){case"l":c=s.width/2;break;case"r":c=-s.width/2}return c&&(l+=i?c:-c),l}}function fc(e,t){return e.node(t).width}function xn(e,t,i){var n;if(!i)return!1;let o=(n=t.node(e))==null?void 0:n.edgeObj;if(!o||t.node(e).edgeLabel.reversed)return!1;let r=i.indexOf(o?.v),a=i.indexOf(o?.w);return r!==-1&&a!==-1&&r===(a+1)%i.length||r===(a-1)%i.length}function gc(e,t){e=vo(e),mc(e),Object.entries(pc(e,t)).forEach(([i,n])=>e.node(i).x=n)}function mc(e){let t=Ze(e),i=e.graph(),n=i.ranksep,o=i.rankalign,r=0;t.forEach(a=>{let s=a.reduce((l,c)=>{var d;let p=(d=e.node(c).height)!=null?d:0;return l>p?l:p},0);a.forEach(l=>{let c=e.node(l);o==="top"?c.y=r+c.height/2:o==="bottom"?c.y=r+s-c.height/2:c.y=r+s/2}),r+=s+n})}var vn=new WeakMap;function bc(e,t={}){return $o(e,ko,t),e}function wn(e,t,i){let n=t;for(;n!==void 0;){let o=e.parent(n);if(o===i)return n;n=o}}function $o(e,t,i){var n;let o=e.nodes().filter(v=>e.children(v).length),r={};o.forEach(v=>{let w=e.node(v);if(w&&w.rankdir){let x=new ye({multigraph:!0,compound:!0});x.setGraph({rankdir:w.rankdir});let y=e.children(v);y.forEach(O=>{let D={...e.node(O)};x.setNode(O,D);let P=e.parent(O);P&&P!==v&&y.includes(P)&&x.setParent(O,P)});let k=new Set;e.edges().forEach(O=>{let D=wn(e,O.v,v),P=wn(e,O.w,v);if(D===O.v&&P===O.w)x.setEdge(O,{...e.edge(O)});else if(D&&P&&D!==P){let R=`${D}\0${P}`;k.has(R)||(k.add(R),x.setEdge(D,P,{...e.edge(O)}))}}),$o(x,t,i);let A=Sn(x);kn(A,t,i,null),Cn(x,A);let S=1/0,E=1/0,z=-1/0,L=-1/0;x.nodes().forEach(O=>{if(O===v)return;let D=x.node(O);D&&typeof D.x=="number"&&typeof D.y=="number"&&typeof D.width=="number"&&typeof D.height=="number"&&(S=Math.min(S,D.x-D.width/2),z=Math.max(z,D.x+D.width/2),E=Math.min(E,D.y-D.height/2),L=Math.max(L,D.y+D.height/2))}),(!isFinite(S)||!isFinite(E)||!isFinite(z)||!isFinite(L))&&(S=E=0,z=L=0);let F=z-S,B=L-E;r[v]={minX:S,minY:E,maxX:z,maxY:L,width:F,height:B,offsetX:S,offsetY:E},w._dagreClusterSubgraph=x}});let a=[],s=v=>{let w=[],x=(e.children(v)||[]).filter(y=>y!==v);for(;x.length>0;){let y=x.shift();w.push(y),(e.children(y)||[]).filter(k=>k!==y).forEach(k=>x.push(k))}return w},l=new Map;o.forEach(v=>{let w=e.node(v);w&&w.rankdir&&r[v]&&l.set(v,(e.children(v)||[]).filter(x=>x!==v))});let c=new Set([...l.values()].flat()),d=new Map;l.forEach((v,w)=>{c.has(w)||d.set(w,s(w))});let p=new Set([...d.values()].flat()),h=v=>{for(let[w,x]of d)if(x.includes(v))return w;return v},f=[];e.edges().forEach(v=>{(p.has(v.v)||p.has(v.w))&&f.push({edge:v,label:e.edge(v)})});let g=new Map;p.forEach(v=>{let w=e.parent(v);g.set(v,typeof w=="string"?w:void 0)}),d.forEach((v,w)=>{let x=e.node(w),y=[];v.forEach(S=>{let E=e.node(S);E&&(y.push({id:S,node:E,parent:g.get(S)}),e.removeNode(S))});let k=f.filter(({edge:S})=>v.includes(S.v)||v.includes(S.w)),A=r[w];x&&(a.push({clusterId:w,subgraph:x._dagreClusterSubgraph,bounds:A,children:v,removedNodes:y,removedEdges:k}),x.width=A.width,x.height=A.height)});let b=new Set;f.forEach(({edge:v,label:w})=>{let x=h(v.v),y=h(v.w);if(x!==y&&e.hasNode(x)&&e.hasNode(y)){let k=`${x}\0${y}`;b.has(k)||(b.add(k),e.setEdge(x,y,{...w,width:0,height:0}))}});let m=Sn(e),C=kn(m,t,i,(n=vn.get(e))!=null?n:null);vn.set(e,C),Cn(e,m),b.forEach(v=>{let w=v.indexOf("\0"),x=v.slice(0,w),y=v.slice(w+1);e.hasEdge(x,y)&&e.removeEdge(x,y)}),a.forEach(({clusterId:v,subgraph:w,bounds:x,removedNodes:y,removedEdges:k})=>{var A,S;let E=e.node(v),z=(A=E?.x)!=null?A:0,L=(S=E?.y)!=null?S:0,F=(x.minX+x.maxX)/2,B=(x.minY+x.maxY)/2;y.forEach(({id:O,node:D,parent:P})=>{e.setNode(O,D),P!==void 0&&e.setParent(O,P)}),k.forEach(({edge:O,label:D})=>{e.setEdge(O,D)}),w.nodes().forEach(O=>{if(O===v)return;let D=w.node(O),P=e.node(O);P&&D&&typeof D.x=="number"&&typeof D.y=="number"&&(P.x=z+(D.x-F),P.y=L+(D.y-B))}),yn(e,w,z-F,L-B),delete E._dagreClusterSubgraph}),o.forEach(v=>{var w,x;let y=e.node(v),k=r[v];if(y&&y.rankdir&&y._dagreClusterSubgraph&&k){let A=y._dagreClusterSubgraph,S=(w=y.x)!=null?w:0,E=(x=y.y)!=null?x:0,z=(k.minX+k.maxX)/2,L=(k.minY+k.maxY)/2;A.nodes().forEach(F=>{if(F===v)return;let B=A.node(F),O=e.node(F);if(O&&B&&typeof B.x=="number"&&typeof B.y=="number"){let D=B.x-z,P=B.y-L;O.x=S+D,O.y=E+P}}),yn(e,A,S-z,E-L),delete y._dagreClusterSubgraph}})}function yn(e,t,i,n){t.edges().forEach(o=>{if(!e.hasEdge(o))return;let r=t.edge(o),a=e.edge(o);a.points=r.points.map(s=>({x:s.x+i,y:s.y+n})),Object.hasOwn(r,"x")&&(a.x=r.x+i,a.y=r.y+n)})}function kn(e,t,i,n=null){var o,r;let a=i?.useDynamic!==!1,s=a&&(o=n?.graph)!=null?o:null,l=a&&(r=n?.rawNodes)!=null?r:null;t("    makeSpaceForEdgeLabels",()=>Sc(e)),t("    removeSelfEdges",()=>Fc(e)),t("    acyclic",()=>al(e,s)),t("    nestingGraph.run",()=>_l(e)),t("    rank",()=>Cl(vo(e))),t("    injectEdgeLabelProxies",()=>Ac(e)),t("    removeEmptyRanks",()=>Ws(e)),t("    nestingGraph.cleanup",()=>Fl(e)),t("    normalizeRanks",()=>Hs(e)),t("    assignRankMinMax",()=>Mc(e)),t("    removeEdgeLabelProxies",()=>Tc(e)),t("    normalize.run",()=>dl(e)),t("    parentDummyChains",()=>Ml(e)),t("    addBorderSegments",()=>$l(e)),t("    order",()=>Io(e,i,l)),t("    insertSelfEdges",()=>$c(e)),t("    adjustCoordinateSystem",()=>Nl(e)),t("    position",()=>gc(e,i.corePath)),t("    positionSelfEdges",()=>jc(e));let c=JSON.parse(JSON.stringify(e._nodes));return t("    removeBorderNodes",()=>Ic(e)),t("    normalize.undo",()=>pl(e)),t("    fixupEdgeLabelCoords",()=>_c(e)),t("    undoCoordinateSystem",()=>ql(e)),t("    translateGraph",()=>Lc(e)),t("    assignNodeIntersects",()=>zc(e)),t("    reversePoints",()=>Bc(e)),t("    acyclic.undo",()=>ll(e)),{graph:e,rawNodes:c}}function Cn(e,t){e.nodes().forEach(i=>{let n=e.node(i),o=t.node(i);n&&(n.x=o.x,n.y=o.y,n.order=o.order,n.rank=o.rank,t.children(i).length&&(n.width=o.width,n.height=o.height))}),e.edges().forEach(i=>{let n=e.edge(i),o=t.edge(i);n.points=o.points,Object.hasOwn(o,"x")&&(n.x=o.x,n.y=o.y)}),e.graph().width=t.graph().width,e.graph().height=t.graph().height}var xc=["nodesep","edgesep","ranksep","marginx","marginy"],vc={ranksep:50,edgesep:20,nodesep:50,rankdir:"TB",rankalign:"center"},wc=["acyclicer","ranker","rankdir","align","rankalign"],yc=["width","height","rank"],En={width:0,height:0},kc=["minlen","weight","width","height","labeloffset"],Cc={minlen:1,weight:1,width:0,height:0,labeloffset:10,labelpos:"r"},Ec=["labelpos"];function Sn(e){let t=new ye({multigraph:!0,compound:!0}),i=Tt(e.graph());return t.setGraph(Object.assign({},vc,Mt(i,xc),st(i,wc))),e.nodes().forEach(n=>{let o=Mt(Tt(e.node(n)),yc);Object.keys(En).forEach(a=>{o[a]===void 0&&(o[a]=En[a])}),t.setNode(n,o);let r=e.parent(n);r!==void 0&&t.setParent(n,r)}),e.edges().forEach(n=>{let o=Tt(e.edge(n));t.setEdge(n,Object.assign({},Cc,Mt(o,kc),st(o,Ec)))}),t}function Sc(e){let t=e.graph();t.ranksep/=2,e.edges().forEach(i=>{var n;let o=e.edge(i);o.minlen*=2,((n=o.labelpos)!=null?n:"r").toLowerCase()!=="c"&&(t.rankdir==="TB"||t.rankdir==="BT"?o.width+=o.labeloffset:o.height+=o.labeloffset)})}function Ac(e){e.edges().forEach(t=>{let i=e.edge(t);if(i.width&&i.height){let n=e.node(t.v);Pe(e,"edge-proxy",{rank:(e.node(t.w).rank-n.rank)/2+n.rank,e:t},"_ep")}})}function Mc(e){let t=0;e.nodes().forEach(i=>{let n=e.node(i);n.borderTop&&(n.minRank=e.node(n.borderTop).rank,n.maxRank=e.node(n.borderBottom).rank,t=Math.max(t,n.maxRank))}),e.graph().maxRank=t}function Tc(e){e.nodes().forEach(t=>{let i=e.node(t);if(i.dummy==="edge-proxy"){let n=i;e.edge(n.e).labelRank=i.rank,e.removeNode(t)}})}function Lc(e){let t=Number.POSITIVE_INFINITY,i=0,n=Number.POSITIVE_INFINITY,o=0,r=e.graph(),a=r.marginx||0,s=r.marginy||0;function l(c){let d=c.x,p=c.y,h=c.width,f=c.height;t=Math.min(t,d-h/2),i=Math.max(i,d+h/2),n=Math.min(n,p-f/2),o=Math.max(o,p+f/2)}e.nodes().forEach(c=>l(e.node(c))),e.edges().forEach(c=>{let d=e.edge(c);Object.hasOwn(d,"x")&&l(d)}),t-=a,n-=s,e.nodes().forEach(c=>{let d=e.node(c);d.x-=t,d.y-=n}),e.edges().forEach(c=>{let d=e.edge(c);d.points.forEach(p=>{p.x-=t,p.y-=n}),Object.hasOwn(d,"x")&&(d.x-=t),Object.hasOwn(d,"y")&&(d.y-=n)}),r.width=i-t+a,r.height=o-n+s}function zc(e){e.edges().forEach(t=>{if(t.v===t.w)return;let i=e.edge(t),n=e.node(t.v),o=e.node(t.w),r,a;i.points?(r=i.points[0],a=i.points[i.points.length-1]):(i.points=[],r=o,a=n),i.points.unshift(ln(n,r)),i.points.push(ln(o,a))})}function _c(e){e.edges().forEach(t=>{let i=e.edge(t);if(Object.hasOwn(i,"x"))switch((i.labelpos==="l"||i.labelpos==="r")&&(i.width-=i.labeloffset),i.labelpos){case"l":i.x-=i.width/2+i.labeloffset;break;case"r":i.x+=i.width/2+i.labeloffset}})}function Bc(e){e.edges().forEach(t=>{let i=e.edge(t);i.reversed&&i.points.reverse()})}function Ic(e){e.nodes().forEach(t=>{if(e.children(t).length){let i=e.node(t),n=e.node(i.borderTop),o=e.node(i.borderBottom),r=e.node(i.borderLeft[i.borderLeft.length-1]),a=e.node(i.borderRight[i.borderRight.length-1]);i.width=Math.abs(a.x-r.x),i.height=Math.abs(o.y-n.y),i.x=r.x+i.width/2,i.y=n.y+i.height/2}}),e.nodes().forEach(t=>{e.node(t).dummy==="border"&&e.removeNode(t)})}function Fc(e){e.edges().forEach(t=>{if(t.v===t.w){let i=e.node(t.v);i.selfEdges||(i.selfEdges=[]),i.selfEdges.push({e:t,label:e.edge(t)}),e.removeEdge(t)}})}function $c(e){Ze(e).forEach(t=>{let i=0;t.forEach((n,o)=>{let r=e.node(n);typeof r.rank!="number"&&(r.rank=0),r.order=o+i,(r.selfEdges||[]).forEach(a=>{Pe(e,"selfedge",{width:a.label.width,height:a.label.height,rank:r.rank,order:o+ ++i,e:a.e,edgeLabel:a.label},"_se"),(!Array.isArray(a.label.points)||a.label.points.length!==7)&&(a.label.points=[{x:0,y:-10},{x:0,y:-10},{x:0,y:0},{x:0,y:10},{x:0,y:10},{x:0,y:0},{x:0,y:0}])}),delete r.selfEdges})})}function jc(e){e.nodes().forEach(t=>{let i=e.node(t),n=o=>typeof o=="number"&&isFinite(o);if(i.dummy==="selfedge"){let o=i,r=e.node(o.e.v),a=n(r?.x)?r.x:0,s=n(r?.y)?r.y:0,l=n(r?.width)?r.width:0,c=n(r?.height)?r.height:0,d=n(i.x)?i.x:a,p=n(i.y)?i.y:s,h=l/2,f=c/2;o.edgeLabel.points=[{x:d+h,y:p-f},{x:d+h,y:p-f},{x:d,y:p},{x:d-h,y:p+f},{x:d-h,y:p+f},{x:d,y:p},{x:d,y:p}],o.edgeLabel.x=d,o.edgeLabel.y=p,e.setEdge(o.e,o.edgeLabel),e.removeNode(t)}else i&&Array.isArray(i.selfEdges)&&i.selfEdges.forEach(o=>{if(!Array.isArray(o.label.points)||o.label.points.length!==7){let r=n(i.x)?i.x:0,a=n(i.y)?i.y:0,s=n(i.width)?i.width:0,l=n(i.height)?i.height:0,c=s/2,d=l/2;o.label.points=[{x:r+c,y:a-d},{x:r+c,y:a-d},{x:r,y:a},{x:r-c,y:a+d},{x:r-c,y:a+d},{x:r,y:a},{x:r,y:a}]}})})}function Mt(e,t){return pt(st(e,t),Number)}function Tt(e){let t={};return e&&Object.entries(e).forEach(([i,n])=>{typeof i=="string"&&(i=i.toLowerCase()),t[i]=n}),t}function Nc(e){let t=Ze(e),i=new ye({compound:!0,multigraph:!0}).setGraph({});return e.nodes().forEach(n=>{i.setNode(n,{label:n}),i.setParent(n,"layer"+e.node(n).rank)}),e.edges().forEach(n=>i.setEdge(n.v,n.w,{},n.name)),t.forEach((n,o)=>{let r="layer"+o;i.setNode(r,{rank:"same"}),n.reduce((a,s)=>(i.setEdge(a,s,{style:"invis"}),s))}),i}var An={graphlib:uo,version:Zs,layout:bc,debug:Nc,util:{time:Ys,notime:ko}},Lt=null;function Gt(e,t="12.5px system-ui, sans-serif"){if(typeof document<"u")try{Lt||(Lt=document.createElement("canvas"));const n=Lt.getContext("2d");if(n)return n.font=t,n.measureText(e).width}catch{}const i=t.includes("11px")?6.5:7.2;return e.length*i}function qc(e,t,i=!1){const n=i?140:160,o=(e||"").split(/\s+/);let r=1,a="",s=0;for(const d of o){const p=a?a+" "+d:d,h=Gt(p,"12.5px system-ui, sans-serif");h>n&&a?(r++,a=d,s=Math.max(s,Gt(d,"12.5px system-ui, sans-serif"))):(a=p,s=Math.max(s,h))}r=Math.min(2,r);const l=Math.min(180,Math.max(96,Math.ceil(Math.min(n,Math.max(s,32))+20+(i?20:0))));let c=r*17;return t&&(c+=15),{width:l,height:Math.max(34,c+12)}}function jo(e){if(!e)return{width:0,height:0};const t=Gt(e,"11px system-ui, sans-serif");return{width:Math.max(24,Math.ceil(t+14)),height:18}}function Oc(e,t){if(!e||e.length===0)return!1;for(const c of e)if((c.label||"").length>24)return!1;if(e.length===1)return!0;if(t.length!==e.length-1)return!1;const i={},n={};for(const c of e)i[c.id]=0,n[c.id]=0;for(const c of t){if(i[c.to]===void 0||n[c.from]===void 0)return!1;i[c.to]++,n[c.from]++}let o=0,r=0;for(const c of e){const d=i[c.id],p=n[c.id];if(d===0&&p===1)o++;else if(d===1&&p===0)r++;else if(!(d===1&&p===1))return!1}if(o!==1||r!==1)return!1;const a=new Map;for(const c of t)a.set(c.from,c.to);let s=e.find(c=>i[c.id]===0)?.id,l=0;for(;s;)l++,s=a.get(s);return l===e.length}function Dc(e,t,i,n){const o={};for(const y of e)o[y.id]=0;for(const y of t)o[y.to]!==void 0&&o[y.to]++;const r=new Map,a=new Map;for(const y of t)r.set(y.from,y.to),a.set(`${y.from}->${y.to}`,y);const s=[];let l=e.find(y=>o[y.id]===0)?.id;const c=new Map(e.map(y=>[y.id,y]));for(;l;){const y=c.get(l);y&&s.push(y),l=r.get(l)}if(s.length<e.length)for(const y of e)s.includes(y)||s.push(y);const d=new Map((i||[]).map(y=>[y.id,y])),p=150,h=36,f=42,g=24;let b;if(s.length<=4)b=s.length;else{const y=Math.max(336,(n&&n>0?n:640)-48);b=Math.max(2,Math.min(s.length,Math.floor((y+h)/186)))}const m=40,C=[];for(let y=0;y<s.length;y++){const k=s[y],A=y%b,S=Math.floor(y/b),E=g+A*186+p/2,z=g+S*82+m/2,L=k.group?d.get(k.group):void 0,F=k.color||L?.color;C.push({id:k.id,label:k.label,sub:k.sub,icon:k.icon,decision:!!k.decision,isStart:y===0,isEnd:y===s.length-1,color:F,x:E,y:z,width:p,height:m})}const v=[];let w=0,x=0;for(const y of C)w=Math.max(w,y.x+y.width/2),x=Math.max(x,y.y+y.height/2);for(let y=0;y<s.length-1;y++){const k=C[y],A=C[y+1],S=a.get(`${k.id}->${A.id}`),E=S?.label?.trim()||"",z=E?jo(E):{width:0,height:0},L=S?.tone||"neutral";y%b;const F=Math.floor(y/b);(y+1)%b;const B=Math.floor((y+1)/b);let O=[],D=0,P=0;if(F===B){const R=k.x+p/2,Q=k.y,ee=A.x-p/2,X=A.y;O=[{x:R,y:Q},{x:ee,y:X}],D=(R+ee)/2,P=Q}else{const R=k.y+m/2+f/2,Q={x:k.x+p/2,y:k.y},ee={x:k.x+p/2+16,y:k.y},X={x:k.x+p/2+16,y:R},j={x:A.x-p/2-16,y:R};O=[Q,ee,X,j,{x:A.x-p/2-16,y:A.y},{x:A.x-p/2,y:A.y}],D=(X.x+j.x)/2,P=R,w=Math.max(w,ee.x)}for(const R of O)w=Math.max(w,R.x),x=Math.max(x,R.y);v.push({from:k.id,to:A.id,label:E||void 0,tone:L,points:O,labelX:E?D:void 0,labelY:E?P:void 0,labelWidth:z.width,labelHeight:z.height})}return{width:Math.ceil(w+g),height:Math.ceil(x+g),rankdir:s.length<=4?"LR":"TB",nodes:C,edges:v}}function Mn(e,t,i,n){const o=new An.graphlib.Graph;o.setGraph({rankdir:n,nodesep:28,ranksep:44,edgesep:12}),o.setDefaultEdgeLabel(()=>({}));const r={},a={};for(const w of e)r[w.id]=0,a[w.id]=0;for(const w of t)r[w.to]!==void 0&&r[w.to]++,a[w.from]!==void 0&&a[w.from]++;const s=new Map((i||[]).map(w=>[w.id,w]));for(const w of e){const x=r[w.id]===0,y=a[w.id]===0,k=!!w.decision||w.label.trim().endsWith("?")||a[w.id]>=2&&t.some(L=>L.from===w.id&&/^(yes|no|true|false)$/i.test((L.label||"").trim())),{width:A,height:S}=qc(w.label,w.sub,!!w.icon),E=w.group?s.get(w.group):void 0,z=w.color||E?.color;o.setNode(w.id,{id:w.id,label:w.label,sub:w.sub,icon:w.icon,decision:k,isStart:x,isEnd:y,color:z,width:A,height:S})}for(const w of t){const x=!!w.label&&w.label.trim().length>0,y=x?jo(w.label):{width:0,height:0},k=w.label?w.label.trim():"";let A=w.tone||"neutral";!w.tone&&x&&(/^(yes|true)$/i.test(k)?A="positive":/^(no|false)$/i.test(k)&&(A="negative")),o.setEdge(w.from,w.to,{from:w.from,to:w.to,label:k,width:y.width,height:y.height,labelpos:"c",tone:A})}An.layout(o);const l=[];let c=1/0,d=1/0,p=-1/0,h=-1/0;for(const w of o.nodes()){const x=o.node(w);x&&(l.push({id:x.id||w,label:x.label,sub:x.sub,icon:x.icon,decision:x.decision,isStart:x.isStart,isEnd:x.isEnd,color:x.color,x:x.x,y:x.y,width:x.width,height:x.height}),c=Math.min(c,x.x-x.width/2),d=Math.min(d,x.y-x.height/2),p=Math.max(p,x.x+x.width/2),h=Math.max(h,x.y+x.height/2))}const f=[];for(const w of o.edges()){const x=o.edge(w);if(!x)continue;const y=(x.points||[]).map(k=>({x:k.x,y:k.y}));for(const k of y)c=Math.min(c,k.x),d=Math.min(d,k.y),p=Math.max(p,k.x),h=Math.max(h,k.y);if(x.x!==void 0&&x.y!==void 0&&x.label){const k=(x.width||0)/2,A=(x.height||0)/2;c=Math.min(c,x.x-k),d=Math.min(d,x.y-A),p=Math.max(p,x.x+k),h=Math.max(h,x.y+A)}f.push({from:w.v,to:w.w,label:x.label,tone:x.tone,points:y,labelX:x.x,labelY:x.y,labelWidth:x.width,labelHeight:x.height})}const g=12,b=-c+g,m=-d+g,C=Math.ceil(Math.max(120,p-c+24)),v=Math.ceil(Math.max(60,h-d+24));for(const w of l)w.x+=b,w.y+=m;for(const w of f){for(const x of w.points)x.x+=b,x.y+=m;w.labelX!==void 0&&(w.labelX+=b),w.labelY!==void 0&&(w.labelY+=m)}return{width:C,height:v,rankdir:n,nodes:l,edges:f}}function Rc(e,t,i,n){if(!e||e.length===0)return{width:0,height:0,rankdir:"TB",nodes:[],edges:[]};if(Oc(e,t))return Dc(e,t,i,n);const o=Mn(e,t,i,"TB");if(o.width>0&&o.height/o.width>1.6){const r=Mn(e,t,i,"LR"),a=n&&n>0?n:640;if(r.width<=a||r.height<o.height)return r}return o}function Pc(e){if(!e||e.length<=1)return"";if(e.length===2)return`M ${e[0].x} ${e[0].y} L ${e[1].x} ${e[1].y}`;let t=`M ${e[0].x} ${e[0].y}`;for(let i=1;i<e.length-1;i++){const n=(e[i].x+e[i+1].x)/2,o=(e[i].y+e[i+1].y)/2;t+=` Q ${e[i].x} ${e[i].y}, ${n} ${o}`}return t+=` L ${e[e.length-1].x} ${e[e.length-1].y}`,t}var Vc=.4,Hc=2.5,Tn=.15;function Wc(e,t){const i=u("div",{class:"iui-card flow-card"});e.title&&i.appendChild(u("div",{class:"iui-title flow-title"},e.title));const n=e.nodes||[],o=e.edges||[],r=e.groups||[],a=new Map(n.map(T=>[T.id,T])),s=new Map(r.map(T=>[T.id,T.label])),l=new Map,c=new Map;for(const T of o){const Y=c.get(T.from)||[];Y.push(T),c.set(T.from,Y);const W=l.get(T.to)||[];W.push(T),l.set(T.to,W)}const d=Rc(n,o,r),p=u("div",{class:"flow-diagram",role:"region"}),h=u("ol",{class:"iui-sr-only"}),f=new Map(n.map(T=>[T.id,T.label]));for(const T of o){const Y=f.get(T.from)||T.from,W=f.get(T.to)||T.to;h.appendChild(u("li",{},`${Y} \u2192 ${W}${T.label?` (${T.label})`:""}`))}if(o.length===0)for(const T of n)h.appendChild(u("li",{},T.label));p.appendChild(h);const g=u("div",{class:"flow-controls iui-diagram-controls",role:"group","aria-label":"Flow zoom controls"}),b=u("button",{class:"flow-control-btn",type:"button","aria-label":"Zoom out",title:"Zoom out"},"\u2212"),m=u("span",{class:"flow-zoom-value","aria-live":"polite"},"100%"),C=u("button",{class:"flow-control-btn",type:"button","aria-label":"Zoom in",title:"Zoom in"},"+"),v=u("button",{class:"flow-fit-btn",type:"button","aria-label":"Fit diagram to view",title:"Fit to view"},"Fit"),w=u("button",{class:"flow-control-btn",type:"button","aria-label":"Reset zoom",title:"Reset view (or double-click)"},"\u21ba");g.append(b,m,C,v,w),p.appendChild(g);const x=u("div",{class:"flow-viewport",role:"region","aria-label":`Flow diagram: ${e.title||"Untitled"}, ${n.length} nodes`}),y=u("div",{class:"flow-inner"});y.style.width=`${d.width}px`,y.style.height=`${d.height}px`,y.style.position="relative",y.style.margin="0 auto",y.style.transformOrigin="top center";const k=`flow-arrow-${Math.random().toString(36).slice(2,8)}`,A="http://www.w3.org/2000/svg",S=document.createElementNS(A,"svg");S.setAttribute("class","flow-svg-overlay"),S.setAttribute("width",String(d.width)),S.setAttribute("height",String(d.height)),S.setAttribute("viewBox",`0 0 ${d.width} ${d.height}`),S.style.position="absolute",S.style.inset="0",S.style.width=`${d.width}px`,S.style.height=`${d.height}px`,S.style.pointerEvents="none",S.style.overflow="visible";const E=document.createElementNS(A,"defs"),z=document.createElementNS(A,"marker");z.setAttribute("id",k),z.setAttribute("viewBox","0 0 6 6"),z.setAttribute("refX","5"),z.setAttribute("refY","3"),z.setAttribute("markerWidth","4.5"),z.setAttribute("markerHeight","4.5"),z.setAttribute("orient","auto-start-reverse");const L=document.createElementNS(A,"path");L.setAttribute("d","M 0 0.75 L 5 3 L 0 5.25 z"),L.setAttribute("fill","currentColor"),z.appendChild(L),E.appendChild(z),S.appendChild(E);const F=[];for(const T of d.edges){const Y=Pc(T.points);if(!Y)continue;const W=document.createElementNS(A,"path");W.setAttribute("d",Y),W.setAttribute("fill","none"),W.setAttribute("stroke","currentColor"),W.setAttribute("stroke-width","1.25"),W.setAttribute("stroke-linecap","round"),W.setAttribute("stroke-linejoin","round"),W.setAttribute("marker-end",`url(#${k})`),W.setAttribute("data-from",T.from),W.setAttribute("data-to",T.to);const re=T.tone==="positive"?"is-positive":T.tone==="negative"?"is-negative":"is-neutral";W.setAttribute("class",`flow-edge-path ${re}`),S.appendChild(W),F.push(W)}y.appendChild(S);const B=[];for(const T of d.edges){if(!T.label||T.labelX===void 0||T.labelY===void 0)continue;const Y=u("span",{class:`flow-edge-label ${T.tone?`tone-${T.tone}`:""}`,style:`left: ${T.labelX}px; top: ${T.labelY}px;`,"data-from":T.from,"data-to":T.to},T.label);y.appendChild(Y),B.push(Y)}const O=[];let D=!1;for(const T of d.nodes){const Y=T.isStart||T.isEnd,W=T.decision,re=["flow-node"];Y&&re.push("is-pill"),W&&re.push("is-decision"),T.color&&re.push(`c-${T.color}`);const se=u("div",{class:re.join(" "),"data-node-id":T.id,tabindex:"0",role:"button","aria-pressed":"false",style:`left: ${T.x-T.width/2}px; top: ${T.y-T.height/2}px; width: ${T.width}px; height: ${T.height}px;`});if(T.icon){const le=u("span",{class:"flow-node-iconbox"},K(T.icon,14));se.appendChild(le)}const pe=u("div",{class:"flow-node-text"}),ge=u("span",{class:"flow-node-label"},T.label);if(pe.appendChild(ge),T.sub){const le=u("span",{class:"flow-node-sub"},T.sub);pe.appendChild(le)}se.appendChild(pe),se.addEventListener("pointerdown",()=>{D=!0,requestAnimationFrame(()=>{D=!1})}),se.addEventListener("focus",()=>{!D&&R!==T.id&&ee(T.id)}),se.addEventListener("click",le=>{te||(le.stopPropagation(),ee(R===T.id?null:T.id))}),se.addEventListener("keydown",le=>{le.key==="Enter"||le.key===" "?(le.preventDefault(),le.stopPropagation(),ee(R===T.id?null:T.id)):le.key==="Escape"&&R!==null&&(le.preventDefault(),le.stopPropagation(),ee(null))}),y.appendChild(se),O.push(se)}const P=u("div",{class:"flow-node-detail",role:"region","aria-live":"polite","aria-label":"Selected node details",hidden:!0});x.appendChild(y),p.appendChild(x),p.appendChild(P),i.appendChild(p);let R=null;function Q(T){if(de(P),!T){P.hidden=!0;return}const Y=a.get(T);if(!Y){P.hidden=!0;return}P.hidden=!1;const W=u("div",{class:"flow-node-detail-header"}),re=u("div",{class:"flow-node-detail-title-wrap"});if(re.appendChild(u("span",{class:"flow-node-detail-title"},Y.label)),Y.group){const le=s.get(Y.group)||Y.group;re.appendChild(u("span",{class:"flow-node-detail-group"},le))}const se=u("button",{class:"flow-node-detail-close",type:"button","aria-label":"Close node details",title:"Close (Esc)"},"\u00d7");se.onclick=()=>ee(null),W.append(re,se),P.appendChild(W),Y.sub&&P.appendChild(u("div",{class:"flow-node-detail-sub"},Y.sub)),Y.detail&&P.appendChild(u("div",{class:"flow-node-detail-body"},Y.detail));const pe=l.get(T)||[],ge=c.get(T)||[];if(pe.length>0||ge.length>0){const le=u("div",{class:"flow-node-detail-conns"});if(pe.length>0){const Z=pe.map(ne=>{const ke=f.get(ne.from)||ne.from;return ne.label?`${ke} (${ne.label})`:ke});le.appendChild(u("div",{class:"flow-node-detail-conn"},u("span",{class:"flow-node-detail-conn-dir"},"In:"),u("span",{class:"flow-node-detail-conn-text"},Z.join(", "))))}if(ge.length>0){const Z=ge.map(ne=>{const ke=f.get(ne.to)||ne.to;return ne.label?`${ke} (${ne.label})`:ke});le.appendChild(u("div",{class:"flow-node-detail-conn"},u("span",{class:"flow-node-detail-conn-dir"},"Out:"),u("span",{class:"flow-node-detail-conn-text"},Z.join(", "))))}P.appendChild(le)}}function ee(T){R=T,y.classList.toggle("has-selection",T!==null);const Y=new Set;if(T!==null){Y.add(T);for(const W of l.get(T)||[])Y.add(W.from);for(const W of c.get(T)||[])Y.add(W.to)}for(const W of O){const re=W.dataset.nodeId||"",se=T!==null&&re===T,pe=T!==null&&Y.has(re);W.classList.toggle("is-selected",se),W.classList.toggle("is-neighbor",pe&&!se),W.classList.toggle("is-dimmed",T!==null&&!pe),W.setAttribute("aria-pressed",se?"true":"false")}for(const W of F){const re=W.getAttribute("data-from"),se=W.getAttribute("data-to"),pe=T!==null&&(re===T||se===T);W.classList.toggle("is-highlighted",pe),W.classList.toggle("is-dimmed",T!==null&&!pe)}for(const W of B){const re=W.getAttribute("data-from"),se=W.getAttribute("data-to"),pe=T!==null&&(re===T||se===T);W.classList.toggle("is-highlighted",pe),W.classList.toggle("is-dimmed",T!==null&&!pe)}Q(T)}let X=1,j=0,$=0,_=1,I=1;function M(){const T=_*X;y.style.transform=`translate(${j}px, ${$}px) scale(${T})`,y.style.transformOrigin="top center",m.textContent=`${Math.round(X*100)}%`}function q(){const T=x.clientWidth||i.clientWidth||d.width;let Y=1;T>0&&d.width>0&&(Y=Math.min(1,T/d.width));const W=416;let re=1;d.height>W&&(re=W/d.height),I=Math.min(Y,re),_=Math.max(.7,Math.min(1,I));const se=_*X;y.style.margin="0 auto";const pe=(T-d.width)/2;y.style.left=`${pe}px`;const ge=Math.ceil(d.height*se);x.style.height=`${Math.min(W,Math.max(ge,80))}px`,x.style.overflow="hidden",M()}function V(T){return Math.min(Hc,Math.max(Vc,+T.toFixed(2)))}C.onclick=()=>{X=V(X+Tn),q()},b.onclick=()=>{X=V(X-Tn),q()},v.onclick=()=>{j=0,$=0,X=_>0?V(Math.min(1,I/_)):1,q()},w.onclick=()=>{X=1,j=0,$=0,q()};let U=!1,G=!1,te=!1,H=0,J=0,oe=0,ae=0;const fe=T=>{if(T.button!==0)return;const Y=T.target;Y?.closest(".flow-controls")||Y?.closest(".flow-node-detail")||(U=!0,G=!1,H=T.clientX,J=T.clientY,oe=j,ae=$)},ue=T=>{if(!U)return;const Y=T.clientX-H,W=T.clientY-J;!G&&Math.hypot(Y,W)>4&&(G=!0,x.classList.add("is-panning")),G&&(j=oe+Y,$=ae+W,M())},ie=()=>{U&&(U=!1,x.classList.remove("is-panning"),G&&(te=!0,setTimeout(()=>{te=!1},0)))};x.addEventListener("pointerdown",fe),window.addEventListener("pointermove",ue),window.addEventListener("pointerup",ie),window.addEventListener("pointercancel",ie),x.addEventListener("click",T=>{te||!T.target?.closest(".flow-node")&&R!==null&&ee(null)}),x.addEventListener("dblclick",T=>{const Y=T.target;Y?.closest(".flow-controls")||Y?.closest(".flow-node-detail")||(X=1,j=0,$=0,q())});const ve=T=>{if(!T.ctrlKey&&!T.metaKey)return;T.preventDefault();const Y=T.deltaY<0?1.1:.9;X=V(X*Y),q()};x.addEventListener("wheel",ve,{passive:!1});const he=T=>{T.key==="Escape"&&R!==null&&ee(null)};document.addEventListener("keydown",he);const Me=typeof ResizeObserver<"u"?new ResizeObserver(()=>q()):null;return Me?.observe(x),t.onCleanup(()=>{Me?.disconnect(),window.removeEventListener("pointermove",ue),window.removeEventListener("pointerup",ie),window.removeEventListener("pointercancel",ie),document.removeEventListener("keydown",he)}),requestAnimationFrame(()=>{q(),requestAnimationFrame(()=>q())}),i}var Uc=0,Gc={blue:"var(--iui-color-blue, #3b82f6)",green:"var(--iui-color-green, #22c55e)",amber:"var(--iui-color-amber, #f59e0b)",orange:"var(--iui-color-orange, #f97316)",red:"var(--iui-color-red, #ef4444)",purple:"var(--iui-color-purple, #a855f7)",teal:"var(--iui-color-teal, #14b8a6)",pink:"var(--iui-color-pink, #ec4899)",gray:"var(--iui-color-gray, #71717a)",sky:"var(--iui-color-sky, #0ea5e9)",mint:"var(--iui-color-mint, #6ee7b7)",butter:"var(--iui-color-butter, #fde68a)",peach:"var(--iui-color-peach, #fdba74)",rose:"var(--iui-color-rose, #fb7185)",lavender:"var(--iui-color-lavender, #c4b5fd)",stone:"var(--iui-color-stone, #a8a29e)"};function di(e){return e?Gc[e]:void 0}function Re(e){if(!e.children||e.children.length===0)return 0;let t=e.children.length;for(const i of e.children)t+=Re(i);return t}function Yt(e,t,i=new Set){if(e.id===t)return i.add(e.id),!0;if(!e.children)return!1;for(const n of e.children)if(Yt(n,t,i))return i.add(e.id),!0;return!1}function No(e,t,i){const n=e.label.toLowerCase().includes(t)||(e.note??"").toLowerCase().includes(t)||(e.badge??"").toLowerCase().includes(t);let o=!1;if(e.children)for(const r of e.children)No(r,t,i)&&(o=!0);return(n||o)&&i.add(e.id),n||o}function Yc(e,t,i,n,o,r){const a=u("ul",{class:"iui-tree-outline-root",role:"tree","aria-label":"Tree outline"});function s(l,c){const d=!(!l.children||l.children.length===0),p=l.collapsed??!1,h=u("li",{class:"iui-tree-ol-item",role:"treeitem","aria-expanded":d?String(!p):void 0,"aria-level":String(c),tabindex:"0","data-node-id":l.id}),f=u("div",{class:"iui-tree-ol-row"});if(d){const m=u("button",{class:"iui-tree-ol-chevron",type:"button","aria-label":"Toggle children",tabindex:"-1"},"\u25b6");f.appendChild(m),m.addEventListener("click",C=>{C.stopPropagation();const v=i.get(l.id);if(!v)return;v.collapsed=!v.collapsed;const w=h.querySelector(":scope > .iui-tree-ol-children");w&&(w.style.display=v.collapsed?"none":""),m.textContent=v.collapsed?"\u25b6":"\u25bc";const x=h.querySelector(".iui-tree-ol-count-badge");x&&(x.style.display=v.collapsed?"":"none",x.textContent=`+${Re(l)}`),h.setAttribute("aria-expanded",String(!v.collapsed))})}else f.appendChild(u("span",{class:"iui-tree-ol-leaf-dot"}));const g=di(l.color),b=u("span",{class:"iui-tree-ol-label",...g?{style:`color: ${g}`}:{}},l.label);if(f.appendChild(b),l.badge&&f.appendChild(u("span",{class:"iui-tree-ol-badge"},l.badge)),d){const m=u("span",{class:"iui-tree-ol-count-badge",style:"display: none"},`+${Re(l)}`);f.appendChild(m)}if(h.appendChild(f),i.set(l.id,{el:h,collapsed:p,node:l}),h.addEventListener("click",m=>{m.stopPropagation(),n(o.v===l.id?null:l.id)}),h.addEventListener("keydown",m=>{if(m.key==="Enter"||m.key===" ")m.preventDefault(),m.stopPropagation(),n(o.v===l.id?null:l.id);else if(m.key==="ArrowRight"){m.preventDefault(),m.stopPropagation();const C=i.get(l.id);d&&C?.collapsed?f.querySelector(".iui-tree-ol-chevron")?.click():d&&h.querySelector(":scope > .iui-tree-ol-children > .iui-tree-ol-item")?.focus()}else if(m.key==="ArrowLeft"){m.preventDefault(),m.stopPropagation();const C=i.get(l.id);d&&C&&!C.collapsed?f.querySelector(".iui-tree-ol-chevron")?.click():h.parentElement?.closest(".iui-tree-ol-item")?.focus()}else if(m.key==="ArrowDown"||m.key==="ArrowUp"){m.preventDefault(),m.stopPropagation();const C=Array.from(a.querySelectorAll(".iui-tree-ol-item")).filter(w=>{let x=w.parentElement;for(;x&&x!==a;){if(x.classList.contains("iui-tree-ol-children")&&x.style.display==="none")return!1;x=x.parentElement}return!0}),v=C.indexOf(h);v!==-1&&C[m.key==="ArrowDown"?Math.min(v+1,C.length-1):Math.max(v-1,0)]?.focus()}}),d){const m=u("ul",{class:"iui-tree-ol-children",role:"group",style:p?"display: none":""});for(const C of l.children)m.appendChild(s(C,c+1));if(h.appendChild(m),p){const C=h.querySelector(".iui-tree-ol-chevron");C&&(C.textContent="\u25b6");const v=h.querySelector(".iui-tree-ol-count-badge");v&&(v.style.display="")}}return h}return a.appendChild(s(e,1)),a}function Kc(e,t,i,n,o){const r=t==="horizontal",a=++Uc;let s=0,l=0;const c=u("div",{class:`iui-tree-diagram ${r?"iui-tree-h":"iui-tree-v"}`,role:"tree","aria-label":"Tree diagram"});function d(p,h){const f=p.collapsed??!1,g=!!(p.children&&p.children.length>0),b=u("div",{class:`iui-tree-dn-wrapper${f?" is-collapsed":""}`,"data-node-id":p.id}),m=g?`iui-tree-${a}-group-${++s}`:void 0,C=u("div",{class:"iui-tree-dn-node",tabindex:l++===0?"0":"-1",role:"treeitem","aria-label":p.label+(p.note?`: ${p.note}`:""),"aria-level":String(h),...m?{"aria-owns":m}:{},"data-node-id":p.id}),v=di(p.color);v&&(C.style.borderColor=v);const w=u("div",{class:"iui-tree-dn-label-row"});if(g){const y=u("button",{class:"iui-tree-dn-chevron",type:"button","aria-label":"Toggle children",tabindex:"-1"},"\u25bc");w.appendChild(y),y.addEventListener("click",k=>{k.stopPropagation();const A=i.get(p.id);if(!A)return;A.collapsed=!A.collapsed,b.classList.toggle("is-collapsed",A.collapsed);const S=b.querySelector(":scope > .iui-tree-dn-children");S&&(S.style.display=A.collapsed?"none":""),y.textContent=A.collapsed?"\u25b6":"\u25bc";const E=C.querySelector(".iui-tree-dn-count");E&&(E.style.display=A.collapsed?"":"none",E.textContent=`+${Re(p)}`),C.setAttribute("aria-expanded",String(!A.collapsed))})}const x=u("span",{class:"iui-tree-dn-label",...v?{style:`color: ${v}`}:{}},p.label);if(w.appendChild(x),p.badge&&w.appendChild(u("span",{class:"iui-tree-dn-badge"},p.badge)),g){const y=u("span",{class:"iui-tree-dn-count",style:"display: none"},`+${Re(p)}`);w.appendChild(y)}if(C.appendChild(w),p.note&&h===1&&C.appendChild(u("div",{class:"iui-tree-dn-note"},p.note)),C.addEventListener("click",()=>{n(o.v===p.id?null:p.id)}),C.addEventListener("focus",()=>{c.querySelectorAll(".iui-tree-dn-node").forEach(y=>{y.tabIndex=y===C?0:-1})}),C.addEventListener("keydown",y=>{if(y.key==="Enter"||y.key===" ")y.preventDefault(),n(o.v===p.id?null:p.id);else if(y.key==="ArrowRight"){y.preventDefault();const k=i.get(p.id);g&&k?.collapsed?C.querySelector(".iui-tree-dn-chevron")?.click():g&&b.querySelector(":scope > .iui-tree-dn-children > .iui-tree-dn-wrapper > .iui-tree-dn-node")?.focus()}else if(y.key==="ArrowLeft"){y.preventDefault();const k=i.get(p.id);g&&k&&!k.collapsed?C.querySelector(".iui-tree-dn-chevron")?.click():b.parentElement?.closest(".iui-tree-dn-wrapper")?.querySelector(":scope > .iui-tree-dn-node")?.focus()}else if(y.key==="ArrowDown"||y.key==="ArrowUp"||y.key==="Home"||y.key==="End"){y.preventDefault();const k=Array.from(c.querySelectorAll(".iui-tree-dn-node")).filter(S=>{let E=S.parentElement;for(;E&&E!==c;){if(E.classList.contains("iui-tree-dn-children")&&E.style.display==="none")return!1;E=E.parentElement}return!0}),A=k.indexOf(C);k[y.key==="Home"?0:y.key==="End"?k.length-1:y.key==="ArrowDown"?Math.min(A+1,k.length-1):Math.max(A-1,0)]?.focus()}}),b.appendChild(C),g&&C.setAttribute("aria-expanded",String(!f)),i.set(p.id,{el:C,collapsed:f,node:p}),g){const y=u("div",{class:"iui-tree-dn-children",id:m,role:"group",style:f?"display: none":""});for(const k of p.children)y.appendChild(d(k,h+1));if(b.appendChild(y),f){const k=C.querySelector(".iui-tree-dn-chevron");k&&(k.textContent="\u25b6");const A=C.querySelector(".iui-tree-dn-count");A&&(A.style.display="")}}return b}return c.appendChild(d(e,1)),c}function Xc(e,t){const i=u("div",{class:"iui-card iui-tree-card"}),n=u("div",{class:"iui-tree-header"});e.title&&n.appendChild(u("div",{class:"iui-title iui-tree-title"},e.title));const o=u("div",{class:"iui-tree-controls"}),r=u("input",{class:"iui-tree-search",type:"search",placeholder:"Filter nodes\u2026","aria-label":"Filter tree nodes"});o.appendChild(r);const a=u("button",{class:"iui-tree-ctrl-btn",type:"button",title:"Expand all"},"Expand all"),s=u("button",{class:"iui-tree-ctrl-btn",type:"button",title:"Collapse all"},"Collapse all");o.appendChild(a),o.appendChild(s);const l=u("div",{class:"iui-tree-toggle",role:"group","aria-label":"View mode"}),c=u("button",{class:"iui-tree-toggle-btn is-active",type:"button","aria-pressed":"true"},"Diagram"),d=u("button",{class:"iui-tree-toggle-btn",type:"button","aria-pressed":"false"},"Outline");l.appendChild(c),l.appendChild(d),o.appendChild(l),n.appendChild(o),i.appendChild(n);const p=u("div",{class:"iui-tree-detail-bar",style:"display:none"}),h=u("button",{class:"iui-tree-detail-close",type:"button","aria-label":"Close detail"},"\u00d7"),f=u("div",{class:"iui-tree-detail-content"});p.appendChild(f),p.appendChild(h);const g=new Map,b={v:null},m={v:""};let C=e.layout==="outline"?"outline":e.layout??"vertical",v=e.layout==="outline"?"outline":"diagram";const w=u("div",{class:"iui-tree-content"});i.appendChild(p),i.appendChild(w);function x(E){if(w.querySelectorAll(".iui-tree-dn-node, .iui-tree-ol-row").forEach(L=>{L.classList.remove("is-selected","is-ancestor")}),!E)return;const z=new Set;Yt(e.root,E,z),w.querySelectorAll("[data-node-id]").forEach(L=>{const F=L.dataset.nodeId;if(F&&(L.classList.contains("iui-tree-dn-node")||L.classList.contains("iui-tree-ol-item"))){if(F===E){L.classList.add("is-selected");const B=L.querySelector(".iui-tree-ol-row");B&&B.classList.add("is-selected")}else if(z.has(F)){L.classList.add("is-ancestor");const B=L.querySelector(".iui-tree-ol-row");B&&B.classList.add("is-ancestor")}}})}function y(E){if(!E){p.style.display="none";return}const z=g.get(E);if(!z){p.style.display="none";return}const{node:L}=z;for(;f.firstChild;)f.removeChild(f.firstChild);const F=di(L.color),B=u("strong",{class:"iui-tree-detail-label",...F?{style:`color:${F}`}:{}},L.label);f.appendChild(B),L.badge&&f.appendChild(u("span",{class:"iui-tree-detail-badge"},L.badge)),L.note&&f.appendChild(u("span",{class:"iui-tree-detail-note"},L.note)),!L.note&&!L.badge&&f.appendChild(u("span",{class:"iui-tree-detail-note",style:"opacity:0.5"},"No additional details")),p.style.display=""}function k(E){b.v=E,x(E),y(E)}h.addEventListener("click",()=>k(null));function A(){for(g.forEach(E=>{E.node.collapsed=E.collapsed});w.firstChild;)w.removeChild(w.firstChild);if(g.clear(),b.v=null,p.style.display="none",v==="diagram"){const E=C==="outline"?"vertical":C;w.appendChild(Kc(e.root,E,g,k,b))}else w.appendChild(Yc(e.root,e,g,k,b,m));m.v&&S(m.v)}function S(E){m.v=E.toLowerCase().trim();const z=m.v;if(!z){g.forEach(F=>{F.el.closest(".iui-tree-ol-item, .iui-tree-dn-wrapper")?.style.setProperty("display",""),F.el.classList.remove("is-search-match","is-search-miss")});return}const L=new Set;No(e.root,z,L),g.forEach((F,B)=>{const O=F.el.closest(".iui-tree-ol-item, .iui-tree-dn-wrapper");if(L.has(B)){F.el.classList.add("is-search-match"),F.el.classList.remove("is-search-miss"),O&&O.style.removeProperty("display");const D=new Set;Yt(e.root,B,D),D.forEach(P=>{const R=g.get(P);if(R&&R.collapsed){R.collapsed=!1;const Q=R.el.closest(".iui-tree-ol-item, .iui-tree-dn-wrapper")?.querySelector(":scope > .iui-tree-ol-children, :scope > .iui-tree-dn-children");Q&&(Q.style.display="");const ee=R.el.querySelector(".iui-tree-ol-chevron, .iui-tree-dn-chevron");ee&&(ee.textContent="\u25bc"),R.node.children?.length&&R.el.setAttribute("aria-expanded","true");const X=R.el.querySelector(".iui-tree-ol-count-badge, .iui-tree-dn-count");X&&(X.style.display="none")}})}else F.el.classList.remove("is-search-match"),F.el.classList.add("is-search-miss")})}return r.addEventListener("input",()=>S(r.value)),a.addEventListener("click",()=>{g.forEach(E=>{E.collapsed=!1;const z=E.el.closest(".iui-tree-ol-item, .iui-tree-dn-wrapper");if(!z)return;const L=z.querySelector(":scope > .iui-tree-ol-children, :scope > .iui-tree-dn-children");L&&(L.style.display=""),E.node.children?.length&&E.el.setAttribute("aria-expanded","true");const F=z.querySelector(".iui-tree-ol-chevron, .iui-tree-dn-chevron");F&&(F.textContent="\u25bc");const B=z.querySelector(".iui-tree-ol-count-badge, .iui-tree-dn-count");B&&(B.style.display="none")})}),s.addEventListener("click",()=>{g.forEach(E=>{if(!E.node.children||E.node.children.length===0)return;E.collapsed=!0;const z=E.el.closest(".iui-tree-ol-item, .iui-tree-dn-wrapper");if(!z)return;const L=z.querySelector(":scope > .iui-tree-ol-children, :scope > .iui-tree-dn-children");L&&(L.style.display="none"),E.el.setAttribute("aria-expanded","false");const F=z.querySelector(".iui-tree-ol-chevron, .iui-tree-dn-chevron");F&&(F.textContent="\u25b6");const B=z.querySelector(".iui-tree-ol-count-badge, .iui-tree-dn-count");B&&(B.style.display="",B.textContent=`+${Re(E.node)}`)})}),c.addEventListener("click",()=>{v!=="diagram"&&(v="diagram",c.classList.add("is-active"),c.setAttribute("aria-pressed","true"),d.classList.remove("is-active"),d.setAttribute("aria-pressed","false"),A())}),d.addEventListener("click",()=>{v!=="outline"&&(v="outline",d.classList.add("is-active"),d.setAttribute("aria-pressed","true"),c.classList.remove("is-active"),c.setAttribute("aria-pressed","false"),A())}),e.layout==="outline"&&(d.classList.add("is-active"),d.setAttribute("aria-pressed","true"),c.classList.remove("is-active"),c.setAttribute("aria-pressed","false"),v="outline"),A(),i}var Zc=0,Ln=Promise.resolve();function Qc(e){const t=Ln.then(e,e);return Ln=t.then(()=>{},()=>{}),t}var zt=null;async function Jc(){return zt||(zt=ni(()=>import("./assets/mermaid.core-ViSSZdte.js").then(e=>e.t).then(e=>e.default||e),__vite__mapDeps([2,3,4,5,6,7,8,9,10,11,12,13,14,15,1,16,17,18]))),zt}var ed='ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, "Google Sans", Inter, sans-serif',td={primaryColor:"#F8FAFC",primaryBorderColor:"#A1A1AA",primaryTextColor:"#18181B",secondaryColor:"#F1F5F9",secondaryBorderColor:"#94A3B8",secondaryTextColor:"#1E293B",tertiaryColor:"#F4F4F5",tertiaryBorderColor:"#A1A1AA",tertiaryTextColor:"#27272A",lineColor:"#71717A",defaultLinkColor:"#71717A",textColor:"#18181B",mainBkg:"#F8FAFC",nodeBorder:"#A1A1AA",clusterBkg:"#FFFFFF",clusterBorder:"#E4E4E7",edgeLabelBackground:"#FFFFFF",background:"transparent",noteBkgColor:"#FAFAFA",noteBorderColor:"#D4D4D8",actorBkg:"#F4F4F5",actorBorder:"#A1A1AA",signalColor:"#3F3F46",labelTextColor:"#27272A"},id={primaryColor:"#18181B",primaryBorderColor:"#52525B",primaryTextColor:"#FAFAFA",secondaryColor:"#202024",secondaryBorderColor:"#52525B",secondaryTextColor:"#F4F4F5",tertiaryColor:"#27272A",tertiaryBorderColor:"#52525B",tertiaryTextColor:"#E4E4E7",lineColor:"#A1A1AA",defaultLinkColor:"#A1A1AA",textColor:"#FAFAFA",mainBkg:"#18181B",nodeBorder:"#52525B",clusterBkg:"#101012",clusterBorder:"#3F3F46",edgeLabelBackground:"#09090B",background:"transparent",noteBkgColor:"#27272A",noteBorderColor:"#52525B",actorBkg:"#202024",actorBorder:"#52525B",signalColor:"#E4E4E7",labelTextColor:"#F4F4F5"};function _t(e){if(!(typeof document>"u"))try{document.querySelectorAll(`[id^="d${e}"], [id^="${e}"]`).forEach(t=>{t.closest(".iui-card")||t.remove()})}catch{}}var nd=.4,od=2.5,zn=.15;function rd(e,t){const i=u("div",{class:"iui-card iui-mermaid-card"});e.title&&i.appendChild(u("div",{class:"iui-title"},e.title));const n=u("div",{class:"iui-skel iui-skel-mermaid"});i.appendChild(n);const o=t.theme==="dark"?id:td,r="iui-mmd-"+ ++Zc;let a=!1,s=null;return t.onCleanup(()=>{a=!0,s?.(),_t(r)}),(async()=>{try{const l=await Jc();if(a)return;const c=await Qc(async()=>{if(a)return null;l.initialize({startOnLoad:!1,securityLevel:"strict",theme:"base",fontFamily:ed,themeVariables:o,suppressErrorRendering:!0,logLevel:"fatal"});const _=await l.render(r,e.code);return _t(r),_});if(!c||a)return;const d=new DOMParser().parseFromString(c.svg,"image/svg+xml"),p=d.querySelector("parsererror");if(p)throw new Error(p.textContent||"Failed to parse diagram SVG");const h=document.importNode(d.documentElement,!0);h.style.maxWidth="100%",h.style.height="auto",h.style.display="block",h.style.margin="0 auto";const f=u("div",{class:"iui-mermaid-diagram",role:"region","aria-label":e.title||"Mermaid diagram"}),g=u("div",{class:"flow-controls iui-diagram-controls",role:"group","aria-label":"Diagram zoom controls"}),b=u("button",{class:"flow-control-btn",type:"button","aria-label":"Zoom out",title:"Zoom out"},"\u2212"),m=u("span",{class:"flow-zoom-value","aria-live":"polite"},"100%"),C=u("button",{class:"flow-control-btn",type:"button","aria-label":"Zoom in",title:"Zoom in"},"+"),v=u("button",{class:"flow-fit-btn",type:"button","aria-label":"Fit diagram to view",title:"Fit to view"},"Fit"),w=u("button",{class:"flow-control-btn",type:"button","aria-label":"Reset zoom",title:"Reset view (or double-click)"},"\u21ba");g.append(b,m,C,v,w);const x=u("div",{class:"iui-mermaid-inner"},h),y=u("div",{class:"iui-mermaid-wrap"},x);f.append(g,y);let k=1,A=0,S=0;const E=_=>Math.min(od,Math.max(nd,+_.toFixed(2))),z=()=>{x.style.transform=`translate(${A}px, ${S}px) scale(${k})`,m.textContent=`${Math.round(k*100)}%`},L=()=>{k=1,A=0,S=0,z()},F=()=>{A=0,S=0;const _=y.clientWidth,I=h.getBoundingClientRect(),M=I.width>0?I.width/k:0;_>0&&M>0?k=E(Math.min(1,_/M)):k=1,z()};C.onclick=()=>{k=E(k+zn),z()},b.onclick=()=>{k=E(k-zn),z()},v.onclick=F,w.onclick=L;let B=!1,O=!1,D=0,P=0,R=0,Q=0;const ee=_=>{_.button===0&&(_.target?.closest(".iui-diagram-controls")||(B=!0,O=!1,D=_.clientX,P=_.clientY,R=A,Q=S))},X=_=>{if(!B)return;const I=_.clientX-D,M=_.clientY-P;!O&&Math.hypot(I,M)>4&&(O=!0,y.classList.add("is-panning")),O&&(A=R+I,S=Q+M,z())},j=()=>{B&&(B=!1,y.classList.remove("is-panning"))};y.addEventListener("pointerdown",ee),window.addEventListener("pointermove",X),window.addEventListener("pointerup",j),window.addEventListener("pointercancel",j),y.addEventListener("dblclick",_=>{_.target?.closest(".iui-diagram-controls")||L()});const $=_=>{if(!_.ctrlKey&&!_.metaKey)return;_.preventDefault();const I=_.deltaY<0?1.1:.9;k=E(k*I),z()};y.addEventListener("wheel",$,{passive:!1}),s=()=>{window.removeEventListener("pointermove",X),window.removeEventListener("pointerup",j),window.removeEventListener("pointercancel",j)},n.replaceWith(f)}catch(l){if(_t(r),a)return;const c=l instanceof Error?l.message:String(l),d=u("div",{class:"iui-fallback",style:"margin-top: 8px;"},u("div",{class:"iui-fallback-note"},`Diagram couldn't be drawn: ${c}`),u("pre",{class:"iui-fallback-pre"},e.code));n.replaceWith(d)}})(),i}function ad(e,t){const i=u("div",{class:"iui-card iui-callout-card"}),n=e.tone||"info";let o="c-sky",r=e.icon||"info";e.icon?n==="success"?o="c-mint":n==="warning"?o="c-butter":n==="tip"&&(o="c-lavender"):n==="success"?(o="c-mint",r="check-circle"):n==="warning"?(o="c-butter",r="warning-circle"):n==="tip"&&(o="c-lavender",r="sparkle");const a=u("div",{class:`iui-callout-box tinted ${o}`}),s=u("div",{class:"iui-callout-iconbox"},K(r,18));a.appendChild(s);const l=u("div",{class:"iui-callout-content"});if(e.title){const d=u("div",{class:"iui-callout-title"});xe(d,e.title),l.appendChild(d)}const c=u("div",{class:"iui-callout-text"});return xe(c,e.text),l.appendChild(c),a.appendChild(l),i.appendChild(a),i}function sd(e){if(typeof e=="number")return{prefix:"",value:e,suffix:"",decimals:e%1!==0&&String(e).split(".")[1]?.length||0};const t=String(e).trim(),i=/^([^\d\-+.]*)([+-]?\d+(?:\.\d+)?)([^\d.]*)$/.exec(t);if(!i)return null;const n=i[1],o=parseFloat(i[2]);return Number.isNaN(o)?null:{prefix:n,value:o,suffix:i[3],decimals:i[2].includes(".")?i[2].split(".")[1].length:0}}function ld(e){if(!e||e.length<2)return null;const t=64,i=20,n=1,o=Math.min(...e),r=Math.max(...e),a=r-o||1,s=b=>n+b/(e.length-1)*62,l=b=>19-(b-o)/a*18,c=e.map((b,m)=>`${s(m).toFixed(1)},${l(b).toFixed(1)}`).join(" "),d=e[e.length-1],p="http://www.w3.org/2000/svg",h=document.createElementNS(p,"svg");h.setAttribute("width",String(t)),h.setAttribute("height",String(i)),h.setAttribute("viewBox",`0 0 ${t} ${i}`),h.classList.add("iui-stat-sparkline"),h.setAttribute("aria-hidden","true"),h.setAttribute("title",`Min: ${o.toLocaleString()}, Max: ${r.toLocaleString()}, Last: ${d.toLocaleString()}`);const f=document.createElementNS(p,"polyline");f.setAttribute("points",c),f.setAttribute("fill","none"),f.setAttribute("stroke","var(--iui-accent, #0b57d0)"),f.setAttribute("stroke-width","1.5"),f.setAttribute("stroke-linecap","round"),f.setAttribute("stroke-linejoin","round"),h.appendChild(f);const g=document.createElementNS(p,"circle");return g.setAttribute("cx",String(s(e.length-1).toFixed(1))),g.setAttribute("cy",String(l(d).toFixed(1))),g.setAttribute("r","2"),g.setAttribute("fill","var(--iui-accent, #0b57d0)"),h.appendChild(g),h}function cd(e,t){const i=u("div",{class:"iui-card iui-stats-card"});e.title&&i.appendChild(u("div",{class:"iui-title"},e.title));const n=e.items||[],o=u("div",{class:"iui-stats-grid"}),r=typeof window<"u"&&window.matchMedia&&window.matchMedia("(prefers-reduced-motion: reduce)").matches;for(let a=0;a<n.length;a++){const s=n[a],l=u("div",{class:"iui-stat-item"}),c=u("div",{class:"iui-stat-label-row"}),d=u("div",{class:"iui-stat-label"});if(xe(d,s.label),c.appendChild(d),s.icon){const b=u("span",{class:"iui-stat-item-icon"},K(s.icon,18));c.appendChild(b)}l.appendChild(c);const p=u("div",{class:"iui-stat-val-row"}),h=u("div",{class:"iui-stat-value tabular-nums"},String(s.value));if(p.appendChild(h),s.delta){const b=s.delta.trim(),m=b.startsWith("+"),C=b.startsWith("-"),v=u("span",{class:`iui-stat-delta ${m?"c-mint":C?"c-rose":"c-stone"}`},b);p.appendChild(v)}if(l.appendChild(p),s.hint){const b=u("div",{class:"iui-stat-hint"},s.hint);l.appendChild(b)}const f=s.sparkline;if(Array.isArray(f)&&f.length>=2){const b=ld(f);if(b){const m=u("div",{class:"iui-stat-sparkline-wrap"});m.appendChild(b),l.appendChild(m)}}o.appendChild(l);const g=sd(s.value);if(g&&!r&&typeof requestAnimationFrame<"u"){const b=g.value,m=600;let C=null,v=null;h.textContent=`${g.prefix}0${g.suffix}`;const w=x=>{C||(C=x);const y=x-C,k=Math.min(y/m,1),A=1-Math.pow(1-k,3),S=b*A,E=g.decimals>0?S.toFixed(g.decimals):Math.round(S).toLocaleString();h.textContent=`${g.prefix}${E}${g.suffix}`,k<1?v=requestAnimationFrame(w):h.textContent=String(s.value)};v=requestAnimationFrame(w),t.onCleanup(()=>{v!==null&&cancelAnimationFrame(v)})}}return i.appendChild(o),i}function dd(e,t){const i=u("div",{class:"iui-card iui-tabs-card"});e.title&&i.appendChild(u("div",{class:"iui-title"},e.title));const n=e.tabs||[];let o=0;const r=u("div",{class:"iui-tabs-nav",role:"tablist"}),a=u("div",{class:"iui-tabs-indicator"});r.appendChild(a);const s=u("div",{class:"iui-tabs-panel",role:"tabpanel",tabindex:"0"}),l=[];function c(h){const f=r.getBoundingClientRect(),g=h.getBoundingClientRect();if(f.width===0){a.style.left=`${h.offsetLeft}px`,a.style.width=`${h.offsetWidth||80}px`;return}const b=g.left-f.left+r.scrollLeft,m=g.width;a.style.transform=`translateX(${b}px)`,a.style.width=`${m}px`}function d(){de(s);const h=n[o];if(h)if(Array.isArray(h.content)){const f=u("ul",{class:"iui-tabs-list"});for(const g of h.content){const b=u("li",{class:"iui-tabs-list-item"});xe(b,g),f.appendChild(b)}s.appendChild(f)}else{const f=u("div",{class:"iui-tabs-text"});xe(f,String(h.content||"")),s.appendChild(f)}}function p(h){h<0||h>=n.length||(o=h,l.forEach((f,g)=>{const b=g===o;f.setAttribute("aria-selected",String(b)),f.classList.toggle("is-active",b),b?(f.setAttribute("tabindex","0"),c(f)):f.setAttribute("tabindex","-1")}),d())}for(let h=0;h<n.length;h++){const f=n[h],g=h===0,b=u("button",{type:"button",class:`iui-tabs-btn${g?" is-active":""}`,role:"tab","aria-selected":String(g),tabindex:g?"0":"-1",onClick:()=>{p(h)},onKeydown:m=>{const C=m;if(C.key==="ArrowRight"){C.preventDefault();const v=(o+1)%n.length;p(v),l[v]?.focus()}else if(C.key==="ArrowLeft"){C.preventDefault();const v=(o-1+n.length)%n.length;p(v),l[v]?.focus()}}},f.label);l.push(b),r.appendChild(b)}if(i.appendChild(r),i.appendChild(s),d(),typeof requestAnimationFrame<"u"&&requestAnimationFrame(()=>{l[0]&&c(l[0])}),typeof ResizeObserver<"u"){const h=new ResizeObserver(()=>{l[o]&&c(l[o])});h.observe(r),t.onCleanup(()=>h.disconnect())}return i}function ud(e,t){const i=u("div",{class:"iui-card iui-timeline-card"});e.title&&i.appendChild(u("div",{class:"iui-title"},e.title));const n=e.events||[],o=n.length>6,r=n.map(b=>b.status).filter(Boolean),a=[...new Set(r)],s=a.length>0;let l=!1,c=null;const d=[];function p(){for(const{row:b,detail:m,expanded:C}of d)o&&(b.setAttribute("aria-expanded",String(C)),m.hidden=!C),b.hidden=c!==null&&b.dataset.status!==c}function h(b){for(const m of d)m.expanded=b;p()}function f(b,m){b.expanded=m,o&&(b.row.setAttribute("aria-expanded",String(m)),b.detail.hidden=!m)}if(o||s){const b=u("div",{class:"iui-timeline-toolbar"});if(o){const m=u("button",{type:"button",class:"iui-timeline-expand-btn","aria-pressed":"false",onClick:()=>{l=!l,m.textContent=l?"Collapse all":"Expand all",m.setAttribute("aria-pressed",String(l)),h(l)}},"Expand all");b.appendChild(m)}if(s){const m=u("div",{class:"iui-timeline-filter-pills"}),C=u("button",{type:"button",class:"iui-timeline-filter-pill is-active","aria-pressed":"true",onClick:()=>{c=null,m.querySelectorAll(".iui-timeline-filter-pill").forEach(v=>{v.classList.remove("is-active"),v.setAttribute("aria-pressed","false")}),C.classList.add("is-active"),C.setAttribute("aria-pressed","true"),p()}},"All");m.appendChild(C);for(const v of a){const w=u("button",{type:"button",class:"iui-timeline-filter-pill","aria-pressed":"false",onClick:()=>{c===v?(c=null,w.classList.remove("is-active"),w.setAttribute("aria-pressed","false"),C.classList.add("is-active"),C.setAttribute("aria-pressed","true")):(c=v,m.querySelectorAll(".iui-timeline-filter-pill").forEach(x=>{x.classList.remove("is-active"),x.setAttribute("aria-pressed","false")}),w.classList.add("is-active"),w.setAttribute("aria-pressed","true")),p()}},v.charAt(0).toUpperCase()+v.slice(1));m.appendChild(w)}b.appendChild(m)}i.appendChild(b)}const g=u("div",{class:"iui-timeline-list"});for(let b=0;b<n.length;b++){const m=n[b],C=b===n.length-1,v=m.status,w=v==="done"?"is-done":v==="active"?"is-active-ev":v==="upcoming"?"is-upcoming":"",x=u("div",{class:`iui-timeline-row${w?" "+w:""}${o?" is-collapsible":""}`,tabindex:o?"0":void 0,...v?{"data-status":v}:{}});let y;if(o){x.setAttribute("role","button"),x.setAttribute("aria-expanded","false");const B=()=>{y&&f(y,!y.expanded)};x.addEventListener("click",B),x.addEventListener("keydown",O=>{(O.key==="Enter"||O.key===" ")&&(O.preventDefault(),B())})}const k=u("div",{class:"iui-timeline-track"});let A="iui-timeline-dot";v==="done"?A+=" is-done c-mint":v==="active"?A+=" is-active-ev c-sky":v==="upcoming"?A+=" is-upcoming c-stone":A+=" c-butter";const S=u("div",{class:A});if(m.icon&&(S.classList.add("has-icon"),S.appendChild(K(m.icon,12))),k.appendChild(S),!C){const B=u("div",{class:"iui-timeline-line"});k.appendChild(B)}x.appendChild(k);const E=u("div",{class:`iui-timeline-content${C?" is-last":""}`});if(m.time){const B=u("div",{class:"iui-timeline-time"},m.time);E.appendChild(B)}const z=u("div",{class:"iui-timeline-title-row"}),L=u("div",{class:"iui-timeline-title"},m.title);if(z.appendChild(L),v){const B=u("span",{class:`iui-timeline-status-badge is-${v}`},v);z.appendChild(B)}E.appendChild(z);const F=u("div",{class:"iui-timeline-text",hidden:!!o},m.text);y={row:x,detail:F,expanded:!1},d.push(y),E.appendChild(F),x.appendChild(E),g.appendChild(x)}return i.appendChild(g),i}function pd(e){if(typeof document>"u")return!1;const t=document.querySelector('rich-textarea div[contenteditable="true"], .ql-editor[contenteditable="true"], div[contenteditable="true"][role="textbox"]');if(t){t.focus();try{const o=window.getSelection();if(o&&o.rangeCount>0){const r=o.getRangeAt(0);r.deleteContents();const a=document.createTextNode(e);r.insertNode(a),r.setStartAfter(a),r.setEndAfter(a),o.removeAllRanges(),o.addRange(r)}else t.textContent=e}catch{t.textContent=e}return t.dispatchEvent(new Event("input",{bubbles:!0})),!0}const i=document.querySelector('textarea[placeholder*="Ask" i], textarea[placeholder*="Grok" i], textarea');if(i){i.focus();const o=i.selectionStart??i.value.length,r=i.selectionEnd??i.value.length;return i.value=i.value.slice(0,o)+e+i.value.slice(r),i.selectionStart=i.selectionEnd=o+e.length,i.dispatchEvent(new Event("input",{bubbles:!0})),i.dispatchEvent(new Event("change",{bubbles:!0})),!0}const n=document.querySelector('div[contenteditable="true"]');return n?(n.focus(),n.textContent=e,n.dispatchEvent(new Event("input",{bubbles:!0})),!0):!1}function hd(e,t){const i=u("div",{class:"iui-card iui-followups-card"});e.title&&i.appendChild(u("div",{class:"iui-title"},e.title));const n=e.suggestions||[],o=u("div",{class:"iui-followups-container"});for(const r of n){const a=u("span",{class:"iui-followup-icon"},K("arrow-up-right",18)),s=u("span",{class:"iui-followup-text"},r),l=u("button",{type:"button",class:"iui-btn secondary iui-followup-chip c-lavender",onClick:()=>{pd(r),l.classList.add("is-clicked"),setTimeout(()=>{l.classList.remove("is-clicked")},1200)}},a,s);o.appendChild(l)}return i.appendChild(o),i}function fd(e,t){const i=u("div",{class:"iui-card iui-math-card"});e.title&&i.appendChild(u("div",{class:"iui-title"},e.title));const n=u("div",{class:"iui-math-main",role:"region","aria-label":e.title||"Mathematical formula"});if(n.textContent=e.latex,Ht(n,e.latex,!0),i.appendChild(n),e.steps&&e.steps.length>0){const o=u("div",{class:"iui-math-steps"}),r=u("div",{class:"iui-math-steps-title"},"Derivation Steps");o.appendChild(r);for(let a=0;a<e.steps.length;a++){const s=e.steps[a],l=u("div",{class:"iui-math-step"}),c=u("div",{class:"iui-math-step-num"},String(a+1));l.appendChild(c);const d=u("div",{class:"iui-math-step-body"}),p=u("div",{class:"iui-math-step-formula"});if(p.textContent=s.latex,Ht(p,s.latex,!0),d.appendChild(p),s.note){const h=u("div",{class:"iui-math-step-note"});xe(h,s.note),d.appendChild(h)}l.appendChild(d),o.appendChild(l)}i.appendChild(o)}return i}function qo(e){if(!e)return"text";const t=e.trim().toLowerCase();return["js","jsx","javascript","mjs","cjs"].includes(t)?"js":["ts","tsx","typescript","mts","cts"].includes(t)?"ts":["py","python","py3"].includes(t)?"python":["json","jsonc"].includes(t)?"json":["sh","bash","shell","zsh"].includes(t)?"bash":["html","htm","xml","svg"].includes(t)?"html":["css","scss","less"].includes(t)?"css":t}function gd(e){switch(e){case"js":case"ts":return[{type:"comment",regex:/\/\/[^\n]*|\/\*[\s\S]*?\*\//y},{type:"string",regex:/"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`/y},{type:"boolean",regex:/\b(true|false|null|undefined|NaN|Infinity)\b/y},{type:"keyword",regex:/\b(abstract|as|async|await|break|case|catch|class|const|continue|debugger|declare|default|delete|do|else|enum|export|extends|finally|for|from|function|get|if|implements|import|in|instanceof|interface|let|new|of|package|private|protected|public|readonly|return|set|static|super|switch|this|throw|try|type|typeof|var|void|while|with|yield)\b/y},{type:"function",regex:/\b[a-zA-Z_$][a-zA-Z0-9_$]*(?=\s*\()/y},{type:"number",regex:/\b0x[0-9a-fA-F]+\b|\b0b[01]+\b|\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b/y},{type:"operator",regex:/===|!==|==|!=|<=|>=|=>|\+\+|--|\+=|-=|\*=|\/=|&&|\|\||[+\-*\/%&|^~!=<>?:.]/y},{type:"punctuation",regex:/[{}()\[\],;]/y}];case"python":return[{type:"comment",regex:/#[^\n]*/y},{type:"string",regex:/"""[\s\S]*?"""|'''[\s\S]*?'''|[bB]?[rR]?"(?:\\.|[^"\\])*"|[bB]?[rR]?'(?:\\.|[^'\\])*'/y},{type:"boolean",regex:/\b(True|False|None)\b/y},{type:"keyword",regex:/\b(and|as|assert|async|await|break|class|continue|def|del|elif|else|except|finally|for|from|global|if|import|in|is|lambda|nonlocal|not|or|pass|raise|return|try|while|with|yield)\b/y},{type:"function",regex:/\b[a-zA-Z_][a-zA-Z0-9_]*(?=\s*\()/y},{type:"number",regex:/\b0x[0-9a-fA-F]+\b|\b\d+(?:\.\d+)?\b/y},{type:"operator",regex:/==|!=|<=|>=|\+=|-=|\*=|\/=|\/\/=|%=|\/\//y},{type:"punctuation",regex:/[{}()\[\],;]/y}];case"json":return[{type:"property",regex:/"(?:\\.|[^"\\])*"(?=\s*:)/y},{type:"string",regex:/"(?:\\.|[^"\\])*"/y},{type:"boolean",regex:/\b(true|false|null)\b/y},{type:"number",regex:/-?\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b/y},{type:"punctuation",regex:/[{}()\[\],:]/y}];case"bash":return[{type:"comment",regex:/#[^\n]*/y},{type:"string",regex:/"(?:\\.|[^"\\])*"|'[^']*'/y},{type:"variable",regex:/\$(?:\{[a-zA-Z_0-9#?*!-]+\}|[a-zA-Z_0-9#?*!-]+)/y},{type:"keyword",regex:/\b(if|then|else|elif|fi|for|while|until|do|done|in|case|esac|function|select|time|return|exit|export|source|local|echo|cd|pwd|cat|grep|sed|awk|chmod|chown|sudo)\b/y},{type:"operator",regex:/\|\||&&|>>|<<|==|!=|[|><;&=]/y},{type:"number",regex:/\b\d+\b/y},{type:"punctuation",regex:/[{}()\[\],]/y}];case"html":return[{type:"comment",regex:/<!--[\s\S]*?-->/y},{type:"tag",regex:/<\/?[a-zA-Z0-9-]+/y},{type:"attr-value",regex:/"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/y},{type:"attr-name",regex:/\b[a-zA-Z0-9-]+(?=\s*=)/y},{type:"punctuation",regex:/[<>/=]/y}];case"css":return[{type:"comment",regex:/\/\*[\s\S]*?\*\//y},{type:"string",regex:/"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'/y},{type:"property",regex:/\b[a-zA-Z-]+(?=\s*:)/y},{type:"number",regex:/#[0-9a-fA-F]{3,8}\b|\b\d+(?:\.\d+)?(px|em|rem|%|vh|vw|deg|s|ms|fr)?\b/y},{type:"tag",regex:/\.[a-zA-Z0-9_-]+|#[a-zA-Z0-9_-]+|:[a-zA-Z-]+/y},{type:"punctuation",regex:/[{}():;,]/y}];default:return[]}}function md(e,t){if(!e)return[];const i=gd(qo(t)),n=[];let o=0;const r=e.length;for(;o<r;){let s=!1;for(const l of i){l.regex.lastIndex=o;const c=l.regex.exec(e);if(c&&c.index===o){n.push({type:l.type,value:c[0]}),o+=c[0].length,s=!0;break}}if(!s){let l=o+1;n.push({type:"plain",value:e[o]}),o=l}}const a=[];for(const s of n)a.length>0&&a[a.length-1].type==="plain"&&s.type==="plain"?a[a.length-1].value+=s.value:a.push({...s});return a}function bd(e){const t=[[]];for(const i of e)if(!i.value.includes(`
`))t[t.length-1].push(i);else{const n=i.value.split(`
`);for(let o=0;o<n.length;o++)o>0&&t.push([]),n[o]&&t[t.length-1].push({type:i.type,value:n[o]})}return t}function xd(e,t){return bd(md(e,t))}function vd(e,t){const i=u("div",{class:"iui-card iui-code-card"});e.title&&i.appendChild(u("div",{class:"iui-title"},e.title));const n=e.code??"",o=e.language||"text",r=qo(o),a=u("div",{class:"iui-code-inner-header"}),s=u("div",{class:"iui-code-meta-left"}),l=u("span",{class:"iui-code-lang-pill"},r.toUpperCase());if(s.appendChild(l),e.filename){const C=u("span",{class:"iui-code-filename",title:e.filename},e.filename);s.appendChild(C)}a.appendChild(s);const c=u("div",{class:"iui-code-controls"});let d=!1;const p=u("button",{class:"iui-code-btn",type:"button",title:"Toggle word wrap","aria-label":"Toggle word wrap","aria-pressed":"false",onClick:()=>{d=!d,p.setAttribute("aria-pressed",String(d)),d?(p.classList.add("is-active"),m.classList.add("is-wrapped")):(p.classList.remove("is-active"),m.classList.remove("is-wrapped"))}},"Wrap");c.appendChild(p);let h=null;const f=u("button",{class:"iui-code-btn",type:"button",title:"Copy code","aria-label":"Copy code",onClick:async()=>{try{await navigator.clipboard.writeText(n),de(f),f.classList.add("is-copied"),f.appendChild(K("check",13)),f.appendChild(document.createTextNode(" Copied")),h!==null&&window.clearTimeout(h),h=window.setTimeout(()=>{de(f),f.classList.remove("is-copied"),f.appendChild(K("copy",13)),f.appendChild(document.createTextNode(" Copy")),h=null},1500)}catch{}}},K("copy",13),document.createTextNode(" Copy"));c.appendChild(f),a.appendChild(c),i.appendChild(a);const g=xd(n,r),b=u("div",{class:"iui-code-wrap"}),m=u("pre",{class:"iui-code-pre"});for(let C=0;C<g.length;C++){const v=g[C],w=u("div",{class:"iui-code-line"}),x=u("span",{class:"iui-code-line-num","aria-hidden":"true"},String(C+1));w.appendChild(x);const y=u("span",{class:"iui-code-line-content"});if(v.length===0)y.appendChild(document.createTextNode(" "));else for(const k of v)k.type==="plain"?y.appendChild(document.createTextNode(k.value)):y.appendChild(u("span",{class:`token token-${k.type}`},k.value));w.appendChild(y),m.appendChild(w)}return b.appendChild(m),i.appendChild(b),i}function lt(e){return e.replace(/([a-z])([A-Z])/g,"$1 $2").replace(/[_-]+/g," ").replace(/\b\w/g,t=>t.toUpperCase()).trim()}function Kt(e){if(e==null)return u("span",{class:"iui-generic-value"},"-");if(typeof e=="boolean")return u("span",{class:"iui-generic-chip"},e?"Yes":"No");if(typeof e=="number")return u("span",{class:"iui-generic-value"},String(e));if(typeof e=="string")return u("span",{class:"iui-generic-value"},e);if(Array.isArray(e)){if(e.length===0)return u("span",{class:"iui-generic-value"},"(empty)");if(e.every(i=>typeof i=="string"||typeof i=="number"||typeof i=="boolean")){if(e.every(n=>String(n).length<=25)&&e.length<=15){const n=u("div",{class:"iui-generic-chips"});for(const o of e)n.appendChild(u("span",{class:"iui-generic-chip"},String(o)));return n}const i=u("ul",{class:"iui-generic-list"});for(const n of e)i.appendChild(u("li",{},String(n)));return i}const t=u("div",{style:"display: flex; flex-direction: column; gap: 8px; margin-top: 4px;"});for(const i of e)if(i&&typeof i=="object"){const n=u("div",{class:"iui-generic-subcard"});for(const[o,r]of Object.entries(i)){const a=u("div",{style:"display: flex; flex-direction: column; gap: 2px;"});a.appendChild(u("span",{class:"iui-generic-label"},lt(o))),a.appendChild(Kt(r)),n.appendChild(a)}t.appendChild(n)}else t.appendChild(u("span",{class:"iui-generic-value"},String(i)));return t}if(typeof e=="object"){const t=u("div",{class:"iui-generic-subcard"});for(const[i,n]of Object.entries(e)){const o=u("div",{style:"display: flex; flex-direction: column; gap: 2px;"});o.appendChild(u("span",{class:"iui-generic-label"},lt(i))),o.appendChild(Kt(n)),t.appendChild(o)}return t}return u("span",{class:"iui-generic-value"},String(e))}function wd(e,t){const i=u("div",{class:"iui-card iui-generic-card"}),n=e.title||(e.originalType?lt(e.originalType):"Details");i.appendChild(u("div",{class:"iui-title"},n));const o=u("div",{class:"iui-generic-content"}),r=u("div",{class:"iui-generic-grid"}),a=Object.entries(e.data||{}).filter(([s])=>s!=="type"&&s!=="title"&&!s.startsWith("_"));for(const[s,l]of a){const c=typeof l=="object"&&l!==null,d=typeof l=="string"&&l.length>60,p=u("div",{class:`iui-generic-row${c||d?" full-width":""}`});p.appendChild(u("span",{class:"iui-generic-label"},lt(s))),p.appendChild(Kt(l)),r.appendChild(p)}return o.appendChild(r),i.appendChild(o),i}function yd(e,t){const i=u("section",{class:"iui-card iui-checklist-card","aria-label":e.title||"Checklist"}),n=e.items.map(h=>({...h,checked:h.checked===!0})),o=u("div",{class:"iui-checklist-header"}),r=u("div",{class:"iui-checklist-heading"},e.title?u("div",{class:"iui-title iui-checklist-title"},e.title):null,u("div",{class:"iui-checklist-count","aria-live":"polite"})),a=u("button",{type:"button",class:"iui-btn secondary iui-checklist-bulk","aria-label":"Mark all checklist items complete"},"Mark all");o.append(r,a);const s=u("div",{class:"iui-checklist-progress-track",role:"progressbar","aria-label":"Checklist progress","aria-valuemin":"0","aria-valuemax":String(n.length),"aria-valuenow":"0"}),l=u("div",{class:"iui-checklist-progress-fill"});s.appendChild(l);const c=u("div",{class:"iui-checklist-items",role:"group","aria-label":"Checklist items"}),d=[];function p(){const h=n.filter(b=>b.checked).length,f=Math.round(h/n.length*100),g=r.querySelector(".iui-checklist-count");g.textContent=`${h} of ${n.length} completed \u00b7 ${f}%`,s.setAttribute("aria-valuenow",String(h)),l.style.width=`${f}%`,i.classList.toggle("is-complete",h===n.length),a.textContent=h===n.length?"Clear all":"Mark all",a.setAttribute("aria-label",h===n.length?"Clear all checklist items":"Mark all checklist items complete");for(const{input:b,row:m,item:C}of d)b.checked=C.checked,m.classList.toggle("is-checked",C.checked)}return n.forEach((h,f)=>{const g=u("input",{type:"checkbox",class:"iui-checklist-input","aria-label":h.text});g.checked=h.checked;const b=u("span",{class:"iui-checklist-copy"},u("span",{class:"iui-checklist-text"},h.text),h.detail?u("span",{class:"iui-checklist-detail"},h.detail):null),m=u("label",{class:"iui-checklist-row",style:`--checklist-index:${f}`},u("span",{class:"iui-checklist-box"},K("check",13)),g,b);g.addEventListener("change",()=>{h.checked=g.checked,p()}),d.push({input:g,row:m,item:h}),c.appendChild(m)}),a.addEventListener("click",()=>{const h=n.some(f=>!f.checked);n.forEach(f=>{f.checked=h}),p()}),i.append(o,s,c),p(),i}function kd(e,t){const i=u("div",{class:`iui-form-field iui-form-field-${e.type}`}),n=`iui-form-${t}-${e.id}`,o=u("label",{class:"iui-form-label",for:n},e.label,e.required?u("span",{class:"iui-form-required","aria-label":"required"}," *"):null),r={id:n,name:e.id,class:"iui-form-control",...e.required?{required:!0}:{},...e.placeholder?{placeholder:e.placeholder}:{},...e.min!==void 0?{min:e.min}:{},...e.max!==void 0?{max:e.max}:{},...e.step!==void 0?{step:e.step}:{}};let a;if(e.type==="textarea")a=u("textarea",{...r,rows:3}),typeof e.value=="string"&&(a.value=e.value);else if(e.type==="select"){const s=u("select",r);s.appendChild(u("option",{value:""},e.placeholder||"Choose an option"));for(const l of e.options||[])s.appendChild(u("option",{value:l},l));typeof e.value=="string"&&(s.value=e.value),a=s}else if(e.type==="radio"){const s=u("div",{class:"iui-form-radio-group",role:"radiogroup","aria-label":e.label});(e.options||[]).forEach((l,c)=>{const d=`${n}-${c}`,p=u("input",{type:"radio",id:d,name:e.id,value:l,required:e.required===!0,...e.value===l?{checked:!0}:{}});s.appendChild(u("label",{class:"iui-form-choice",for:d},p,u("span",{},l)))}),a=u("div",{class:"iui-form-radio-wrap"},o,s)}else if(e.type==="checkbox"){const s=u("input",{type:"checkbox",id:n,name:e.id,value:"true",...e.required?{required:!0}:{},...e.value===!0?{checked:!0}:{}});a=u("label",{class:"iui-form-choice iui-form-single-choice",for:n},s,u("span",{},e.label,e.required?u("span",{class:"iui-form-required","aria-label":"required"}," *"):null))}else{const s=e.type==="range"?"range":e.type,l=u("input",{...r,type:s});if(e.value!==void 0&&(l.value=String(e.value)),e.type==="range"){const c=u("output",{class:"iui-form-range-value",for:n},l.value||"0");l.addEventListener("input",()=>{c.textContent=l.value}),a=u("div",{class:"iui-form-range-wrap"},l,c)}else a=l}return e.type!=="radio"&&e.type!=="checkbox"&&i.appendChild(o),i.appendChild(a),e.help&&i.appendChild(u("div",{class:"iui-form-help"},e.help)),i}function Cd(e,t){const i=u("section",{class:"iui-card iui-form-card"});e.title&&i.appendChild(u("div",{class:"iui-title iui-form-title"},e.title)),e.description&&i.appendChild(u("p",{class:"iui-form-description"},e.description));const n=u("form",{class:"iui-form",novalidate:!1});e.fields.forEach((l,c)=>n.appendChild(kd(l,c)));const o=u("div",{class:"iui-form-actions"}),r=u("button",{type:"submit",class:"iui-btn primary iui-form-submit"},e.submitLabel||"Submit"),a=u("button",{type:"reset",class:"iui-btn secondary iui-form-reset"},"Reset");o.append(r,a),n.appendChild(o);const s=u("section",{class:"iui-form-result",hidden:!0,"aria-live":"polite"});return n.addEventListener("submit",l=>{if(l.preventDefault(),!n.reportValidity())return;const c=new FormData(n),d=e.fields.map(f=>({label:f.label,value:f.type==="checkbox"?c.has(f.id)?"Yes":"No":c.get(f.id)?.toString()||"\u2014"})),p=d.map(f=>`${f.label}: ${f.value}`).join(`
`);s.replaceChildren(u("div",{class:"iui-form-result-heading"},K("check-circle",18),u("strong",{},"Response ready")),u("dl",{class:"iui-form-result-list"},...d.flatMap(f=>[u("dt",{},f.label),u("dd",{},f.value)])));const h=u("button",{type:"button",class:"iui-btn secondary iui-form-copy",onClick:()=>{const f=navigator.clipboard;f?.writeText?f.writeText(p).then(()=>{h.textContent="Copied"}).catch(()=>{h.textContent="Select and copy the answers above"}):h.textContent="Clipboard unavailable"}},K("copy",14),"Copy answers");s.appendChild(h),s.hidden=!1,s.scrollIntoView?.({behavior:"smooth",block:"nearest"})}),n.addEventListener("reset",()=>{s.hidden=!0}),i.append(n,s),i}function Ed(e,t){const i=u("div",{class:"iui-card iui-image-card"});e.title&&i.appendChild(u("div",{class:"iui-title"},e.title));const n=u("figure",{class:`iui-image-figure aspect-${e.aspect||"auto"}`}),o=u("img",{class:"iui-image",src:e.src,alt:e.alt,loading:"lazy",decoding:"async",referrerpolicy:"no-referrer"});return o.style.objectFit=e.fit||"contain",n.appendChild(o),e.caption&&n.appendChild(u("figcaption",{class:"iui-image-caption"},e.caption)),i.appendChild(n),i}function Sd(e,t,i){const n=u("div",{class:"iui-card iui-dashboard-card"});e.title&&n.appendChild(u("div",{class:"iui-title"},e.title));const o=u("div",{class:"iui-dashboard-grid",role:"group","aria-label":e.title||"Dashboard"});return e.items.forEach((r,a)=>{const s=r.title||r.visual.title||`${r.visual.type[0].toUpperCase()}${r.visual.type.slice(1)} ${a+1}`,l=u("section",{class:"iui-dashboard-panel","aria-label":s});l.appendChild(u("div",{class:"iui-dashboard-panel-title",role:"heading","aria-level":"4"},s));const c=i(r.visual,t);c.classList.add("iui-dashboard-visual"),c.querySelector(".iui-title")?.remove(),l.appendChild(c),o.appendChild(l)}),n.appendChild(o),n}var Xt={flow:Wc,tree:Xc,stepper:gs,table:lo,compare:hs,quiz:ms,chart:ao,mermaid:rd,callout:ad,stats:cd,tabs:dd,timeline:ud,followups:hd,math:fd,code:vd,checklist:yd,form:Cd,image:Ed,dashboard:(e,t)=>Sd(e,t,(i,n)=>{const o=Xt[i.type];return o(i,n)}),generic:wd},Ad=':host{all:initial;box-sizing:border-box;width:100%;min-width:0;max-width:100%;margin:12px 0;scroll-margin-bottom:140px;display:block}:host(:last-child),:host(:last-of-type){margin-bottom:24px}.iui-root{box-sizing:border-box;font-family:var(--iui-font,Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif);font-size:var(--iui-fs,14px);line-height:var(--iui-lh,1.5);color:var(--iui-text);text-transform:none;background:0 0;scroll-margin-bottom:140px}.iui-root *,.iui-root :before,.iui-root :after{box-sizing:border-box}.iui-root[data-theme=light],.iui-root:not([data-theme=dark]){--iui-bg:#fff;--iui-surface:#fafafa;--iui-surface-2:#f4f4f5;--iui-border:#0000001f;--iui-text:#0a0a0a;--iui-muted:#6b6b6b;--iui-subtle:#a3a3a3;--iui-accent:#0a0a0a;--iui-accent-bg:#f4f4f5;--iui-success:#16a34a;--iui-success-bg:#16a34a1f;--iui-danger:#dc2626;--iui-danger-bg:#dc26261a;--iui-warning:#d97706;--iui-info:#2563eb;--iui-radius-card:12px;--iui-radius-inner:8px;--iui-radius-pill:999px;--iui-ease:cubic-bezier(.2,.8,.2,1);--iui-dur-fast:.12s;--iui-dur-med:.2s;--iui-shadow-float:0 8px 24px #0000001f;--iui-font:Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;--iui-mono:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace}.iui-root[data-theme=dark]{--iui-bg:#0f0f10;--iui-surface:#18181a;--iui-surface-2:#222225;--iui-border:#ffffff1f;--iui-text:#fafafa;--iui-muted:#a3a3a3;--iui-subtle:#71717a;--iui-accent:#fafafa;--iui-accent-bg:#27272a;--iui-success:#34d399;--iui-success-bg:#34d39929;--iui-danger:#f87171;--iui-danger-bg:#f8717129;--iui-warning:#fbbf24;--iui-info:#60a5fa;--iui-radius-card:12px;--iui-radius-inner:8px;--iui-radius-pill:999px;--iui-ease:cubic-bezier(.2,.8,.2,1);--iui-dur-fast:.12s;--iui-dur-med:.2s;--iui-shadow-float:0 8px 28px #00000073;--iui-font:Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;--iui-mono:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace}.iui-root[data-host=gemini][data-theme=light],.iui-root[data-host=gemini]:not([data-theme=dark]){--iui-bg:#fff;--iui-surface:#f0f4f9;--iui-surface-2:#e9eef6;--iui-border:#e1e3e1;--iui-text:#1f1f1f;--iui-muted:#444746;--iui-subtle:#747775;--iui-accent:#0b57d0;--iui-accent-bg:#d3e3fd;--iui-radius-card:12px;--iui-radius-inner:8px;--iui-font:"Google Sans Text", "Google Sans", Roboto, Arial, sans-serif;--iui-mono:"Google Sans Mono", "Roboto Mono", ui-monospace, monospace}.iui-root[data-host=gemini][data-theme=dark]{--iui-bg:#131314;--iui-surface:#1e1f20;--iui-surface-2:#282a2c;--iui-border:#3c4043;--iui-text:#e3e3e3;--iui-muted:#c4c7c5;--iui-subtle:#8e918f;--iui-accent:#a8c7fa;--iui-accent-bg:#0842a066;--iui-radius-card:12px;--iui-radius-inner:8px;--iui-font:"Google Sans Text", "Google Sans", Roboto, Arial, sans-serif;--iui-mono:"Google Sans Mono", "Roboto Mono", ui-monospace, monospace}.iui-root[data-host=grok][data-theme=light],.iui-root[data-host=grok]:not([data-theme=dark]){--iui-bg:#fff;--iui-surface:#fafafa;--iui-surface-2:#f2f2f2;--iui-border:#0000001f;--iui-text:#0d0d0d;--iui-muted:#6b6b6b;--iui-subtle:#9a9a9a;--iui-accent:#0d0d0d;--iui-accent-bg:#f2f2f2;--iui-radius-card:12px;--iui-radius-inner:8px;--iui-font:ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;--iui-mono:ui-monospace, "SF Mono", Menlo, Consolas, monospace}.iui-root[data-host=grok][data-theme=dark]{--iui-bg:#141414;--iui-surface:#1c1c1c;--iui-surface-2:#242424;--iui-border:#ffffff1f;--iui-text:#f5f5f5;--iui-muted:#a3a3a3;--iui-subtle:#737373;--iui-accent:#f5f5f5;--iui-accent-bg:#262626;--iui-radius-card:12px;--iui-radius-inner:8px;--iui-font:ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;--iui-mono:ui-monospace, "SF Mono", Menlo, Consolas, monospace}.iui-root[data-host=chatgpt][data-theme=light],.iui-root[data-host=chatgpt]:not([data-theme=dark]){--iui-bg:#fff;--iui-surface:#f9f9fb;--iui-surface-2:#f1f2f6;--iui-border:#0f172a1a;--iui-text:#0d0d0d;--iui-muted:#5d6370;--iui-subtle:#8e95a2;--iui-accent:#10a37f;--iui-accent-bg:#10a37f1f;--iui-success:#16a34a;--iui-success-bg:#16a34a1f;--iui-danger:#dc2626;--iui-danger-bg:#dc26261a;--iui-warning:#d97706;--iui-info:#2563eb;--iui-radius-card:12px;--iui-radius-inner:8px;--iui-font:-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;--iui-mono:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace}.iui-root[data-host=chatgpt][data-theme=dark]{--iui-bg:#212121;--iui-surface:#2f2f2f;--iui-surface-2:#383838;--iui-border:#ffffff1f;--iui-text:#ececec;--iui-muted:#b4b4b4;--iui-subtle:#8e8e8e;--iui-accent:#10a37f;--iui-accent-bg:#10a37f33;--iui-success:#34d399;--iui-success-bg:#34d39929;--iui-danger:#f87171;--iui-danger-bg:#f8717129;--iui-warning:#fbbf24;--iui-info:#60a5fa;--iui-radius-card:12px;--iui-radius-inner:8px;--iui-font:-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;--iui-mono:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace}.iui-root[data-host=claude][data-theme=light],.iui-root[data-host=claude]:not([data-theme=dark]){--iui-bg:#faf9f5;--iui-surface:#f0eee6;--iui-surface-2:#e6e3d8;--iui-border:#3d392924;--iui-text:#141413;--iui-muted:#5e5d59;--iui-subtle:#87867f;--iui-accent:#d97757;--iui-accent-bg:#d9775724;--iui-success:#16a34a;--iui-success-bg:#16a34a1f;--iui-danger:#dc2626;--iui-danger-bg:#dc26261a;--iui-warning:#d97706;--iui-info:#2563eb;--iui-radius-card:12px;--iui-radius-inner:8px;--iui-font:Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;--iui-mono:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace}.iui-root[data-host=claude][data-theme=dark]{--iui-bg:#262624;--iui-surface:#30302e;--iui-surface-2:#3a3a37;--iui-border:#fffaeb1f;--iui-text:#faf9f5;--iui-muted:#c2c0b6;--iui-subtle:#8c8a80;--iui-accent:#d97757;--iui-accent-bg:#d9775738;--iui-success:#34d399;--iui-success-bg:#34d39929;--iui-danger:#f87171;--iui-danger-bg:#f8717129;--iui-warning:#fbbf24;--iui-info:#60a5fa;--iui-radius-card:12px;--iui-radius-inner:8px;--iui-font:Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;--iui-mono:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace}.iui-root[data-theme=light] .c-blue,.iui-root[data-theme=light] .c-sky,.iui-root:not([data-theme=dark]) .c-blue,.iui-root:not([data-theme=dark]) .c-sky{--c-bg:#eaf4fd;--c-line:#cfe5f8;--c-ink:#1f5f8f;--c-solid:#a9d3f5}.iui-root[data-theme=light] .c-green,.iui-root[data-theme=light] .c-teal,.iui-root[data-theme=light] .c-mint,.iui-root[data-theme=light] .c-good,.iui-root:not([data-theme=dark]) .c-green,.iui-root:not([data-theme=dark]) .c-teal,.iui-root:not([data-theme=dark]) .c-mint,.iui-root:not([data-theme=dark]) .c-good{--c-bg:#e9f7f0;--c-line:#cbebda;--c-ink:#1e6b48;--c-solid:#a6dec0}.iui-root[data-theme=light] .c-amber,.iui-root[data-theme=light] .c-butter,.iui-root[data-theme=light] .c-warning,.iui-root:not([data-theme=dark]) .c-amber,.iui-root:not([data-theme=dark]) .c-butter,.iui-root:not([data-theme=dark]) .c-warning{--c-bg:#fdf7e1;--c-line:#f3e4a8;--c-ink:#7a5e10;--c-solid:#f2dc8a}.iui-root[data-theme=light] .c-orange,.iui-root[data-theme=light] .c-peach,.iui-root:not([data-theme=dark]) .c-orange,.iui-root:not([data-theme=dark]) .c-peach{--c-bg:#fdefe6;--c-line:#f7d4be;--c-ink:#8c4a20;--c-solid:#f6c0a0}.iui-root[data-theme=light] .c-red,.iui-root[data-theme=light] .c-pink,.iui-root[data-theme=light] .c-rose,.iui-root[data-theme=light] .c-bad,.iui-root:not([data-theme=dark]) .c-red,.iui-root:not([data-theme=dark]) .c-pink,.iui-root:not([data-theme=dark]) .c-rose,.iui-root:not([data-theme=dark]) .c-bad{--c-bg:#fcecef;--c-line:#f5cdd6;--c-ink:#8e2e46;--c-solid:#f2b1c0}.iui-root[data-theme=light] .c-purple,.iui-root[data-theme=light] .c-lavender,.iui-root:not([data-theme=dark]) .c-purple,.iui-root:not([data-theme=dark]) .c-lavender{--c-bg:#f1edfc;--c-line:#dcd3f6;--c-ink:#4c3d91;--c-solid:#c6b9f2}.iui-root[data-theme=light] .c-gray,.iui-root[data-theme=light] .c-stone,.iui-root[data-theme=light] .c-neutral,.iui-root:not([data-theme=dark]) .c-gray,.iui-root:not([data-theme=dark]) .c-stone,.iui-root:not([data-theme=dark]) .c-neutral{--c-bg:#f5f5f4;--c-line:#e4e4e2;--c-ink:#4a4a47;--c-solid:#d6d6d3}.iui-root[data-theme=dark] .c-blue,.iui-root[data-theme=dark] .c-sky{--c-bg:#16212b;--c-line:#263a4c;--c-ink:#a9d3f5;--c-solid:#6fa8d6}.iui-root[data-theme=dark] .c-green,.iui-root[data-theme=dark] .c-teal,.iui-root[data-theme=dark] .c-mint,.iui-root[data-theme=dark] .c-good{--c-bg:#15241d;--c-line:#254134;--c-ink:#a6dec0;--c-solid:#6dbf95}.iui-root[data-theme=dark] .c-amber,.iui-root[data-theme=dark] .c-butter,.iui-root[data-theme=dark] .c-warning{--c-bg:#26231a;--c-line:#463f27;--c-ink:#f2dc8a;--c-solid:#cdb45a}.iui-root[data-theme=dark] .c-orange,.iui-root[data-theme=dark] .c-peach{--c-bg:#281e18;--c-line:#4a3528;--c-ink:#f6c0a0;--c-solid:#d9946c}.iui-root[data-theme=dark] .c-red,.iui-root[data-theme=dark] .c-pink,.iui-root[data-theme=dark] .c-rose,.iui-root[data-theme=dark] .c-bad{--c-bg:#29191d;--c-line:#4a2c34;--c-ink:#f2b1c0;--c-solid:#d47f95}.iui-root[data-theme=dark] .c-purple,.iui-root[data-theme=dark] .c-lavender{--c-bg:#1e1b29;--c-line:#383150;--c-ink:#c6b9f2;--c-solid:#9585d6}.iui-root[data-theme=dark] .c-gray,.iui-root[data-theme=dark] .c-stone,.iui-root[data-theme=dark] .c-neutral{--c-bg:#1c1c1c;--c-line:#333;--c-ink:#d6d6d3;--c-solid:#8f8f8b}.iui-root[data-host=gemini][data-theme=light] .c-blue,.iui-root[data-host=gemini][data-theme=light] .c-sky,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-blue,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-sky{--c-bg:#d3e3fd;--c-line:#b4c8f5;--c-ink:#041e49;--c-solid:#a8c7fa}.iui-root[data-host=gemini][data-theme=light] .c-green,.iui-root[data-host=gemini][data-theme=light] .c-teal,.iui-root[data-host=gemini][data-theme=light] .c-mint,.iui-root[data-host=gemini][data-theme=light] .c-good,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-green,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-teal,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-mint,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-good{--c-bg:#c4eed0;--c-line:#a3e0b5;--c-ink:#072711;--c-solid:#6dd58c}.iui-root[data-host=gemini][data-theme=light] .c-amber,.iui-root[data-host=gemini][data-theme=light] .c-butter,.iui-root[data-host=gemini][data-theme=light] .c-warning,.iui-root[data-host=gemini][data-theme=light] .c-orange,.iui-root[data-host=gemini][data-theme=light] .c-peach,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-amber,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-butter,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-warning,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-orange,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-peach{--c-bg:#ffe08266;--c-line:#ffe082;--c-ink:#3f2e00;--c-solid:#ffe082}.iui-root[data-host=gemini][data-theme=light] .c-red,.iui-root[data-host=gemini][data-theme=light] .c-pink,.iui-root[data-host=gemini][data-theme=light] .c-rose,.iui-root[data-host=gemini][data-theme=light] .c-bad,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-red,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-pink,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-rose,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-bad{--c-bg:#f9dedc;--c-line:#f2b8b5;--c-ink:#410e0b;--c-solid:#e46962}.iui-root[data-host=gemini][data-theme=light] .c-purple,.iui-root[data-host=gemini][data-theme=light] .c-lavender,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-purple,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-lavender{--c-bg:#e8def8;--c-line:#d0bcff;--c-ink:#21005d;--c-solid:#d0bcff}.iui-root[data-host=gemini][data-theme=light] .c-gray,.iui-root[data-host=gemini][data-theme=light] .c-stone,.iui-root[data-host=gemini][data-theme=light] .c-neutral,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-gray,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-stone,.iui-root[data-host=gemini]:not([data-theme=dark]) .c-neutral{--c-bg:#e9eef6;--c-line:#e1e3e1;--c-ink:#1f1f1f;--c-solid:#c4c7c5}.iui-root[data-host=gemini][data-theme=dark] .c-blue,.iui-root[data-host=gemini][data-theme=dark] .c-sky{--c-bg:#0842a0;--c-line:#0b57d0;--c-ink:#d3e3fd;--c-solid:#a8c7fa}.iui-root[data-host=gemini][data-theme=dark] .c-green,.iui-root[data-host=gemini][data-theme=dark] .c-teal,.iui-root[data-host=gemini][data-theme=dark] .c-mint,.iui-root[data-host=gemini][data-theme=dark] .c-good{--c-bg:#0f5223;--c-line:#137333;--c-ink:#c4eed0;--c-solid:#81c995}.iui-root[data-host=gemini][data-theme=dark] .c-amber,.iui-root[data-host=gemini][data-theme=dark] .c-butter,.iui-root[data-host=gemini][data-theme=dark] .c-warning,.iui-root[data-host=gemini][data-theme=dark] .c-orange,.iui-root[data-host=gemini][data-theme=dark] .c-peach{--c-bg:#ffe08226;--c-line:#544000;--c-ink:#ffe082;--c-solid:#fdd663}.iui-root[data-host=gemini][data-theme=dark] .c-red,.iui-root[data-host=gemini][data-theme=dark] .c-pink,.iui-root[data-host=gemini][data-theme=dark] .c-rose,.iui-root[data-host=gemini][data-theme=dark] .c-bad{--c-bg:#8c1d18;--c-line:#b3261e;--c-ink:#f9dedc;--c-solid:#f28b82}.iui-root[data-host=gemini][data-theme=dark] .c-purple,.iui-root[data-host=gemini][data-theme=dark] .c-lavender{--c-bg:#4a4458;--c-line:#605d62;--c-ink:#e8def8;--c-solid:#ccc2dc}.iui-root[data-host=gemini][data-theme=dark] .c-gray,.iui-root[data-host=gemini][data-theme=dark] .c-stone,.iui-root[data-host=gemini][data-theme=dark] .c-neutral{--c-bg:#282a2c;--c-line:#3c4043;--c-ink:#e3e3e3;--c-solid:#8e918f}.iui-root[data-host=grok][data-theme=light] .c-blue,.iui-root[data-host=grok][data-theme=light] .c-sky,.iui-root[data-host=grok]:not([data-theme=dark]) .c-blue,.iui-root[data-host=grok]:not([data-theme=dark]) .c-sky{--c-bg:#0000000d;--c-line:#0000001a;--c-ink:#0d0d0d;--c-solid:#0000001f}.iui-root[data-host=grok][data-theme=light] .c-green,.iui-root[data-host=grok][data-theme=light] .c-teal,.iui-root[data-host=grok][data-theme=light] .c-mint,.iui-root[data-host=grok][data-theme=light] .c-good,.iui-root[data-host=grok]:not([data-theme=dark]) .c-green,.iui-root[data-host=grok]:not([data-theme=dark]) .c-teal,.iui-root[data-host=grok]:not([data-theme=dark]) .c-mint,.iui-root[data-host=grok]:not([data-theme=dark]) .c-good{--c-bg:#10b98114;--c-line:#10b98129;--c-ink:#0d0d0d;--c-solid:#10b98133}.iui-root[data-host=grok][data-theme=light] .c-amber,.iui-root[data-host=grok][data-theme=light] .c-butter,.iui-root[data-host=grok][data-theme=light] .c-warning,.iui-root[data-host=grok][data-theme=light] .c-orange,.iui-root[data-host=grok][data-theme=light] .c-peach,.iui-root[data-host=grok]:not([data-theme=dark]) .c-amber,.iui-root[data-host=grok]:not([data-theme=dark]) .c-butter,.iui-root[data-host=grok]:not([data-theme=dark]) .c-warning,.iui-root[data-host=grok]:not([data-theme=dark]) .c-orange,.iui-root[data-host=grok]:not([data-theme=dark]) .c-peach{--c-bg:#f59e0b14;--c-line:#f59e0b29;--c-ink:#0d0d0d;--c-solid:#f59e0b33}.iui-root[data-host=grok][data-theme=light] .c-red,.iui-root[data-host=grok][data-theme=light] .c-pink,.iui-root[data-host=grok][data-theme=light] .c-rose,.iui-root[data-host=grok][data-theme=light] .c-bad,.iui-root[data-host=grok]:not([data-theme=dark]) .c-red,.iui-root[data-host=grok]:not([data-theme=dark]) .c-pink,.iui-root[data-host=grok]:not([data-theme=dark]) .c-rose,.iui-root[data-host=grok]:not([data-theme=dark]) .c-bad{--c-bg:#ef444414;--c-line:#ef444429;--c-ink:#0d0d0d;--c-solid:#ef444433}.iui-root[data-host=grok][data-theme=light] .c-purple,.iui-root[data-host=grok][data-theme=light] .c-lavender,.iui-root[data-host=grok]:not([data-theme=dark]) .c-purple,.iui-root[data-host=grok]:not([data-theme=dark]) .c-lavender{--c-bg:#8b5cf614;--c-line:#8b5cf629;--c-ink:#0d0d0d;--c-solid:#8b5cf633}.iui-root[data-host=grok][data-theme=light] .c-gray,.iui-root[data-host=grok][data-theme=light] .c-stone,.iui-root[data-host=grok][data-theme=light] .c-neutral,.iui-root[data-host=grok]:not([data-theme=dark]) .c-gray,.iui-root[data-host=grok]:not([data-theme=dark]) .c-stone,.iui-root[data-host=grok]:not([data-theme=dark]) .c-neutral{--c-bg:#0000000a;--c-line:#00000014;--c-ink:#0d0d0d;--c-solid:#0000001a}.iui-root[data-host=grok][data-theme=dark] .c-blue,.iui-root[data-host=grok][data-theme=dark] .c-sky{--c-bg:#ffffff0f;--c-line:#ffffff1a;--c-ink:#f5f5f5;--c-solid:#ffffff26}.iui-root[data-host=grok][data-theme=dark] .c-green,.iui-root[data-host=grok][data-theme=dark] .c-teal,.iui-root[data-host=grok][data-theme=dark] .c-mint,.iui-root[data-host=grok][data-theme=dark] .c-good{--c-bg:#10b9811a;--c-line:#10b98133;--c-ink:#f5f5f5;--c-solid:#10b98140}.iui-root[data-host=grok][data-theme=dark] .c-amber,.iui-root[data-host=grok][data-theme=dark] .c-butter,.iui-root[data-host=grok][data-theme=dark] .c-warning,.iui-root[data-host=grok][data-theme=dark] .c-orange,.iui-root[data-host=grok][data-theme=dark] .c-peach{--c-bg:#f59e0b1a;--c-line:#f59e0b33;--c-ink:#f5f5f5;--c-solid:#f59e0b40}.iui-root[data-host=grok][data-theme=dark] .c-red,.iui-root[data-host=grok][data-theme=dark] .c-pink,.iui-root[data-host=grok][data-theme=dark] .c-rose,.iui-root[data-host=grok][data-theme=dark] .c-bad{--c-bg:#ef44441a;--c-line:#ef444433;--c-ink:#f5f5f5;--c-solid:#ef444440}.iui-root[data-host=grok][data-theme=dark] .c-purple,.iui-root[data-host=grok][data-theme=dark] .c-lavender{--c-bg:#8b5cf61a;--c-line:#8b5cf633;--c-ink:#f5f5f5;--c-solid:#8b5cf640}.iui-root[data-host=grok][data-theme=dark] .c-gray,.iui-root[data-host=grok][data-theme=dark] .c-stone,.iui-root[data-host=grok][data-theme=dark] .c-neutral{--c-bg:#ffffff0a;--c-line:#ffffff14;--c-ink:#f5f5f5;--c-solid:#ffffff1f}.iui-card{background:var(--iui-surface,transparent);border:1px solid color-mix(in srgb, var(--iui-text,#000) 12%, transparent);box-sizing:border-box;border-radius:12px;flex-direction:column;gap:8px;max-width:100%;margin:0;padding:12px 14px;scroll-margin-bottom:140px;display:flex;overflow:visible;box-shadow:none!important}.iui-card[data-animate=enter]{animation:.2s cubic-bezier(.2,.8,.2,1) forwards iui-card-rise}.iui-card-body{min-height:0;max-height:480px;overflow-y:auto}.iui-card.tinted{background-color:var(--c-bg,var(--iui-surface));border-color:var(--c-line,var(--iui-border));color:var(--c-ink,var(--iui-text))}@keyframes iui-card-rise{0%{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}.iui-card-header{justify-content:space-between;align-items:center;gap:8px;min-height:28px;display:flex;position:relative;overflow:visible}.iui-header-left{flex:1;align-items:center;gap:8px;min-width:0;display:flex}.iui-type-iconbox{flex-shrink:0;justify-content:center;align-items:center;display:inline-flex;width:16px!important;height:16px!important;box-shadow:none!important;color:var(--iui-muted)!important;background:0 0!important;border:none!important;border-radius:0!important;padding:0!important}.iui-type-iconbox svg{stroke-width:1.8px;display:block;width:16px!important;height:16px!important;stroke:var(--iui-muted)!important}.iui-title-group{flex-direction:column;justify-content:center;min-width:0;display:flex}.iui-title{font-family:var(--iui-font,inherit);color:var(--iui-text);letter-spacing:-.018em;margin:0;font-size:15.5px;font-weight:600;line-height:1.35}.iui-root[data-host=gemini] .iui-title{font-family:"Google Sans", var(--iui-font,inherit);font-size:16px;font-weight:600}.iui-root[data-host=grok] .iui-title{font-size:15px;font-weight:600}@keyframes iui-title-wipe{0%{clip-path:inset(0 100% 0 0)}to{clip-path:inset(0)}}.iui-sub{color:var(--iui-muted);font-size:12px;font-weight:400;line-height:1.35}.iui-card .iui-title+.iui-chart-plot,.iui-card .iui-title+.iui-mermaid-wrap{margin-top:2px}.iui-root[data-host=gemini] .iui-card,.iui-root[data-host=gemini] .iui-stat-item,.iui-root[data-host=gemini] .iui-compare-panel,.iui-root[data-host=gemini] .flow-node,.iui-root[data-host=gemini] .flow-edge-label,.iui-root[data-host=gemini] .iui-followup-chip,.iui-root[data-host=gemini] .iui-math-main,.iui-root[data-host=grok] .iui-card,.iui-root[data-host=grok] .iui-stat-item,.iui-root[data-host=grok] .iui-compare-panel,.iui-root[data-host=grok] .flow-node,.iui-root[data-host=grok] .flow-edge-label,.iui-root[data-host=grok] .iui-followup-chip,.iui-root[data-host=grok] .iui-math-main{box-shadow:none!important}.tabular-nums{font-variant-numeric:tabular-nums}.iui-card-toolbar{opacity:.55;pointer-events:auto;flex-shrink:0;align-items:center;gap:2px;transition:opacity .12s;display:flex;position:relative;overflow:visible}.iui-card:hover .iui-card-toolbar,.iui-card:focus-within .iui-card-toolbar,.iui-card-toolbar.is-open{opacity:1;pointer-events:auto}@media (hover:none){.iui-card-toolbar{opacity:1;pointer-events:auto}}.iui-tool-btn{width:28px;height:28px;color:var(--iui-muted);cursor:pointer;box-sizing:border-box;background:0 0;border:none;border-radius:8px;justify-content:center;align-items:center;transition:background-color .12s,color .12s;display:inline-flex;position:relative}.iui-tool-btn svg{width:16px;height:16px}.iui-tool-btn:hover{background-color:color-mix(in srgb, var(--iui-text) 8%, transparent);color:var(--iui-text)}.iui-tool-btn:focus-visible{background-color:color-mix(in srgb, var(--iui-text) 8%, transparent);color:var(--iui-text)}.iui-tool-btn:focus-visible{outline:2px solid var(--iui-text);outline-offset:1px}.iui-root[data-host=gemini] .iui-card-toolbar{gap:4px}.iui-root[data-host=gemini] .iui-tool-btn{border-radius:999px;width:32px;height:32px}.iui-root[data-host=gemini] .iui-tool-btn svg{width:18px;height:18px}.iui-root[data-host=grok] .iui-card-toolbar{gap:2px}.iui-root[data-host=grok] .iui-tool-btn{border-radius:8px;width:28px;height:28px}.iui-root[data-host=grok] .iui-tool-btn svg{width:16px;height:16px}.iui-tooltip{background-color:var(--iui-text);color:var(--iui-bg);white-space:nowrap;pointer-events:none;opacity:0;z-index:1000;border-radius:6px;max-width:min(220px,100vw - 24px);padding:4px 7px;font-family:inherit;font-size:11.5px;font-weight:500;line-height:1;transition:opacity .12s;position:absolute;top:calc(100% + 6px);bottom:auto;left:50%;transform:translate(-50%);box-shadow:0 2px 6px #0000001f}.iui-card-toolbar>.iui-tool-btn:first-child .iui-tooltip{left:0;transform:none}.iui-card-toolbar>.iui-tool-btn:last-child .iui-tooltip{left:auto;right:0;transform:none}.iui-export-wrap .iui-tooltip{left:50%;transform:translate(-50%)}.iui-tool-btn:hover .iui-tooltip{opacity:1;transition-delay:.3s}.iui-tool-btn:focus-visible .iui-tooltip{opacity:1;transition-delay:.3s}.iui-export-wrap{display:inline-flex;position:relative}.iui-export-menu{z-index:1000;background-color:var(--iui-bg);border:1px solid var(--iui-border);border-radius:8px;flex-direction:column;gap:2px;min-width:150px;padding:4px;animation:.12s cubic-bezier(.2,.8,.2,1) iui-menu-in;display:flex;position:absolute;top:calc(100% + 4px);right:0;box-shadow:0 4px 16px #0000001f}.iui-export-menu.is-hidden{display:none}@keyframes iui-menu-in{0%{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)}}.iui-export-item{all:unset;color:var(--iui-text);cursor:pointer;box-sizing:border-box;border-radius:6px;align-items:center;gap:8px;width:100%;padding:6px 10px;font-size:12px;font-weight:500;transition:background-color .12s cubic-bezier(.2,.8,.2,1);display:flex}.iui-export-item:hover{background-color:var(--iui-surface)}.iui-export-item:focus-visible{background-color:var(--iui-surface)}.iui-export-item-icon{color:var(--iui-muted);flex-shrink:0}.iui-toast{background-color:var(--iui-text);color:var(--iui-bg);pointer-events:none;z-index:200;border-radius:999px;padding:6px 14px;font-size:12px;font-weight:600;transition:opacity .2s,transform .2s;animation:.16s cubic-bezier(.2,.8,.2,1) iui-toast-pop;position:absolute;bottom:14px;left:50%;transform:translate(-50%);box-shadow:0 4px 12px #0000002e}.iui-toast.is-hiding{opacity:0;transform:translate(-50%,4px)}@keyframes iui-toast-pop{0%{opacity:0;transform:translate(-50%,6px)scale(.95)}to{opacity:1;transform:translate(-50%)scale(1)}}.iui-modal-overlay{z-index:99999;box-sizing:border-box;justify-content:center;align-items:center;padding:24px;animation:.2s cubic-bezier(.2,.8,.2,1) forwards iui-modal-in;display:flex;position:fixed;top:0;bottom:0;left:0;right:0}@keyframes iui-modal-in{0%{opacity:0}to{opacity:1}}.iui-modal-overlay.is-closing{animation:.15s cubic-bezier(.4,0,1,1) forwards iui-modal-out}@keyframes iui-modal-out{0%{opacity:1}to{opacity:0}}.iui-modal-backdrop{-webkit-backdrop-filter:blur(2px);backdrop-filter:blur(2px);background-color:#00000080;position:absolute;top:0;bottom:0;left:0;right:0}.iui-root[data-theme=dark] .iui-modal-backdrop{background-color:#000000bf}.iui-modal-container{z-index:1;background-color:var(--iui-bg);border:1px solid var(--iui-border);box-sizing:border-box;border-radius:18px;flex-direction:column;gap:16px;width:100%;max-width:960px;max-height:90vh;padding:24px;animation:.22s cubic-bezier(.2,.8,.2,1) forwards iui-modal-container-rise;display:flex;position:relative;overflow-y:auto;box-shadow:0 16px 40px #0003}@keyframes iui-modal-container-rise{0%{opacity:0;transform:translateY(8px)scale(.98)}to{opacity:1;transform:translateY(0)scale(1)}}.iui-modal-esc-hint{color:var(--iui-muted);opacity:.7;-webkit-user-select:none;user-select:none;margin-left:auto;font-size:11px}.iui-modal-header{justify-content:space-between;align-items:center;gap:12px;display:flex}.iui-modal-close{all:unset;background-color:var(--iui-surface);border:1px solid var(--iui-border);width:28px;height:28px;color:var(--iui-text);cursor:pointer;border-radius:999px;justify-content:center;align-items:center;display:inline-flex}.iui-modal-close:hover{background-color:var(--iui-border)}.iui-modal-close:focus-visible{outline:2px solid var(--iui-accent,var(--iui-text));outline-offset:2px}.iui-chip{background-color:var(--c-bg,var(--iui-surface));border:1px solid var(--c-line,var(--iui-border));color:var(--c-ink,var(--iui-text));border-radius:999px;align-items:center;padding:2px 10px;font-size:12px;font-weight:500;display:inline-flex}.iui-btn{background-color:var(--iui-text);color:var(--iui-bg);border:1px solid var(--iui-text);cursor:pointer;-webkit-user-select:none;user-select:none;border-radius:999px;padding:9px 18px;font-size:13px;font-weight:600;transition:opacity .16s cubic-bezier(.2,.8,.2,1)}.iui-btn:hover{opacity:.85}.iui-btn.secondary{border:1px solid var(--iui-border);color:var(--iui-text);background-color:#0000;border-radius:999px}.iui-btn.secondary:hover{background-color:var(--iui-surface)}.iui-btn:disabled{opacity:.5;cursor:not-allowed}:focus-visible{outline:2px solid var(--iui-text);outline-offset:2px}@keyframes iui-shimmer{0%{background-position:-200% 0}to{background-position:200% 0}}.iui-root[data-theme=light] .iui-skel,.iui-root:not([data-theme=dark]) .iui-skel{border:1px solid var(--iui-border);background:linear-gradient(90deg,#f0f0f0 0% 35%,#f8f8f8 50%,#f0f0f0 65% 100%) 0 0/200% 100%;border-radius:12px;animation:1.4s cubic-bezier(.2,.8,.2,1) infinite iui-shimmer}.iui-root[data-theme=dark] .iui-skel{border:1px solid var(--iui-border);background:linear-gradient(90deg,#1c1c1c 0% 35%,#262626 50%,#1c1c1c 65% 100%) 0 0/200% 100%;border-radius:12px;animation:1.4s cubic-bezier(.2,.8,.2,1) infinite iui-shimmer}.iui-skel-line{width:100%;height:18px;margin-bottom:8px}.iui-skel-line:last-child{margin-bottom:0}.iui-skel-flow-wrap{flex-direction:column;justify-content:center;align-items:center;gap:8px;min-height:220px;padding:12px 0;display:flex}.iui-skel-flow-pill{border-radius:12px;height:44px}.iui-skel-flow-line{background-color:var(--iui-border);width:1px;height:18px}.iui-skel-table-wrap{flex-direction:column;gap:10px;min-height:180px;display:flex}.iui-skel-table-header{width:100%;height:28px}.iui-skel-table-row{height:20px}.iui-skel-stepper-wrap{flex-direction:column;gap:12px;min-height:200px;display:flex}.iui-skel-stepper-row{align-items:center;gap:12px;display:flex}.iui-skel-stepper-circle{border-radius:999px;flex-shrink:0;width:28px;height:28px}.iui-skel-stepper-bar{flex:1;height:20px}.iui-skel-compare-wrap{grid-template-columns:1fr 1fr;gap:12px;min-height:180px;display:grid}.iui-skel-compare-col{border:1px solid var(--iui-border);background-color:var(--iui-surface);border-radius:12px;flex-direction:column;gap:10px;padding:12px;display:flex}.iui-skel-quiz-wrap{flex-direction:column;gap:10px;min-height:200px;display:flex}.iui-skel-quiz-q{width:85%;height:24px}.iui-skel-quiz-opt{border-radius:999px;height:36px}.iui-skel-chart-wrap{border-bottom:2px solid var(--iui-border);border-left:2px solid var(--iui-border);box-sizing:border-box;align-items:flex-end;gap:16px;min-height:240px;padding:16px 24px;display:flex}.iui-skel-chart-bar{border-radius:4px 4px 0 0;flex:1}.iui-skel-mermaid-wrap{box-sizing:border-box;justify-content:center;align-items:center;gap:16px;min-height:200px;padding:24px;display:flex}.iui-skel-mermaid-box{border-radius:10px;width:100px;height:60px}.iui-skel-mermaid-arrow{background-color:var(--iui-border);width:32px;height:2px}.iui-fallback{background:0 0;padding:6px 0}.iui-fallback-collapsed{flex-direction:column;align-items:flex-start;gap:8px;display:flex}.iui-fallback-note{color:var(--iui-muted);margin-bottom:8px;font-size:12.5px}.iui-show-source-btn{border:1px solid var(--iui-border);background-color:var(--iui-surface);color:var(--iui-muted);cursor:pointer;-webkit-user-select:none;user-select:none;border-radius:6px;align-items:center;gap:6px;padding:5px 12px;font-family:inherit;font-size:12px;font-weight:500;transition:background-color .14s;display:inline-flex}.iui-show-source-btn:hover{background-color:var(--iui-surface-2);color:var(--iui-text)}.iui-show-source-btn:focus-visible{outline:2px solid var(--iui-accent,var(--iui-text));outline-offset:2px}.iui-fallback pre,.iui-fallback-pre{background-color:var(--iui-surface);border:1px solid var(--iui-border);white-space:pre-wrap;word-break:break-all;color:var(--iui-text);border-radius:12px;max-height:200px;margin:0;padding:8px;font-family:ui-monospace,SF Mono,Consolas,monospace;font-size:12px;overflow:auto}.iui-partial-error-note{color:var(--iui-muted);background-color:var(--iui-surface);border-radius:8px;align-items:center;gap:6px;margin-top:4px;padding:6px 10px;font-size:12px;display:inline-flex}.iui-partial-source-link{all:unset;cursor:pointer;color:var(--iui-text);text-decoration:underline}.iui-source-panel{opacity:1;max-height:400px;transition:max-height .24s cubic-bezier(.2,.8,.2,1),opacity .24s cubic-bezier(.2,.8,.2,1);overflow:hidden}.iui-source-panel.is-collapsed{opacity:0;pointer-events:none;max-height:0;margin:0}.iui-source-pre{background-color:var(--iui-surface);border:1px solid var(--iui-border);color:var(--iui-text);white-space:pre-wrap;word-break:break-all;border-radius:12px;margin:0;padding:10px;font-family:ui-monospace,SF Mono,Consolas,monospace;font-size:12px;overflow-x:auto}.iui-source-toggle{display:none}.iui-rendered-wrap{flex-direction:column;width:100%;display:flex}:host{box-sizing:border-box;width:100%;min-width:0;max-width:100%;margin:4px 0}.iui-root{overflow-wrap:anywhere;width:100%;min-width:0;max-width:100%;container:iui/inline-size}.iui-root[data-theme=dark]{--lightningcss-light: ;--lightningcss-dark:initial;color-scheme:dark}.iui-root:not([data-theme=dark]){--lightningcss-light:initial;--lightningcss-dark: ;color-scheme:light}.iui-root .iui-rendered-wrap,.iui-root .iui-card{width:100%;min-width:0;max-width:100%}.iui-root[data-host=gemini] .iui-card.iui-chart-card:not(.iui-dashboard-visual),.iui-root[data-host=grok] .iui-card.iui-chart-card:not(.iui-dashboard-visual),.iui-root[data-host=gemini] .iui-card.iui-dashboard-card,.iui-root[data-host=grok] .iui-card.iui-dashboard-card{padding:12px 14px}.iui-root[data-host=gemini] .iui-chart-plot,.iui-root[data-host=grok] .iui-chart-plot{padding:6px 6px 4px}.iui-root .iui-card-header{border-bottom:0;gap:8px;min-height:24px;padding-bottom:0}.iui-root .iui-type-iconbox{width:18px;height:18px;color:var(--iui-muted);background:0 0;border:0;border-radius:0;flex:0 0 18px}.iui-root[data-host=gemini] .iui-type-iconbox,.iui-root[data-host=grok] .iui-type-iconbox{width:18px;height:18px;color:var(--iui-muted);background:0 0;border:0;flex-basis:18px}.iui-root[data-host=gemini] .iui-type-iconbox{border-radius:0}.iui-root[data-host=grok] .iui-type-iconbox{border-radius:8px}.iui-root .iui-card-header .iui-type-iconbox{display:none!important}.iui-root .iui-card-header .iui-header-left{gap:0}.iui-root .iui-title,.iui-root .iui-sub{overflow-wrap:anywhere;min-width:0}.iui-root :focus-visible{outline-color:var(--iui-accent)}@container iui (width<=520px){.iui-root .iui-card{padding:10px 12px}.iui-root .iui-card-header{align-items:flex-start;gap:8px}.iui-root .iui-card-toolbar{opacity:1;pointer-events:auto}.iui-root .iui-modal-overlay{padding:12px}.iui-root .iui-modal-container{border-radius:14px;max-height:calc(100vh - 24px);padding:16px}.iui-root .iui-skel-compare-wrap{grid-template-columns:minmax(0,1fr)}}.iui-sr-only{clip:rect(0, 0, 0, 0);white-space:nowrap;border-width:0;width:1px;height:1px;margin:-1px;padding:0;position:absolute;overflow:hidden}@media (prefers-reduced-motion:reduce){.iui-card,.iui-title,.iui-skel,.iui-modal-overlay,.iui-modal-backdrop,.iui-modal-container,.iui-source-panel,.iui-card-toolbar,.iui-tool-btn,.iui-btn,.iui-toast,.iui-export-menu,.iui-export-item,.iui-tooltip,.iui-tabs-btn,.iui-tab-btn,.iui-quiz-opt-row,.iui-quiz-nav-btn,.flow-controls,.flow-control-btn,.iui-tree-card *,.iui-timeline-card *,.iui-compare-card *,.iui-table-card *,.iui-stepper-card *,.iui-chart-card *{clip-path:none!important;transition:none!important;animation:none!important;transform:none!important}}',Md=".iui-table-wrap{box-shadow:none;background:0 0;border:none;border-radius:0;overflow:hidden}.iui-table-actions{justify-content:space-between;align-items:center;gap:10px;margin-bottom:8px;display:flex}.iui-table-copy-btn{border:1px solid color-mix(in srgb, var(--iui-text,#000) 12%, transparent);min-height:26px;color:var(--iui-muted);font:inherit;cursor:pointer;background:0 0;border-radius:6px;justify-content:center;align-items:center;gap:6px;padding:4px 8px;font-size:11.5px;font-weight:500;transition:background-color .1s,color .1s;display:inline-flex}.iui-table-copy-btn:hover{background:color-mix(in srgb, var(--iui-text,#000) 6%, transparent);color:var(--iui-text)}.iui-table-copy-btn:focus-visible{outline:2px solid var(--iui-accent);outline-offset:1px}.iui-table-copy-fallback{position:fixed;top:0;left:-9999px}.iui-table-filter-bar{justify-content:space-between;align-items:center;gap:10px;margin-bottom:0;display:flex}.iui-table-filter-wrap{border:1px solid color-mix(in srgb, var(--iui-text,#000) 12%, transparent);background-color:#0000;border-radius:6px;flex:1;align-items:center;gap:6px;max-width:220px;padding:4px 8px;transition:border-color .12s;display:flex}.iui-table-filter-wrap:focus-within{border-color:var(--iui-accent)}.iui-table-filter-icon{color:var(--iui-muted);flex-shrink:0}.iui-table-filter-input{all:unset;color:var(--iui-text);width:100%;font-size:11.5px}.iui-table-filter-input::placeholder{color:var(--iui-muted)}.iui-table-filter-count{color:var(--iui-muted);white-space:nowrap;font-variant-numeric:tabular-nums;font-size:11px}.iui-table-scroll{border:none;overflow-x:auto}.iui-table{border-collapse:collapse;text-align:left;border:none;width:100%}.iui-table-header{z-index:2;background-color:var(--iui-surface,var(--iui-bg));position:sticky;top:0}.iui-table-header-tr{border-bottom:1px solid color-mix(in srgb, var(--iui-text,#000) 12%, transparent)}.iui-table-th{color:var(--iui-text);-webkit-user-select:none;user-select:none;text-align:left;background-color:#0000;border:none;padding:0;font-size:13px;font-weight:600}.iui-table-th.is-numeric{text-align:right;font-variant-numeric:tabular-nums}.iui-table-th-btn{all:unset;box-sizing:border-box;text-transform:none;width:100%;color:var(--iui-text);cursor:pointer;align-items:center;gap:4px;padding:8px 10px;font-family:inherit;font-size:13px;font-weight:600;display:flex}.iui-table-th.is-numeric .iui-table-th-btn{justify-content:flex-end}.iui-table-th-btn:focus-visible{outline:2px solid var(--iui-accent);outline-offset:-1px}.iui-table-sort-arrow{color:var(--iui-muted);align-items:center;font-size:12px;line-height:1;display:inline-flex}.iui-table-tbody{border:none}.iui-table-tr{border-bottom:1px solid color-mix(in srgb, var(--iui-text,#000) 8%, transparent);transition:background-color .1s}.iui-table-tr:last-child{border-bottom:none}.iui-table-tr:hover{background-color:color-mix(in srgb, var(--iui-text,#000) 3%, transparent)}.iui-table-td{color:var(--iui-text);white-space:normal;word-break:break-word;text-align:left;border:none;padding:8px 10px;font-size:13px;line-height:1.45}.iui-table-td.is-numeric{text-align:right;font-variant-numeric:tabular-nums}.iui-table-empty-td{text-align:center;color:var(--iui-muted);border:none;padding:20px;font-size:12.5px}.iui-table-highlight-pill{background-color:color-mix(in srgb, var(--iui-success,#10b981) 12%, transparent);color:var(--iui-text);border-radius:4px;align-items:center;padding:1px 6px;font-size:12px;font-weight:500;display:inline-flex}.iui-table-actions-right{align-items:center;gap:8px;margin-left:auto;display:flex}.iui-table-view-switch{background-color:var(--iui-surface);border:1px solid color-mix(in srgb, var(--iui-text,#000) 12%, transparent);border-radius:7px;align-items:center;gap:2px;padding:2px;display:inline-flex}.iui-table-view-btn{all:unset;color:var(--iui-muted);cursor:pointer;white-space:nowrap;border-radius:5px;padding:3px 10px;font-size:11.5px;font-weight:500;transition:color .14s,background-color .14s}.iui-table-view-btn:hover{color:var(--iui-text)}.iui-table-view-btn.is-active{background-color:var(--iui-bg);color:var(--iui-text);border:1px solid color-mix(in srgb, var(--iui-text,#000) 12%, transparent);font-weight:600}.iui-table-view-btn:focus-visible{outline:2px solid var(--iui-accent);outline-offset:1px}.iui-table-chart-view,.iui-table-cards-view{margin-top:4px}.iui-table-cards-grid{grid-template-columns:repeat(auto-fill,minmax(min(100%,180px),1fr));gap:8px;display:grid}.iui-table-kv-card{border:1px solid color-mix(in srgb, var(--iui-text,#000) 10%, transparent);border-radius:var(--iui-radius-card,12px);background:var(--iui-surface);flex-direction:column;gap:6px;padding:10px 12px;display:flex}.iui-table-kv-head{color:var(--iui-text);font-size:13px;font-weight:600;line-height:1.4}.iui-table-kv-body{flex-direction:column;gap:4px;display:flex}.iui-table-kv-row{justify-content:space-between;gap:8px;font-size:12px;line-height:1.4;display:flex}.iui-table-kv-key{color:var(--iui-muted);flex-shrink:0}.iui-table-kv-val{color:var(--iui-text);text-align:right}.iui-table-kv-val.is-numeric{font-variant-numeric:tabular-nums}.iui-table-cards-empty{color:var(--iui-muted);text-align:center;padding:16px 0;font-size:13px}.iui-table-cell-bar{background-color:color-mix(in srgb, var(--iui-accent,#0b57d0) 8%, transparent);pointer-events:none;z-index:0;display:block;position:absolute;top:0;bottom:0;left:0}.iui-table-cell-val{z-index:1;position:relative}.iui-table-tfoot{border-top:1px solid color-mix(in srgb, var(--iui-text,#000) 15%, transparent)}.iui-table-summary-tr{background:color-mix(in srgb, var(--iui-text,#000) 2%, transparent)}.iui-table-summary-td{color:var(--iui-muted);border:none;padding:6px 10px;font-size:11.5px}.iui-table-summary-td.is-numeric{text-align:right;font-variant-numeric:tabular-nums;flex-direction:column;gap:1px;display:flex}.iui-table-summary-td.is-label{color:var(--iui-text);font-weight:600}.iui-table-summary-sum{color:var(--iui-text);font-weight:600;display:block}.iui-table-summary-avg{font-size:11px;display:block}",Td=".iui-compare-card{border-radius:var(--iui-radius-card,12px)}.iui-compare-filter-wrap{border:1px solid color-mix(in srgb, var(--iui-text,#000) 12%, transparent);background-color:#0000;border-radius:6px;align-items:center;gap:6px;max-width:240px;margin-bottom:10px;padding:4px 8px;transition:border-color .12s;display:flex}.iui-compare-filter-wrap:focus-within{border-color:var(--iui-accent)}.iui-compare-filter-icon{color:var(--iui-muted);flex-shrink:0}.iui-compare-filter-input{all:unset;color:var(--iui-text);width:100%;font-size:11.5px}.iui-compare-filter-input::placeholder{color:var(--iui-muted)}.iui-compare-grid{grid-template-columns:repeat(auto-fit,minmax(min(100%,200px),1fr));gap:0;display:grid}.iui-compare-panel{box-shadow:none;cursor:pointer;background:0 0;border:none;border-radius:8px;flex-direction:column;padding:6px 14px;transition:opacity .15s,background-color .15s;display:flex}.iui-compare-panel:focus-visible{outline:2px solid var(--iui-accent);outline-offset:1px}.iui-compare-panel.is-dimmed{opacity:.42}.iui-compare-panel.is-focused{background:color-mix(in srgb, var(--iui-accent,#0b57d0) 4%, transparent)}.iui-compare-badge{background:color-mix(in srgb, var(--iui-accent,#0b57d0) 12%, transparent);color:var(--iui-accent,#0b57d0);white-space:nowrap;border-radius:999px;margin-left:auto;padding:1px 6px;font-size:10.5px;font-weight:600}.iui-compare-panel+.iui-compare-panel{border-left:1px solid color-mix(in srgb, var(--iui-text,#000) 10%, transparent)}.iui-compare-header{align-items:center;gap:8px;margin-bottom:8px;display:flex}.iui-compare-iconbox{width:16px;height:16px;color:var(--c-ink,var(--iui-text));background:0 0;border:none;flex-shrink:0;justify-content:center;align-items:center;display:inline-flex}.iui-compare-iconbox svg{width:16px;height:16px}.iui-compare-label{color:var(--iui-text);font-size:13px;font-weight:600}.iui-compare-points{flex-direction:column;gap:6px;display:flex}@container iui (width<=520px){.iui-compare-panel{padding:10px 0}.iui-compare-panel+.iui-compare-panel{border-left:none;border-top:1px solid color-mix(in srgb, var(--iui-text,#000) 10%, transparent)}}.iui-compare-point{align-items:flex-start;gap:8px;display:flex}.iui-compare-point-icon{width:14px;height:14px;color:var(--c-ink,var(--iui-text));flex-shrink:0;justify-content:center;align-items:center;margin-top:2px;display:inline-flex}.iui-compare-point-icon svg{width:14px;height:14px}.iui-compare-dot{background-color:var(--iui-muted);border-radius:9999px;flex-shrink:0;width:4px;height:4px;margin-top:7px;margin-left:5px;margin-right:5px}.iui-compare-point-text{color:var(--iui-text);flex:1;font-size:13px;line-height:1.45}",Ld=".iui-stepper-card{border-radius:var(--iui-radius-card,12px)}.iui-stepper-progress-wrap{background:color-mix(in srgb, var(--iui-text,#000) 8%, transparent);border-radius:999px;height:4px;margin-bottom:10px;overflow:hidden}.iui-stepper-progress-fill{border-radius:inherit;background:var(--iui-success,#10b981);width:0;height:100%;transition:width .18s}.iui-stepper-list{flex-direction:column;gap:10px;padding:4px 0;display:flex}.iui-stepper-step{gap:12px;display:flex}.iui-stepper-track{flex-direction:column;flex-shrink:0;align-items:center;width:20px;display:flex}.iui-stepper-circle{background-color:var(--iui-surface,#f4f4f5);border:1px solid color-mix(in srgb, var(--iui-text,#000) 15%, transparent);width:20px;height:20px;color:var(--iui-text);-webkit-user-select:none;user-select:none;cursor:pointer;border-radius:9999px;flex-shrink:0;justify-content:center;align-items:center;padding:0;font-family:inherit;font-size:11px;font-weight:600;transition:background-color .14s,border-color .14s,color .14s;display:flex}.iui-stepper-circle:hover{border-color:var(--iui-accent)}.iui-stepper-circle:focus-visible{outline:2px solid var(--iui-accent);outline-offset:2px}.iui-stepper-circle.is-done{background-color:var(--iui-success,#10b981);border-color:var(--iui-success,#10b981);color:#fff}.iui-stepper-step.is-completed .iui-stepper-title{color:var(--iui-muted);text-decoration:line-through}.iui-stepper-line{background-color:color-mix(in srgb, var(--iui-text,#000) 12%, transparent);flex:1;width:1px;min-height:10px;margin-top:4px;margin-bottom:4px}.iui-stepper-content{flex:1;min-width:0;padding-top:1px;padding-bottom:0}.iui-stepper-content.is-last{padding-bottom:0}.iui-stepper-title{color:var(--iui-text);font-size:13px;font-weight:600;line-height:1.4}.iui-stepper-detail{color:var(--iui-muted);margin-top:3px;font-size:12.5px;line-height:1.45}",zd=".iui-quiz-card{box-sizing:border-box;max-height:360px;overflow-y:auto}.iui-quiz-header{justify-content:space-between;align-items:center;gap:12px;margin-bottom:12px;display:flex}.iui-quiz-title-spacer{flex:1}.iui-quiz-header-right{flex-shrink:0;align-items:center;gap:8px;display:flex}.iui-quiz-counter{color:var(--iui-muted);font-variant-numeric:tabular-nums;-webkit-user-select:none;user-select:none;font-size:11.5px}.iui-quiz-nav{align-items:center;gap:2px;display:inline-flex}.iui-quiz-nav-btn{width:24px;height:24px;color:var(--iui-muted);cursor:pointer;background:0 0;border:none;border-radius:4px;justify-content:center;align-items:center;padding:0;transition:background-color .1s,color .1s;display:inline-flex}.iui-quiz-nav-btn:hover:not(:disabled){background-color:color-mix(in srgb, var(--iui-text,#000) 8%, transparent);color:var(--iui-text)}.iui-quiz-nav-btn:focus-visible{outline:2px solid var(--iui-accent);outline-offset:1px}.iui-quiz-nav-btn:disabled{opacity:.35;cursor:default}.iui-quiz-q-container{flex-direction:column;gap:10px;display:flex}.iui-quiz-q-text{color:var(--iui-text);font-size:13.5px;font-weight:600;line-height:1.45}.iui-quiz-options{flex-direction:column;gap:6px;display:flex}.iui-quiz-opt-row{box-sizing:border-box;border:1px solid color-mix(in srgb, var(--iui-text,#000) 12%, transparent);width:100%;height:36px;min-height:36px;color:var(--iui-text);font:inherit;cursor:pointer;text-align:left;background-color:#0000;border-radius:8px;align-items:center;gap:10px;padding:0 12px;font-size:13px;transition:background-color .12s,border-color .12s;display:flex}.iui-quiz-opt-row:hover:not(:disabled){background-color:color-mix(in srgb, var(--iui-text,#000) 5%, transparent)}.iui-quiz-opt-row:focus-visible{outline:2px solid var(--iui-accent);outline-offset:1px}.iui-quiz-opt-row:disabled{cursor:default}.iui-quiz-letter-circle{border:1px solid color-mix(in srgb, var(--iui-text,#000) 22%, transparent);width:20px;height:20px;color:var(--iui-muted);border-radius:9999px;flex-shrink:0;justify-content:center;align-items:center;font-size:11px;font-weight:600;line-height:1;display:inline-flex}.iui-quiz-opt-text{text-overflow:ellipsis;white-space:nowrap;flex:1;min-width:0;overflow:hidden}.iui-quiz-opt-row.is-correct{background-color:color-mix(in srgb, var(--iui-success,#10b981) 12%, transparent);border-color:color-mix(in srgb, var(--iui-success,#10b981) 40%, transparent);color:var(--iui-text)}.iui-quiz-opt-row.is-correct .iui-quiz-letter-circle{border-color:var(--iui-success,#10b981);color:var(--iui-success,#10b981)}.iui-quiz-opt-row.is-incorrect{background-color:color-mix(in srgb, var(--iui-danger,#ef4444) 12%, transparent);border-color:color-mix(in srgb, var(--iui-danger,#ef4444) 40%, transparent);color:var(--iui-text)}.iui-quiz-opt-row.is-incorrect .iui-quiz-letter-circle{border-color:var(--iui-danger,#ef4444);color:var(--iui-danger,#ef4444)}.iui-quiz-explain{color:var(--iui-muted);background-color:color-mix(in srgb, var(--iui-text,#000) 4%, transparent);border-radius:6px;align-items:center;gap:6px;margin-top:4px;padding:4px 6px;font-size:12px;line-height:1.4;display:flex}.iui-quiz-explain-icon{color:var(--iui-muted);flex-shrink:0;justify-content:center;align-items:center;display:inline-flex}.iui-quiz-explain-text{flex:1}.iui-quiz-results{text-align:center;flex-direction:column;justify-content:center;align-items:center;gap:16px;padding:24px 12px;display:flex}.iui-quiz-score-text{color:var(--iui-text);font-size:16px;font-weight:600}.iui-quiz-retry-btn,.iui-btn-ghost{border:1px solid color-mix(in srgb, var(--iui-text,#000) 15%, transparent);color:var(--iui-text);font:inherit;cursor:pointer;background:0 0;border-radius:6px;padding:6px 16px;font-size:12.5px;font-weight:550;transition:background-color .12s,border-color .12s}.iui-quiz-retry-btn:hover,.iui-btn-ghost:hover{background-color:color-mix(in srgb, var(--iui-text,#000) 8%, transparent)}.iui-quiz-finish-bar{justify-content:flex-end;margin-top:8px;display:flex}.iui-quiz-finish-btn{padding:4px 10px;font-size:12px}",_d=".flow-card{background:#fff;border-radius:14px;padding:14px 0;overflow:visible;border:0!important}.iui-root[data-theme=dark] .flow-card{background:#09090b}.iui-root:not([data-theme=dark]) .flow-card{background:#fff}.flow-card .iui-card-header{padding:0 2px 8px}.flow-controls,.iui-diagram-controls{border:1px solid color-mix(in srgb, var(--iui-text,#18181b) 10%, transparent);background:color-mix(in srgb, var(--iui-bg,#fff) 94%, transparent);-webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px);opacity:1;pointer-events:auto;border-radius:11px;gap:3px;padding:4px;top:8px;right:8px;box-shadow:0 3px 12px #0f172a17,0 1px 2px #0f172a0d}.flow-control-btn,.flow-fit-btn{width:auto;min-width:30px;height:30px;color:var(--iui-muted,#71717a);font:inherit;background:0 0;border:0;border-radius:7px;padding:0 8px;font-size:12px;font-weight:550;line-height:1;transition:background-color .14s,color .14s,transform .14s}.flow-control-btn:hover,.flow-fit-btn:hover{background:var(--iui-surface-2,#7878801f);color:var(--iui-text,#18181b)}.flow-control-btn:active,.flow-fit-btn:active{transform:scale(.96)}.flow-fit-btn{border-left:1px solid var(--iui-border,#e4e4e7);color:var(--iui-text,#18181b);border-radius:0 7px 7px 0;margin-left:3px;padding-inline-start:11px;padding-inline-end:11px}.flow-control-btn[aria-label=Reset\\ zoom]{min-width:30px;font-size:17px;font-weight:400}.flow-zoom-value{min-width:42px;color:var(--iui-text,#3f3f46);letter-spacing:-.01em;font-size:11px;font-weight:600}.iui-root[data-theme=dark] .flow-controls,.iui-root[data-theme=dark] .iui-diagram-controls{background:#18181bf0;border-color:#ffffff1f;box-shadow:0 4px 16px #0000004d}.iui-root[data-theme=dark] .flow-fit-btn{color:#f4f4f5;border-left-color:#ffffff24}.iui-root[data-theme=dark] .flow-zoom-value{color:#d4d4d8}@media (max-width:480px){.flow-controls,.iui-diagram-controls{gap:2px;padding:3px;top:6px;right:6px}.flow-control-btn,.flow-fit-btn{min-width:28px;height:28px;padding-inline-start:7px;padding-inline-end:7px}.flow-zoom-value{min-width:36px;font-size:10px}}@media (prefers-reduced-motion:reduce){.flow-control-btn,.flow-fit-btn{transition:none}}.flow-diagram{box-sizing:border-box;width:100%;padding:2px 0;position:relative}.flow-controls,.iui-diagram-controls{z-index:10;opacity:0;pointer-events:none;background:var(--iui-bg);border:1px solid color-mix(in srgb, var(--iui-text,#000) 12%, transparent);border-radius:6px;align-items:center;gap:2px;padding:2px;transition:opacity .12s;display:flex;position:absolute;top:4px;right:4px;box-shadow:0 1px 4px #0000000d}.flow-diagram:hover .flow-controls,.flow-diagram:focus-within .flow-controls,.iui-mermaid-diagram:hover .iui-diagram-controls,.iui-mermaid-diagram:focus-within .iui-diagram-controls{opacity:1;pointer-events:auto}@media (hover:none){.flow-controls,.iui-diagram-controls{opacity:1;pointer-events:auto}}.flow-control-btn{width:22px;height:22px;color:var(--iui-muted);font:inherit;cursor:pointer;background:0 0;border:none;border-radius:4px;justify-content:center;align-items:center;padding:0;font-size:11px;line-height:1;transition:background-color .1s,color .1s;display:inline-flex}.flow-control-btn:hover{background:color-mix(in srgb, var(--iui-text,#000) 8%, transparent);color:var(--iui-text)}.flow-control-btn:focus-visible{outline:2px solid var(--iui-accent);outline-offset:1px}.flow-fit-btn{height:22px;color:var(--iui-muted);font:inherit;cursor:pointer;background:0 0;border:none;border-radius:4px;justify-content:center;align-items:center;padding:0 6px;font-size:11px;font-weight:600;line-height:1;transition:background-color .1s,color .1s;display:inline-flex}.flow-fit-btn:hover{background:color-mix(in srgb, var(--iui-text,#000) 8%, transparent);color:var(--iui-text)}.flow-fit-btn:focus-visible{outline:2px solid var(--iui-accent);outline-offset:1px}.flow-zoom-value{min-width:34px;color:var(--iui-muted);text-align:center;font-variant-numeric:tabular-nums;-webkit-user-select:none;user-select:none;font-size:10.5px}.flow-viewport{box-sizing:border-box;cursor:grab;background:0 0;border:none;border-radius:0;width:100%;position:relative;overflow:hidden}.flow-viewport.is-panning,.iui-mermaid-wrap.is-panning{cursor:grabbing;-webkit-user-select:none;user-select:none}.flow-inner{transform-origin:top;margin:0 auto;position:relative}.flow-svg-overlay{pointer-events:none;position:absolute;top:0;bottom:0;left:0;right:0;overflow:visible}.flow-edge-path{color:var(--iui-muted,#71717a);stroke:currentColor;stroke-width:1.25px;fill:none;transition:opacity .15s,stroke-width .15s}.flow-edge-path.is-positive{color:var(--iui-success,#10b981)}.flow-edge-path.is-negative{color:var(--iui-danger,#ef4444)}.flow-inner.has-selection .flow-edge-path.is-dimmed{opacity:.15}.flow-inner.has-selection .flow-edge-path.is-highlighted{stroke-width:2px;opacity:1;color:var(--iui-accent,#0b57d0)}.flow-edge-label{background-color:var(--iui-bg,#fff);border:1px solid color-mix(in srgb, var(--iui-text,#000) 12%, transparent);color:var(--iui-muted);white-space:nowrap;pointer-events:none;z-index:2;border-radius:9999px;padding:1px 6px;font-size:11px;font-weight:500;line-height:1.3;transition:opacity .15s;position:absolute;transform:translate(-50%,-50%);box-shadow:0 1px 2px #0000000a}.iui-root[data-theme=dark] .flow-edge-label{background:#09090b}.iui-root:not([data-theme=dark]) .flow-edge-label{background:#fff}.flow-edge-label.tone-positive{color:var(--iui-success,#10b981)}.flow-edge-label.tone-negative{color:var(--iui-danger,#ef4444)}.flow-inner.has-selection .flow-edge-label.is-dimmed{opacity:.15}.flow-inner.has-selection .flow-edge-label.is-highlighted{opacity:1;color:var(--iui-accent);border-color:var(--iui-accent)}.flow-node{box-sizing:border-box;color:var(--iui-text,#0a0a0a);text-align:center;word-break:break-word;-webkit-user-select:none;user-select:none;z-index:1;cursor:pointer;background-color:#f8fafc;border:1px solid #d4d4d8;border-radius:10px;justify-content:center;align-items:center;gap:6px;max-width:180px;padding:6px 10px;font-size:12.5px;line-height:1.4;transition:opacity .15s,box-shadow .15s,border-color .15s,transform .15s;display:flex;position:absolute}.iui-root[data-theme=dark] .flow-node{color:#fafafa;background-color:#18181b;border-color:#3f3f46}.iui-root:not([data-theme=dark]) .flow-node{color:#18181b;background-color:#f8fafc;border-color:#d4d4d8}.flow-node:focus-visible{outline:2px solid var(--iui-accent);outline-offset:2px}.flow-node.is-pill{border-radius:9999px;padding:6px 14px}.flow-node.is-decision{background-color:#f4f4f5;border-color:#a1a1aa;border-radius:8px}.iui-root[data-theme=dark] .flow-node.is-decision{background-color:#27272a;border-color:#71717a}.flow-node.is-selected{border-color:var(--iui-accent);box-shadow:0 0 0 2px color-mix(in srgb, var(--iui-accent) 30%, transparent);background-color:color-mix(in srgb, var(--iui-accent) 8%, var(--iui-surface,#fafafa));z-index:3}.flow-node:hover{transform:translateY(-1px)}.flow-node.is-neighbor{border-color:color-mix(in srgb, var(--iui-accent) 50%, transparent);opacity:1;z-index:2}.flow-inner.has-selection .flow-node.is-dimmed{opacity:.2}.flow-node-text{flex-direction:column;justify-content:center;align-items:center;min-width:0;display:flex}.flow-node-label{color:var(--iui-text);overflow-wrap:break-word;-webkit-line-clamp:2;-webkit-box-orient:vertical;font-size:12.5px;font-weight:500;display:-webkit-box;overflow:hidden}.flow-node-sub{color:var(--iui-muted);margin-top:1px;font-size:11px;line-height:1.25}.flow-node-iconbox{color:var(--iui-muted);flex-shrink:0;justify-content:center;align-items:center;width:14px;height:14px;display:inline-flex}.flow-node-iconbox svg{width:14px;height:14px;display:block}.flow-node-detail{background:var(--iui-surface);border:1px solid color-mix(in srgb, var(--iui-accent) 25%, transparent);border-radius:8px;margin-top:6px;padding:8px 10px;font-size:12.5px;box-shadow:0 2px 8px #00000012}.flow-node-detail[hidden]{display:none}.flow-node-detail-header{justify-content:space-between;align-items:flex-start;gap:8px;margin-bottom:4px;display:flex}.flow-node-detail-title-wrap{flex-wrap:wrap;align-items:center;gap:6px;min-width:0;display:flex}.flow-node-detail-title{color:var(--iui-text);font-size:12.5px;font-weight:600}.flow-node-detail-group{color:var(--iui-accent);background:color-mix(in srgb, var(--iui-accent) 10%, transparent);border-radius:4px;padding:1px 5px;font-size:11px;font-weight:500}.flow-node-detail-close{width:20px;height:20px;color:var(--iui-muted);cursor:pointer;background:0 0;border:none;border-radius:4px;flex-shrink:0;justify-content:center;align-items:center;padding:0;font-size:14px;line-height:1;transition:background-color .1s,color .1s;display:inline-flex}.flow-node-detail-close:hover{background:color-mix(in srgb, var(--iui-text,#000) 8%, transparent);color:var(--iui-text)}.flow-node-detail-close:focus-visible{outline:2px solid var(--iui-accent);outline-offset:1px}.flow-node-detail-sub{color:var(--iui-muted);margin-bottom:4px;font-size:11.5px}.flow-node-detail-body{color:var(--iui-text);margin-bottom:4px;font-size:12px;line-height:1.5}.flow-node-detail-conns{border-top:1px solid color-mix(in srgb, var(--iui-text,#000) 8%, transparent);flex-direction:column;gap:2px;margin-top:4px;padding-top:4px;display:flex}.flow-node-detail-conn{color:var(--iui-muted);align-items:baseline;gap:4px;font-size:11.5px;line-height:1.4;display:flex}.flow-node-detail-conn-dir{color:var(--iui-accent);flex-shrink:0;font-weight:600}.flow-node-detail-conn-text{color:var(--iui-text);word-break:break-word;min-width:0}@media (prefers-reduced-motion:reduce){.flow-controls,.iui-diagram-controls,.flow-control-btn,.flow-fit-btn,.flow-node,.flow-edge-path,.flow-edge-label{transition:none}}",Bd='.iui-tree-card{overflow:visible}.iui-tree-header{flex-direction:column;gap:10px;margin-bottom:14px;display:flex}.iui-tree-title{margin:0}.iui-tree-controls{flex-wrap:wrap;align-items:center;gap:6px;display:flex}.iui-tree-search{border:1px solid color-mix(in srgb, var(--iui-text,#000) 15%, transparent);background:var(--iui-bg,#fff);min-width:100px;max-width:220px;height:28px;color:var(--iui-text,#0a0a0a);font:inherit;border-radius:999px;outline:none;flex:140px;padding:0 8px;font-size:12px;transition:border-color .12s}.iui-tree-search:focus{border-color:var(--iui-accent,#0b57d0)}.iui-tree-search::placeholder{color:var(--iui-muted,#71717a)}.iui-tree-ctrl-btn{border:1px solid color-mix(in srgb, var(--iui-text,#000) 15%, transparent);height:28px;color:var(--iui-muted,#71717a);font:inherit;cursor:pointer;white-space:nowrap;background:0 0;border-radius:999px;padding:0 10px;font-size:11.5px;transition:background-color .1s,color .1s}.iui-tree-ctrl-btn:hover{background:color-mix(in srgb, var(--iui-text,#000) 6%, transparent);color:var(--iui-text,#0a0a0a)}.iui-tree-toggle{border:1px solid color-mix(in srgb, var(--iui-text,#000) 15%, transparent);border-radius:999px;display:flex;overflow:hidden}.iui-tree-toggle-btn{height:28px;color:var(--iui-muted,#71717a);font:inherit;cursor:pointer;white-space:nowrap;background:0 0;border:none;padding:0 11px;font-size:11.5px;transition:background-color .1s,color .1s}.iui-tree-toggle-btn.is-active{background:var(--iui-accent,#0b57d0);color:#fff}.iui-tree-toggle-btn:not(.is-active):hover{background:color-mix(in srgb, var(--iui-text,#000) 6%, transparent);color:var(--iui-text,#0a0a0a)}.iui-tree-detail-bar{background:color-mix(in srgb, var(--iui-accent,#0b57d0) 7%, var(--iui-surface,#fafafa));border:1px solid color-mix(in srgb, var(--iui-accent,#0b57d0) 20%, transparent);border-radius:8px;align-items:flex-start;gap:8px;margin-bottom:10px;padding:8px 12px;animation:.16s iui-tree-fadein;display:flex}@keyframes iui-tree-fadein{0%{opacity:0;transform:translateY(-3px)}to{opacity:1;transform:translateY(0)}}.iui-tree-detail-content{flex-wrap:wrap;flex:1;align-items:center;gap:6px;font-size:12.5px;line-height:1.4;display:flex}.iui-tree-detail-label{color:var(--iui-text,#0a0a0a);font-weight:600}.iui-tree-detail-badge{background:var(--iui-accent,#0b57d0);color:#fff;border-radius:999px;align-items:center;padding:1px 7px;font-size:11px;font-weight:600;display:inline-flex}.iui-tree-detail-note{color:var(--iui-muted,#71717a);font-size:12px}.iui-tree-detail-close{width:22px;height:22px;color:var(--iui-muted,#71717a);cursor:pointer;background:0 0;border:none;border-radius:999px;flex-shrink:0;justify-content:center;align-items:center;font-size:16px;line-height:1;transition:background-color .1s;display:flex}.iui-tree-detail-close:hover{background:color-mix(in srgb, var(--iui-text,#000) 10%, transparent);color:var(--iui-text,#0a0a0a)}.iui-tree-outline-root{margin:0;padding:0;list-style:none}.iui-tree-ol-item{outline:none;margin:0;padding:0;list-style:none}.iui-tree-ol-row{cursor:pointer;-webkit-user-select:none;user-select:none;border-radius:6px;align-items:center;gap:5px;min-height:28px;padding:4px 6px;transition:background-color .1s;display:flex}.iui-tree-ol-row:hover{background:color-mix(in srgb, var(--iui-text,#000) 5%, transparent)}.iui-tree-ol-item:focus>.iui-tree-ol-row,.iui-tree-ol-row:focus{outline:2px solid var(--iui-accent,#0b57d0);outline-offset:1px}.iui-tree-ol-row.is-selected{background:color-mix(in srgb, var(--iui-accent,#0b57d0) 12%, transparent)}.iui-tree-ol-row.is-ancestor{background:color-mix(in srgb, var(--iui-accent,#0b57d0) 5%, transparent)}.iui-tree-ol-item.is-selected>.iui-tree-ol-row{background:color-mix(in srgb, var(--iui-accent,#0b57d0) 12%, transparent)}.iui-tree-ol-item.is-ancestor>.iui-tree-ol-row{background:color-mix(in srgb, var(--iui-accent,#0b57d0) 5%, transparent)}.iui-tree-ol-chevron{width:18px;height:18px;color:var(--iui-muted,#71717a);cursor:pointer;background:0 0;border:none;border-radius:4px;flex-shrink:0;justify-content:center;align-items:center;padding:0;font-size:9px;transition:color .1s;display:flex}.iui-tree-ol-chevron:hover{color:var(--iui-text,#0a0a0a);background:color-mix(in srgb, var(--iui-text,#000) 8%, transparent)}.iui-tree-ol-leaf-dot{background:color-mix(in srgb, var(--iui-text,#000) 25%, transparent);border-radius:999px;flex-shrink:0;width:6px;height:6px;margin:0 6px}.iui-tree-ol-label{color:var(--iui-text,#0a0a0a);word-break:break-word;flex:1;font-size:13px;font-weight:500;line-height:1.4}.iui-tree-ol-badge{background:var(--iui-accent,#0b57d0);color:#fff;border-radius:999px;flex-shrink:0;align-items:center;padding:1px 7px;font-size:10.5px;font-weight:600;line-height:1.4;display:inline-flex}.iui-tree-ol-count-badge{background:color-mix(in srgb, var(--iui-text,#000) 10%, transparent);color:var(--iui-muted,#71717a);border-radius:999px;flex-shrink:0;align-items:center;padding:1px 7px;font-size:10.5px;font-weight:500;line-height:1.4;display:inline-flex}.iui-tree-ol-children{border-left:1px solid color-mix(in srgb, var(--iui-text,#000) 10%, transparent);margin:0 0 0 9px;padding-left:20px;list-style:none}.iui-tree-ol-item.is-search-miss>.iui-tree-ol-row,.iui-tree-dn-node.is-search-miss,.iui-tree-dn-node.is-search-miss .iui-tree-dn-label{opacity:.35}.iui-tree-ol-item.is-search-match>.iui-tree-ol-row .iui-tree-ol-label{font-weight:700}.iui-tree-diagram{padding:8px 4px;overflow-x:auto}.iui-tree-v .iui-tree-dn-wrapper{flex-direction:column;align-items:center;gap:0;display:flex}.iui-tree-v .iui-tree-dn-children{flex-flow:wrap;justify-content:center;align-items:flex-start;gap:12px;padding-top:20px;display:flex;position:relative}.iui-tree-v .iui-tree-dn-wrapper>.iui-tree-dn-node{position:relative}.iui-tree-v .iui-tree-dn-wrapper>.iui-tree-dn-node:after{content:"";background:color-mix(in srgb, var(--iui-text,#000) 15%, transparent);width:1.5px;height:20px;position:absolute;bottom:-20px;left:50%;transform:translate(-50%)}.iui-tree-v .iui-tree-dn-children>.iui-tree-dn-wrapper>.iui-tree-dn-node:before{content:"";background:color-mix(in srgb, var(--iui-text,#000) 15%, transparent);width:1.5px;height:20px;position:absolute;top:-20px;left:50%;transform:translate(-50%)}.iui-tree-v .iui-tree-dn-wrapper.is-collapsed>.iui-tree-dn-node:after{display:none}.iui-tree-h .iui-tree-dn-wrapper{flex-direction:row;align-items:center;gap:0;display:flex}.iui-tree-h .iui-tree-dn-children{flex-direction:column;justify-content:center;align-items:flex-start;gap:8px;padding-left:24px;display:flex;position:relative}.iui-tree-h .iui-tree-dn-wrapper>.iui-tree-dn-node:after{content:"";background:color-mix(in srgb, var(--iui-text,#000) 15%, transparent);width:24px;height:1.5px;position:absolute;top:50%;right:-24px;transform:translateY(-50%)}.iui-tree-h .iui-tree-dn-wrapper.is-collapsed>.iui-tree-dn-node:after{display:none}.iui-tree-h .iui-tree-dn-children>.iui-tree-dn-wrapper>.iui-tree-dn-node:before{content:"";background:color-mix(in srgb, var(--iui-text,#000) 15%, transparent);width:24px;height:1.5px;position:absolute;top:50%;left:-24px;transform:translateY(-50%)}.iui-tree-dn-node{border:1.5px solid color-mix(in srgb, var(--iui-text,#000) 14%, transparent);background:var(--iui-surface,#fafafa);min-width:72px;max-width:180px;color:var(--iui-text,#0a0a0a);cursor:pointer;-webkit-user-select:none;user-select:none;word-break:break-word;border-radius:8px;outline:none;flex-direction:column;align-items:flex-start;gap:2px;padding:6px 10px;transition:border-color .12s,background-color .12s,box-shadow .12s;display:inline-flex;position:relative}.iui-tree-dn-node:hover{border-color:var(--iui-accent,#0b57d0);box-shadow:0 1px 6px #00000012}.iui-tree-dn-node:focus-visible{outline:2px solid var(--iui-accent,#0b57d0);outline-offset:2px}.iui-tree-dn-node.is-selected{border-color:var(--iui-accent,#0b57d0);background:color-mix(in srgb, var(--iui-accent,#0b57d0) 10%, var(--iui-surface,#fafafa));box-shadow:0 2px 8px #0000001a}.iui-tree-dn-node.is-ancestor{border-color:color-mix(in srgb, var(--iui-accent,#0b57d0) 50%, transparent)}.iui-tree-dn-label-row{flex-wrap:wrap;align-items:center;gap:5px;display:flex}.iui-tree-dn-label{color:var(--iui-text,#0a0a0a);word-break:break-word;font-size:12.5px;font-weight:600;line-height:1.35}.iui-tree-dn-note{color:var(--iui-muted,#71717a);-webkit-line-clamp:2;-webkit-box-orient:vertical;margin-top:2px;font-size:11px;line-height:1.3;display:-webkit-box;overflow:hidden}.iui-tree-dn-badge{background:var(--iui-accent,#0b57d0);color:#fff;border-radius:999px;align-items:center;padding:1px 6px;font-size:10px;font-weight:600;line-height:1.4;display:inline-flex}.iui-tree-dn-count{background:color-mix(in srgb, var(--iui-text,#000) 10%, transparent);color:var(--iui-muted,#71717a);border-radius:999px;align-items:center;padding:1px 6px;font-size:10px;font-weight:500;line-height:1.4;display:inline-flex}.iui-tree-dn-chevron{width:16px;height:16px;color:var(--iui-muted,#71717a);cursor:pointer;background:0 0;border:none;border-radius:3px;flex-shrink:0;justify-content:center;align-items:center;padding:0;font-size:8px;transition:color .1s;display:flex}.iui-tree-dn-chevron:hover{color:var(--iui-text,#0a0a0a);background:color-mix(in srgb, var(--iui-text,#000) 8%, transparent)}.iui-tree-content{min-height:60px;overflow-x:auto}.iui-root[data-theme=dark] .iui-tree-dn-node{background:color-mix(in srgb, var(--iui-text,#fff) 4%, var(--iui-bg,#18181b))}.iui-root[data-theme=dark] .iui-tree-dn-node.is-selected{background:color-mix(in srgb, var(--iui-accent,#4f9eff) 15%, var(--iui-bg,#18181b))}.iui-root[data-theme=dark] .iui-tree-search{background:color-mix(in srgb, var(--iui-text,#fff) 5%, var(--iui-bg,#18181b))}',Id=".iui-mermaid-card{background:#fff;border-radius:14px;padding:14px 0;overflow:visible;border:0!important}.iui-root[data-theme=dark] .iui-mermaid-card{color:#fafafa;background:#09090b}.iui-root:not([data-theme=dark]) .iui-mermaid-card{color:#18181b;background:#fff}.iui-mermaid-card .iui-card-header{padding:0 2px 8px}.iui-mermaid-card .iui-title{letter-spacing:-.025em;font-size:15px}.iui-mermaid-card .iui-card-body{min-width:0;max-height:none;overflow:visible}.iui-mermaid-diagram{box-sizing:border-box;width:100%;min-width:0;color:var(--iui-text);padding:34px 0 4px;position:relative}.iui-mermaid-diagram .iui-diagram-controls{z-index:2;opacity:0;pointer-events:none;background:var(--iui-surface,var(--iui-bg));border:1px solid var(--iui-border);border-radius:9px;align-items:center;gap:3px;padding:4px;transition:opacity .14s;display:flex;position:absolute;top:2px;right:2px;box-shadow:0 2px 10px #0f172a14}.iui-mermaid-diagram:hover .iui-diagram-controls,.iui-mermaid-diagram:focus-within .iui-diagram-controls{opacity:1;pointer-events:auto}.iui-mermaid-diagram .flow-control-btn,.iui-mermaid-diagram .flow-fit-btn{min-width:27px;height:27px;color:var(--iui-muted);font:inherit;cursor:pointer;background:0 0;border:0;border-radius:6px;padding:0 7px;font-size:12px}.iui-mermaid-diagram .flow-control-btn:focus-visible{outline:2px solid var(--iui-accent);outline-offset:1px}.iui-mermaid-diagram .flow-fit-btn:focus-visible{outline:2px solid var(--iui-accent);outline-offset:1px}.iui-mermaid-diagram .flow-zoom-value{min-width:38px;color:var(--iui-muted);text-align:center;font-variant-numeric:tabular-nums;font-size:11px}.iui-mermaid-wrap{cursor:grab;scrollbar-width:thin;scrollbar-color:var(--iui-subtle) transparent;background:#fff;border:0;border-radius:12px;justify-content:center;align-items:flex-start;width:100%;max-width:100%;min-height:72px;max-height:min(70vh,640px);display:flex;position:relative;overflow:auto}.iui-root[data-theme=dark] .iui-mermaid-wrap{background:#09090b}.iui-root:not([data-theme=dark]) .iui-mermaid-wrap{background:#fff}.iui-mermaid-wrap.is-panning{cursor:grabbing;-webkit-user-select:none;user-select:none}.iui-mermaid-inner{transform-origin:top;box-sizing:border-box;flex:none;justify-content:center;padding:20px;display:flex}.iui-root:not([data-theme=dark]) .iui-mermaid-diagram .iui-diagram-controls{background:#fafafa;border-color:#e4e4e7;box-shadow:0 3px 12px #18181b14}.iui-mermaid-wrap svg{max-width:none;height:auto;font-family:var(--iui-font,ui-sans-serif, system-ui, sans-serif);display:block;overflow:visible}.iui-mermaid-wrap svg .nodeLabel,.iui-mermaid-wrap svg .edgeLabel,.iui-mermaid-wrap svg .label,.iui-mermaid-wrap svg .messageText,.iui-mermaid-wrap svg .loopText,.iui-mermaid-wrap svg .noteText,.iui-mermaid-wrap svg .actor{font-family:var(--iui-font,ui-sans-serif, system-ui, sans-serif)}.iui-root[data-theme=dark] .iui-mermaid-wrap svg .edgeLabel rect,.iui-root[data-theme=dark] .iui-mermaid-wrap svg .labelBkg{fill:#09090b!important}.iui-root:not([data-theme=dark]) .iui-mermaid-wrap svg .edgeLabel rect,.iui-root:not([data-theme=dark]) .iui-mermaid-wrap svg .labelBkg{fill:#fff!important}.iui-mermaid-diagram .iui-diagram-controls{border:1px solid color-mix(in srgb, var(--iui-text,#18181b) 10%, transparent);-webkit-backdrop-filter:blur(12px);backdrop-filter:blur(12px);opacity:1;pointer-events:auto;background:#fffffff0;border-radius:11px;gap:3px;padding:4px;top:8px;right:8px;box-shadow:0 3px 12px #0f172a17,0 1px 2px #0f172a0d}.iui-mermaid-diagram .flow-control-btn,.iui-mermaid-diagram .flow-fit-btn{width:auto;min-width:30px;height:30px;color:var(--iui-muted);font:inherit;background:0 0;border:0;border-radius:7px;padding:0 8px;font-size:12px;font-weight:550;line-height:1;transition:background-color .14s,color .14s,transform .14s}.iui-mermaid-diagram .flow-control-btn:hover,.iui-mermaid-diagram .flow-fit-btn:hover{background:var(--iui-surface-2);color:var(--iui-text)}.iui-mermaid-diagram .flow-control-btn:active,.iui-mermaid-diagram .flow-fit-btn:active{transform:scale(.96)}.iui-mermaid-diagram .flow-fit-btn{border-left:1px solid var(--iui-border);color:var(--iui-text);border-radius:0 7px 7px 0;margin-left:3px;padding-inline-start:11px;padding-inline-end:11px}.iui-mermaid-diagram .flow-control-btn[aria-label=Reset\\ zoom]{min-width:30px;font-size:17px;font-weight:400}.iui-mermaid-diagram .flow-zoom-value{min-width:42px;color:var(--iui-text);font-size:11px;font-weight:600}.iui-root[data-theme=dark] .iui-mermaid-diagram .iui-diagram-controls{background:#18181bf0;border-color:#ffffff1f;box-shadow:0 4px 16px #0000004d}.iui-root[data-theme=dark] .iui-mermaid-diagram .flow-fit-btn{color:#f4f4f5;border-left-color:#ffffff24}.iui-root[data-theme=dark] .iui-mermaid-diagram .flow-zoom-value{color:#d4d4d8}.iui-fallback .iui-fallback-pre{max-width:100%;color:var(--iui-text);background:var(--iui-surface);border:1px solid var(--iui-border);font-family:var(--iui-mono,ui-monospace, monospace);white-space:pre;border-radius:8px;padding:12px;font-size:12px;line-height:1.55;overflow:auto}@media (hover:none){.iui-mermaid-diagram .iui-diagram-controls{opacity:1;pointer-events:auto}}@media (max-width:480px){.iui-mermaid-diagram{padding-top:38px}.iui-mermaid-diagram .iui-diagram-controls{right:0}.iui-mermaid-inner{padding:12px}.iui-mermaid-diagram .iui-diagram-controls{gap:2px;padding:3px;top:6px;right:6px}.iui-mermaid-diagram .flow-control-btn,.iui-mermaid-diagram .flow-fit-btn{min-width:28px;height:28px;padding-inline-start:7px;padding-inline-end:7px}.iui-mermaid-diagram .flow-zoom-value{min-width:36px;font-size:10px}}@media (prefers-reduced-motion:reduce){.iui-mermaid-diagram .iui-diagram-controls,.iui-mermaid-diagram .flow-control-btn,.iui-mermaid-diagram .flow-fit-btn{transition:none}}",Fd=".iui-callout-card{border-radius:var(--iui-radius-card,12px)}.iui-callout-box{border:none;border-left:3px solid var(--c-ink,var(--iui-accent,#0b57d0));background-color:color-mix(in srgb, var(--c-ink,var(--iui-accent,#0b57d0)) 8%, transparent);color:var(--iui-text);box-sizing:border-box;border-radius:8px;align-items:flex-start;gap:10px;padding:8px 12px;display:flex}.iui-callout-box.c-bad{border-left-color:var(--iui-danger,#ef4444);background-color:color-mix(in srgb, var(--iui-danger,#ef4444) 8%, transparent)}.iui-callout-iconbox{width:16px;height:16px;color:var(--c-ink,var(--iui-accent,#0b57d0));background:0 0;border:none;flex-shrink:0;justify-content:center;align-items:center;margin-top:1px;display:inline-flex}.iui-callout-iconbox svg{stroke:currentColor;width:16px;height:16px}.iui-callout-content{flex:1;min-width:0}.iui-callout-title{color:var(--iui-text);margin-bottom:2px;font-size:13px;font-weight:600;line-height:1.4}.iui-callout-text{color:var(--iui-text);font-size:13px;line-height:1.45}",$d=".iui-stats-card{border-radius:var(--iui-radius-card,12px)}.iui-stats-grid{flex-flow:wrap;align-items:flex-start;gap:24px 32px;padding:4px 0;display:flex}.iui-stat-item{box-sizing:border-box;box-shadow:none;background:0 0;border:none;border-radius:0;flex-direction:column;gap:2px;min-width:80px;padding:0;display:flex}.iui-stat-label-row{align-items:center;gap:6px;display:flex}.iui-stat-label{color:var(--iui-muted);font-size:12px;font-weight:500;line-height:1.3}.iui-stat-item-icon{width:14px;height:14px;color:var(--iui-muted);background:0 0;border:none;justify-content:center;align-items:center;display:inline-flex}.iui-stat-item-icon svg{width:14px;height:14px}.iui-stat-val-row{align-items:baseline;gap:6px;display:flex}.iui-stat-value{color:var(--iui-text);font-variant-numeric:tabular-nums;font-size:20px;font-weight:600;line-height:1.25}.iui-stat-delta{background:0 0;border:none;padding:0;font-size:11.5px;font-weight:600;line-height:1.2}.iui-stat-delta.c-mint{color:var(--iui-success,#10b981)}.iui-stat-delta.c-rose{color:var(--iui-danger,#ef4444)}.iui-stat-delta.c-stone{color:var(--iui-muted)}.iui-stat-hint{color:var(--iui-muted);font-size:11px;line-height:1.25}.iui-stat-sparkline-wrap{margin-top:4px}.iui-stat-sparkline{display:block;overflow:visible}",jd=".iui-tabs-card{border-radius:var(--iui-radius-card,12px)}.iui-tabs-nav{background-color:var(--iui-surface);border:1px solid var(--iui-border);border-radius:10px;gap:2px;max-width:100%;margin-bottom:14px;padding:3px;display:inline-flex;position:relative;overflow-x:auto}.iui-tabs-indicator{background-color:var(--iui-bg);border:1px solid var(--iui-border);pointer-events:none;box-sizing:border-box;border-radius:8px;transition:transform .24s cubic-bezier(.2,.8,.2,1),width .24s cubic-bezier(.2,.8,.2,1);position:absolute;top:3px;bottom:3px;left:0}@media (prefers-reduced-motion:reduce){.iui-tabs-indicator{transition:none!important}}.iui-tabs-btn{all:unset;z-index:1;color:var(--iui-muted);cursor:pointer;white-space:nowrap;-webkit-user-select:none;user-select:none;border-radius:8px;padding:6px 14px;font-size:13px;font-weight:500;transition:color .18s cubic-bezier(.2,.8,.2,1);position:relative}.iui-tabs-btn:hover{color:var(--iui-text)}.iui-tabs-btn.is-active{color:var(--iui-text);font-weight:600}.iui-tabs-btn:focus-visible{outline:2px solid var(--iui-text);outline-offset:1px}.iui-tabs-panel{border:0;border-top:1px solid var(--iui-border);background:0 0;border-radius:0;min-height:48px;padding:14px 0 0;line-height:1.5}.iui-tabs-text{color:var(--iui-text);white-space:pre-wrap;font-size:13.5px}.iui-tabs-list{flex-direction:column;gap:6px;margin:0;padding-left:20px;display:flex}.iui-tabs-list-item{color:var(--iui-text);font-size:13.5px}",Nd=".iui-timeline-card{background:#fff;border-radius:14px;padding:14px 0;border:0!important}.iui-root[data-theme=dark] .iui-timeline-card{background:#09090b}.iui-root:not([data-theme=dark]) .iui-timeline-card{background:#fff}.iui-timeline-card .iui-card-header{padding:0 2px 8px}.iui-timeline-toolbar{flex-wrap:wrap;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px;display:flex}.iui-timeline-expand-btn{all:unset;color:var(--iui-muted);border:1px solid color-mix(in srgb, var(--iui-text,#000) 12%, transparent);cursor:pointer;border-radius:6px;padding:3px 8px;font-size:11.5px;font-weight:500;transition:color .12s,background-color .12s}.iui-timeline-expand-btn:hover{color:var(--iui-text);background:color-mix(in srgb, var(--iui-text,#000) 5%, transparent)}.iui-timeline-expand-btn:focus-visible{outline:2px solid var(--iui-accent);outline-offset:1px}.iui-timeline-filter-pills{flex-wrap:wrap;align-items:center;gap:4px;display:inline-flex}.iui-timeline-filter-pill{all:unset;color:var(--iui-muted);border:1px solid color-mix(in srgb, var(--iui-text,#000) 12%, transparent);cursor:pointer;border-radius:999px;padding:2px 8px;font-size:11px;font-weight:500;transition:color .12s,background-color .12s,border-color .12s}.iui-timeline-filter-pill:hover{color:var(--iui-text)}.iui-timeline-filter-pill.is-active{color:var(--iui-accent);border-color:var(--iui-accent);background:color-mix(in srgb, var(--iui-accent,#0b57d0) 10%, transparent);font-weight:600}.iui-timeline-filter-pill:focus-visible{outline:2px solid var(--iui-accent);outline-offset:1px}.iui-timeline-list{flex-direction:column;padding:4px 0;display:flex}.iui-timeline-row{gap:12px;display:flex}.iui-timeline-row.is-collapsible{cursor:pointer;border-radius:6px}.iui-timeline-row.is-collapsible:hover .iui-timeline-title{color:var(--iui-accent)}.iui-timeline-row.is-collapsible:focus-visible{outline:2px solid var(--iui-accent);outline-offset:2px}.iui-timeline-dot.is-done{background-color:var(--iui-success,#10b981)}.iui-timeline-dot.is-active-ev{background-color:var(--iui-accent,#0b57d0);box-shadow:0 0 0 3px color-mix(in srgb, var(--iui-accent,#0b57d0) 20%, transparent)}.iui-timeline-dot.is-upcoming{background-color:var(--iui-muted);opacity:.55}.iui-timeline-title-row{flex-wrap:wrap;align-items:center;gap:6px;display:flex}.iui-timeline-status-badge{text-transform:uppercase;letter-spacing:.03em;border-radius:999px;padding:1px 6px;font-size:10px;font-weight:600}.iui-timeline-status-badge.is-done{background:color-mix(in srgb, var(--iui-success,#10b981) 12%, transparent);color:var(--iui-success,#10b981)}.iui-timeline-status-badge.is-active{background:color-mix(in srgb, var(--iui-accent,#0b57d0) 12%, transparent);color:var(--iui-accent,#0b57d0)}.iui-timeline-status-badge.is-upcoming{background:color-mix(in srgb, var(--iui-text,#000) 7%, transparent);color:var(--iui-muted)}.iui-timeline-track{flex-direction:column;flex-shrink:0;align-items:center;width:14px;display:flex}.iui-timeline-dot{background-color:var(--iui-muted);width:6px;height:6px;box-shadow:none;border:none;border-radius:9999px;flex-shrink:0;margin-top:6px}.iui-timeline-dot.has-icon{width:16px;height:16px;color:var(--iui-muted);background:0 0;border:none;justify-content:center;align-items:center;margin-top:1px;display:inline-flex}.iui-timeline-dot.has-icon svg{width:12px;height:12px}.iui-timeline-line{background-color:color-mix(in srgb, var(--iui-text,#000) 12%, transparent);flex:1;width:1px;min-height:18px;margin-top:4px;margin-bottom:4px}.iui-timeline-content{flex:1;min-width:0;padding-bottom:14px}.iui-timeline-content.is-last{padding-bottom:2px}.iui-timeline-time{color:var(--iui-muted);margin-bottom:2px;font-size:11px;font-weight:500;line-height:1.25}.iui-timeline-title{color:var(--iui-text);margin-bottom:2px;font-size:13px;font-weight:600;line-height:1.4}.iui-timeline-list{gap:2px;padding:2px 0}.iui-timeline-row{border-radius:10px;gap:14px;padding:7px 9px 0;transition:background-color .14s}.iui-timeline-row.is-collapsible:hover{background:color-mix(in srgb, var(--iui-text) 4%, transparent)}.iui-timeline-row.is-active-ev{background:color-mix(in srgb, var(--iui-accent) 5%, transparent)}.iui-timeline-track{width:16px;padding-top:1px}.iui-timeline-dot{background:var(--iui-subtle);outline:3px solid color-mix(in srgb, var(--iui-subtle) 13%, transparent);width:8px;height:8px;margin-top:5px}.iui-timeline-dot.is-done{background:var(--iui-success);outline-color:color-mix(in srgb, var(--iui-success) 18%, transparent)}.iui-timeline-dot.is-active-ev{background:var(--iui-accent);outline:4px solid color-mix(in srgb, var(--iui-accent) 16%, transparent);box-shadow:none}.iui-timeline-dot.is-upcoming{background:var(--iui-surface-2);outline-color:color-mix(in srgb, var(--iui-muted) 12%, transparent);opacity:1}.iui-timeline-line{background:color-mix(in srgb, var(--iui-muted) 22%, transparent);border-radius:2px;width:2px;min-height:22px;margin-top:6px;margin-bottom:3px}.iui-timeline-time{letter-spacing:.055em;text-transform:uppercase;margin-bottom:3px;font-size:10px;font-weight:650}.iui-timeline-title{letter-spacing:-.012em;margin-bottom:3px;font-size:13.5px}.iui-timeline-text{padding-bottom:2px;font-size:12.5px;line-height:1.55}.iui-timeline-status-badge{letter-spacing:.045em;padding:2px 7px}.iui-timeline-expand-btn,.iui-timeline-filter-pill{border-color:color-mix(in srgb, var(--iui-text) 10%, transparent);background:color-mix(in srgb, var(--iui-text) 3%, transparent)}.iui-timeline-filter-pill.is-active{background:var(--iui-accent-bg);border-color:color-mix(in srgb, var(--iui-accent) 30%, transparent)}@media (max-width:480px){.iui-timeline-row{gap:11px;padding-left:5px;padding-right:5px}.iui-timeline-toolbar{align-items:flex-start}}@media (prefers-reduced-motion:reduce){.iui-timeline-row{transition:none}}.iui-timeline-text{color:var(--iui-muted);font-size:13px;line-height:1.45}",qd=".iui-followups-card{border-radius:var(--iui-radius-card,18px)}.iui-root[data-host=gemini] .iui-followup-chip{box-sizing:border-box;border:1px solid var(--iui-border);background-color:var(--iui-surface);height:32px;color:var(--iui-text);box-shadow:none;border-radius:8px;padding:0 12px;font-size:14px}.iui-root[data-host=gemini] .iui-followup-chip:hover{background-color:var(--iui-surface-2);border-color:var(--iui-border);color:var(--iui-text)}.iui-root[data-host=grok] .iui-followup-chip{box-sizing:border-box;border:1px solid var(--iui-border);background-color:var(--iui-surface);height:28px;color:var(--iui-text);box-shadow:none;border-radius:9999px;padding:0 12px;font-size:13px}.iui-root[data-host=grok] .iui-followup-chip:hover{background-color:var(--iui-surface-2);border-color:var(--iui-border);color:var(--iui-text)}.iui-followups-container{flex-wrap:wrap;gap:8px;display:flex}.iui-followup-chip{background-color:var(--iui-surface);border:1px solid var(--iui-border);color:var(--iui-text);cursor:pointer;-webkit-user-select:none;user-select:none;border-radius:9999px;align-items:center;gap:6px;padding:6px 14px;font-size:13px;font-weight:500;transition:background-color .16s cubic-bezier(.2,.8,.2,1),border-color .16s cubic-bezier(.2,.8,.2,1);display:inline-flex;box-shadow:0 1px 2px #0000000a}.iui-followup-chip:hover{background-color:var(--c-bg,#f1edfc);border-color:var(--c-line,#dcd3f6);color:var(--c-ink,#4c3d91)}.iui-followup-chip:active,.iui-followup-chip.is-clicked{background-color:var(--c-bg,#f1edfc)}.iui-followup-icon{width:18px;height:18px;color:var(--c-ink,var(--iui-text));background:0 0;border:none;flex-shrink:0;justify-content:center;align-items:center;display:inline-flex}.iui-followup-icon svg{width:18px;height:18px}.iui-followup-text{line-height:1.35}",Od=".iui-math-card{flex-direction:column;gap:16px;display:flex}.iui-math-main{background-color:var(--iui-surface);border:1px solid var(--iui-border);border-radius:var(--iui-radius-inner,12px);color:var(--iui-text);justify-content:center;align-items:center;padding:20px 16px;font-size:18px;line-height:1.4;display:flex;overflow-x:auto;box-shadow:0 1px 3px #0000000a}.iui-root[data-host=gemini] .iui-math-main{background-color:var(--iui-surface-2);box-shadow:none;border:none;border-radius:12px}.iui-root[data-host=grok] .iui-math-main{background-color:var(--iui-surface-2);border:1px solid var(--iui-border);box-shadow:none;border-radius:8px}.iui-math-steps{flex-direction:column;gap:10px;display:flex}.iui-math-steps-title{text-transform:uppercase;letter-spacing:.05em;color:var(--iui-muted);margin-bottom:2px;font-size:12px;font-weight:600}.iui-math-step{background-color:var(--iui-bg);border:1px solid var(--iui-border);border-radius:10px;align-items:flex-start;gap:12px;padding:12px 14px;transition:background-color .16s cubic-bezier(.2,.8,.2,1);display:flex}.iui-math-step:hover{background-color:var(--iui-surface)}.iui-math-step-num{background-color:var(--c-bg,#f1edfc);width:22px;height:22px;color:var(--c-ink,#4c3d91);border:1px solid var(--c-line,#dcd3f6);border-radius:999px;flex-shrink:0;justify-content:center;align-items:center;margin-top:2px;font-size:11px;font-weight:700;display:inline-flex}.iui-math-step-body{flex-direction:column;flex:1;gap:4px;min-width:0;display:flex}.iui-math-step-formula{color:var(--iui-text);font-size:15px;overflow-x:auto}.iui-math-step-note{color:var(--iui-muted);font-size:12.5px;line-height:1.4}.iui-math-inline{vertical-align:middle;padding:0 2px;display:inline-block}.iui-math-display{text-align:center;margin:6px 0;display:block;overflow-x:auto}.katex{white-space:nowrap;text-indent:0;text-rendering:auto;font-family:KaTeX_Main,Times New Roman,STIXGeneral,serif;line-height:1.2}.katex *{-webkit-font-smoothing:antialiased}.katex .katex-html{display:inline-block}.katex .katex-mathml{clip:rect(1px, 1px, 1px, 1px);border:0;width:1px;height:1px;padding:0;position:absolute;overflow:hidden}.katex .base{white-space:nowrap;width:min-content;display:inline-block;position:relative}.katex .strut{height:2em;display:inline-block}.katex .mord,.katex .mbin,.katex .mrel,.katex .mopen,.katex .mclose,.katex .mpunct,.katex .minner{display:inline-block}.katex .mbin{margin-left:.2222em;margin-right:.2222em}.katex .mrel{margin-left:.2778em;margin-right:.2778em}.katex .mop{display:inline-block}.katex .mfrac{vertical-align:-.5em;text-align:center;display:inline-block}.katex .frac-line{border-bottom-style:solid;border-bottom-width:.04em;width:100%;display:block}.katex .vlist-t{table-layout:fixed;border-collapse:collapse;display:inline-table}.katex .vlist-r{display:table-row}.katex .vlist{vertical-align:bottom;display:table-cell;position:relative}.katex .vlist>span{height:0;display:block;position:relative}.katex .vlist>span>span{display:inline-block}.katex .msupsub{vertical-align:-.5em;display:inline-block}.katex .sqrt{display:inline-block}.katex .sqrt>.root{margin-left:.2778em;margin-right:-.5556em}.katex-display{text-align:center;margin:.5em 0;display:block}.katex-display>.katex{text-align:center;white-space:nowrap;display:block}.katex-display>.katex>.katex-html{display:block;position:relative}",Dd='.iui-code-card{border-radius:var(--iui-radius-card,18px);padding:0;overflow:visible}.iui-root[data-host=gemini] .iui-code-card{background-color:var(--iui-surface);border:none;border-radius:16px}.iui-root[data-host=gemini] .iui-code-inner-header{background-color:var(--iui-surface-2);border-bottom:1px solid var(--iui-border)}.iui-root[data-host=gemini] .iui-code-wrap{background-color:var(--iui-surface);font-family:var(--iui-mono,"Google Sans Mono", monospace)}.iui-root[data-host=grok] .iui-code-card{background-color:var(--iui-surface-2);border:1px solid var(--iui-border);border-radius:8px}.iui-root[data-host=grok] .iui-code-inner-header{background-color:var(--iui-surface);border-bottom:1px solid var(--iui-border)}.iui-root[data-host=grok] .iui-code-wrap{background-color:var(--iui-surface-2);font-family:var(--iui-mono,ui-monospace, monospace)}.iui-code-inner-header{background-color:var(--iui-surface);border-bottom:1px solid var(--iui-border);justify-content:space-between;align-items:center;gap:8px;padding:8px 14px;display:flex}.iui-code-meta-left{align-items:center;gap:8px;min-width:0;display:flex}.iui-code-lang-pill{text-transform:uppercase;letter-spacing:.05em;background-color:var(--c-bg,#eaf4fd);color:var(--c-ink,#1f5f8f);border:1px solid var(--c-line,#d0e4f7);border-radius:6px;align-items:center;padding:2px 8px;font-size:11px;font-weight:700;display:inline-flex}.iui-code-filename{color:var(--iui-muted);white-space:nowrap;text-overflow:ellipsis;font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;font-size:12px;font-weight:500;overflow:hidden}.iui-code-controls{align-items:center;gap:4px;display:flex}.iui-code-btn{all:unset;color:var(--iui-muted);cursor:pointer;background:0 0;border-radius:6px;justify-content:center;align-items:center;gap:4px;padding:4px 8px;font-size:11.5px;font-weight:500;transition:background-color .16s cubic-bezier(.2,.8,.2,1),color .16s cubic-bezier(.2,.8,.2,1);display:inline-flex}.iui-code-btn:hover{background-color:var(--iui-border);color:var(--iui-text)}.iui-code-btn:focus-visible{outline:2px solid var(--iui-text)}.iui-code-btn.is-active{color:var(--iui-text);background-color:var(--iui-border)}.iui-code-btn.is-copied{color:#10b981}.iui-code-wrap{background-color:var(--iui-bg);font-family:var(--iui-mono,ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace);font-size:12.5px;line-height:1.6;position:relative;overflow-x:auto}.iui-code-pre{white-space:pre;margin:0;padding:12px 0}.iui-code-pre.is-wrapped{white-space:pre-wrap;word-break:break-word}.iui-code-line{min-height:20px;padding:0 14px 0 0;display:flex}.iui-code-line:hover{background-color:var(--iui-surface)}.iui-code-line-num{text-align:right;width:44px;color:var(--iui-muted);opacity:.5;-webkit-user-select:none;user-select:none;flex-shrink:0;padding-right:12px;font-size:11px}.iui-code-line-content{flex:1;min-width:0}.iui-root[data-theme=light] .token-keyword,.iui-root:not([data-theme=dark]) .token-keyword{color:#7c3aed;font-weight:600}.iui-root[data-theme=light] .token-string,.iui-root:not([data-theme=dark]) .token-string{color:#059669}.iui-root[data-theme=light] .token-comment,.iui-root:not([data-theme=dark]) .token-comment{color:#78716c;font-style:italic}.iui-root[data-theme=light] .token-number,.iui-root:not([data-theme=dark]) .token-number{color:#d97706}.iui-root[data-theme=light] .token-function,.iui-root:not([data-theme=dark]) .token-function{color:#2563eb}.iui-root[data-theme=light] .token-boolean,.iui-root:not([data-theme=dark]) .token-boolean{color:#ea580c;font-weight:600}.iui-root[data-theme=light] .token-operator,.iui-root:not([data-theme=dark]) .token-operator{color:#64748b}.iui-root[data-theme=light] .token-tag,.iui-root:not([data-theme=dark]) .token-tag{color:#dc2626;font-weight:600}.iui-root[data-theme=light] .token-attr-name,.iui-root:not([data-theme=dark]) .token-attr-name{color:#d97706}.iui-root[data-theme=light] .token-attr-value,.iui-root:not([data-theme=dark]) .token-attr-value{color:#059669}.iui-root[data-theme=light] .token-property,.iui-root:not([data-theme=dark]) .token-property{color:#2563eb}.iui-root[data-theme=light] .token-variable,.iui-root:not([data-theme=dark]) .token-variable{color:#b45309}.iui-root[data-theme=dark] .token-keyword{color:#c6b9f2;font-weight:600}.iui-root[data-theme=dark] .token-string{color:#a6dec0}.iui-root[data-theme=dark] .token-comment{color:#8f8f8b;font-style:italic}.iui-root[data-theme=dark] .token-number{color:#f2dc8a}.iui-root[data-theme=dark] .token-function{color:#a9d3f5}.iui-root[data-theme=dark] .token-boolean{color:#f6c0a0;font-weight:600}.iui-root[data-theme=dark] .token-operator{color:#94a3b8}.iui-root[data-theme=dark] .token-tag{color:#f2b1c0;font-weight:600}.iui-root[data-theme=dark] .token-attr-name{color:#f2dc8a}.iui-root[data-theme=dark] .token-attr-value{color:#a6dec0}.iui-root[data-theme=dark] .token-property{color:#a9d3f5}.iui-root[data-theme=dark] .token-variable{color:#f6c0a0}',Rd=".iui-generic-card{box-sizing:border-box;background:0 0;border:0;border-radius:0;padding:0}.iui-generic-content{flex-direction:column;gap:12px;margin-top:6px;display:flex}.iui-generic-grid{grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px;display:grid}.iui-generic-row{border:0;border-bottom:1px solid var(--iui-border);box-sizing:border-box;background:0 0;border-radius:0;flex-direction:column;gap:3px;padding:8px 0;display:flex}.iui-generic-row.full-width{grid-column:1/-1}.iui-generic-label{color:var(--iui-muted);font-size:12px;font-weight:500;line-height:1.3}.iui-generic-value{color:var(--iui-text);word-break:break-word;font-size:14px;line-height:1.45}.iui-generic-chips{flex-wrap:wrap;gap:6px;margin-top:4px;display:flex}.iui-generic-chip{background-color:var(--iui-surface-2);color:var(--iui-text);border:1px solid var(--iui-border);border-radius:6px;align-items:center;padding:3px 9px;font-size:12px;display:inline-flex}.iui-generic-list{color:var(--iui-text);margin:4px 0 0 18px;padding:0;font-size:13.5px;line-height:1.5}.iui-generic-subcard{background:0 0;border:0;border-radius:0;flex-direction:column;gap:6px;padding:10px 0;display:flex}.iui-show-source-btn{border:1px solid var(--iui-border);background-color:var(--iui-surface);color:var(--iui-text);cursor:pointer;-webkit-user-select:none;user-select:none;border-radius:6px;align-items:center;gap:6px;padding:5px 12px;font-family:inherit;font-size:12px;font-weight:500;transition:background-color .14s;display:inline-flex}.iui-show-source-btn:hover{background-color:var(--iui-surface-2)}.iui-fallback-collapsed{flex-direction:column;align-items:flex-start;gap:8px;padding:6px 0;display:flex}",Pd=".iui-chart-card{gap:10px;overflow:visible}.iui-chart-card>.iui-title{margin:0;padding:0 2px;font-size:13.5px;font-weight:600;line-height:1.4}.iui-chart-controls{justify-content:flex-end;align-items:center;gap:8px;display:flex}.iui-chart-view-switch{background-color:var(--iui-surface);border:1px solid color-mix(in srgb, var(--iui-text,#000) 12%, transparent);border-radius:7px;align-items:center;gap:2px;padding:2px;display:inline-flex}.iui-chart-view-btn{all:unset;color:var(--iui-muted);cursor:pointer;white-space:nowrap;border-radius:5px;padding:3px 10px;font-size:11.5px;font-weight:500;transition:color .14s,background-color .14s}.iui-chart-view-btn:hover{color:var(--iui-text)}.iui-chart-view-btn.is-active{background-color:var(--iui-bg);color:var(--iui-text);border:1px solid color-mix(in srgb, var(--iui-text,#000) 12%, transparent);font-weight:600}.iui-chart-view-btn:focus-visible{outline:2px solid var(--iui-accent);outline-offset:1px}.iui-chart-table-view{margin-top:2px}.iui-chart-table-view .iui-table-card,.iui-table-chart-view .iui-chart-card{box-shadow:none;background:0 0;border:none;padding:0}.iui-chart-table-view .iui-table-card>.iui-title,.iui-table-chart-view .iui-chart-controls{display:none}.iui-chart-wrap{box-sizing:border-box;width:100%;min-width:0;padding:2px 0}.iui-chart-plot{--iui-chart-legend-offset:0px;width:100%;min-width:0;height:calc(clamp(240px, 32vw, 300px) + var(--iui-chart-legend-offset));box-sizing:border-box;background:0 0;border:none;padding:6px 4px 2px;position:relative}.iui-chart-plot[data-has-legend=true],[data-has-legend=true] .iui-chart-plot{--iui-chart-legend-offset:28px}.iui-chart-plot[data-chart-type=pie],.iui-chart-plot[data-chart-type=doughnut],[data-chart-type=pie] .iui-chart-plot,[data-chart-type=doughnut] .iui-chart-plot{height:calc(clamp(220px, 28vw, 270px) + var(--iui-chart-legend-offset))}.iui-root .iui-modal-container .iui-chart-plot{height:clamp(320px,50vh,460px);padding:8px 6px 4px}.iui-chart-plot canvas{width:100%;max-width:100%;display:block}@container iui (width<=520px){.iui-chart-card{gap:8px}.iui-chart-plot{height:calc(clamp(220px, 46vw, 270px) + var(--iui-chart-legend-offset));padding:4px 2px 2px}.iui-chart-plot[data-chart-type=pie],.iui-chart-plot[data-chart-type=doughnut],[data-chart-type=pie] .iui-chart-plot,[data-chart-type=doughnut] .iui-chart-plot{height:calc(clamp(200px, 42vw, 250px) + var(--iui-chart-legend-offset))}}",Vd=".iui-checklist-card{border-radius:var(--iui-radius-card,12px)}.iui-checklist-header{justify-content:space-between;align-items:center;gap:12px;margin-bottom:14px;display:flex}.iui-checklist-heading{min-width:0}.iui-checklist-title{margin:0 0 4px}.iui-checklist-count{color:var(--iui-muted);font-variant-numeric:tabular-nums;font-size:12px;font-weight:500}.iui-checklist-bulk{border-radius:999px;flex:none;padding:7px 12px;font-size:12px}.iui-checklist-progress-track{background:var(--iui-surface-2);border-radius:999px;height:7px;margin-bottom:14px;overflow:hidden}.iui-checklist-progress-fill{border-radius:inherit;background:var(--c-ink,var(--iui-accent,#4c3d91));width:0;height:100%;transition:width .18s}.iui-checklist-items{flex-direction:column;gap:7px;display:flex}.iui-checklist-row{border:0;border-bottom:1px solid var(--iui-border);cursor:pointer;animation:.18s both iui-checklist-enter;animation-delay:calc(var(--checklist-index,0) * 25ms);background:0 0;border-radius:0;align-items:flex-start;gap:11px;padding:10px 2px;transition:border-color .14s,background-color .14s;display:flex;position:relative}@keyframes iui-checklist-enter{0%{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}.iui-checklist-row:hover{background:var(--iui-surface)}.iui-checklist-row:focus-within{outline:2px solid var(--iui-text);outline-offset:2px}.iui-checklist-input{opacity:0;pointer-events:none;width:1px;height:1px;position:absolute}.iui-checklist-box{border:1.5px solid var(--iui-muted);color:#0000;background:var(--iui-bg);border-radius:6px;flex:0 0 19px;justify-content:center;align-items:center;width:19px;height:19px;margin-top:1px;transition:background-color .14s,border-color .14s,color .14s;display:inline-flex}.iui-checklist-box svg{width:13px;height:13px}.iui-checklist-row.is-checked .iui-checklist-box{border-color:var(--c-ink,var(--iui-accent,#4c3d91));background:var(--c-ink,var(--iui-accent,#4c3d91));color:#fff}.iui-checklist-copy{flex-direction:column;flex:1;gap:3px;min-width:0;display:flex}.iui-checklist-text{color:var(--iui-text);font-size:13.5px;font-weight:600;line-height:1.4}.iui-checklist-detail{color:var(--iui-muted);font-size:12px;line-height:1.45}.iui-checklist-row.is-checked .iui-checklist-text{color:var(--iui-muted);text-decoration:line-through;text-decoration-thickness:1px}.iui-checklist-card.is-complete .iui-checklist-progress-fill{background:var(--iui-success,#39966b)}@media (prefers-reduced-motion:reduce){.iui-checklist-row{animation:none}.iui-checklist-progress-fill,.iui-checklist-box{transition:none}}",Hd=".iui-form-card{border-radius:var(--iui-radius-card,12px)}.iui-form-title{margin-bottom:6px}.iui-form-description{color:var(--iui-muted);margin:0 0 18px;font-size:13px;line-height:1.5}.iui-form{flex-direction:column;gap:15px;display:flex}.iui-form-field{flex-direction:column;gap:7px;min-width:0;display:flex}.iui-form-label{color:var(--iui-text);font-size:13px;font-weight:600}.iui-form-required{color:var(--iui-danger,#d45b66)}.iui-form-control{box-sizing:border-box;border:1px solid var(--iui-border);background:var(--iui-bg);width:100%;min-height:40px;color:var(--iui-text);font:inherit;border-radius:10px;outline:none;padding:9px 11px;font-size:13px}.iui-form-control:focus{border-color:var(--iui-text);box-shadow:0 0 0 2px color-mix(in srgb, var(--iui-text) 12%, transparent)}.iui-form-field textarea.iui-form-control{resize:vertical;min-height:88px}.iui-form-help{color:var(--iui-muted);font-size:11.5px;line-height:1.45}.iui-form-radio-group{flex-wrap:wrap;gap:8px;display:flex}.iui-form-choice{border:1px solid var(--iui-border);min-height:36px;color:var(--iui-text);background:var(--iui-surface);cursor:pointer;border-radius:9px;align-items:center;gap:8px;padding:7px 11px;font-size:12.5px;display:inline-flex}.iui-form-choice:focus-within{outline:2px solid var(--iui-accent);outline-offset:1px}.iui-form-choice:focus-visible{outline:2px solid var(--iui-accent);outline-offset:1px}.iui-form-choice:has(input:checked){border-color:var(--iui-text);background:var(--iui-surface-2)}.iui-form-choice input{accent-color:var(--iui-text);margin:0}.iui-form-single-choice{align-self:flex-start}.iui-form-range-wrap{align-items:center;gap:12px;display:flex}.iui-form-range-wrap input{min-width:0;accent-color:var(--iui-text);flex:1}.iui-form-range-value{min-width:34px;color:var(--iui-text);font-variant-numeric:tabular-nums;text-align:right;font-size:12px}.iui-form-actions{flex-wrap:wrap;gap:8px;padding-top:3px;display:flex}.iui-form-submit{min-width:110px}.iui-form-result{border:1px solid var(--iui-border);background:var(--iui-surface);border-radius:12px;margin-top:16px;padding:14px}.iui-form-result[hidden]{display:none}.iui-form-result-heading{color:var(--iui-text);align-items:center;gap:8px;font-size:13px;display:flex}.iui-form-result-list{grid-template-columns:minmax(100px,.7fr) minmax(0,1.3fr);gap:8px 12px;margin:12px 0;font-size:12px;display:grid}.iui-form-result-list dt{color:var(--iui-muted)}.iui-form-result-list dd{min-width:0;color:var(--iui-text);overflow-wrap:anywhere;margin:0}.iui-form-copy{font-size:12px}@media (max-width:480px){.iui-form-result-list{grid-template-columns:1fr;gap:3px}.iui-form-result-list dd{margin-bottom:7px}}",Wd=".iui-dashboard-card,.iui-image-card,.iui-heatmap-card,.iui-geo-card{min-width:0}.iui-dashboard-grid{grid-template-columns:repeat(auto-fit,minmax(min(100%,300px),1fr));align-items:start;gap:20px 24px;display:grid}.iui-dashboard-panel{border-top:1px solid var(--iui-border);min-width:0;padding-top:10px}.iui-dashboard-panel-title{color:var(--iui-muted);margin:0 0 8px;font-size:11px;font-weight:600;line-height:1.35}.iui-dashboard-visual.iui-card{width:100%;min-width:0;box-shadow:none;background:0 0;border:0;border-radius:0;flex-direction:column;padding:0;display:flex}.iui-dashboard-visual .iui-chart-plot{height:calc(clamp(210px, 28vw, 260px) + var(--iui-chart-legend-offset,0px))}.iui-image-figure{flex-direction:column;gap:7px;min-width:0;margin:0;display:flex}.iui-image{background:var(--iui-surface);border-radius:8px;width:100%;max-height:420px;display:block}.iui-image-figure.aspect-wide .iui-image{aspect-ratio:16/9}.iui-image-figure.aspect-square .iui-image{aspect-ratio:1}.iui-image-figure.aspect-portrait .iui-image{aspect-ratio:3/4;max-height:520px}.iui-image-caption{color:var(--iui-muted);font-size:12px;line-height:1.45}.iui-heatmap-grid{grid-template-columns:minmax(84px, 1.25fr) repeat(var(--iui-heatmap-columns), minmax(44px, 1fr));gap:5px;min-width:0;padding-bottom:4px;font-size:11px;display:grid;overflow-x:auto}.iui-heatmap-corner{min-width:0}.iui-heatmap-col-label,.iui-heatmap-row-label{color:var(--iui-muted);text-align:center;text-overflow:ellipsis;white-space:nowrap;padding:5px 4px;font-size:11px;line-height:1.3;overflow:hidden}.iui-heatmap-row-label{text-align:left;font-weight:600}.iui-heatmap-cell{font-variant-numeric:tabular-nums;border-radius:5px;place-items:center;min-height:32px;padding:2px 4px;font-size:10.5px;font-weight:500;display:grid}.iui-heatmap-legend{color:var(--iui-muted);font-variant-numeric:tabular-nums;align-self:flex-end;align-items:center;gap:8px;margin-top:10px;font-size:10.5px;display:flex}.iui-heatmap-legend-bar{border:1px solid var(--iui-border);background:linear-gradient(90deg,#eff5fa,#7bd5ce);border-radius:5px;width:76px;height:8px}.iui-root[data-theme=dark] .iui-heatmap-legend-bar{background:linear-gradient(90deg,#1b3855,#4dc7bd)}.iui-geo-map{aspect-ratio:720/330;width:100%;height:auto;max-height:360px;margin-top:2px;display:block}.iui-geo-frame{fill:var(--iui-surface);stroke:var(--iui-border);stroke-width:1px}.iui-geo-graticule{stroke:var(--iui-border);stroke-width:1px;stroke-dasharray:2 5}.iui-geo-point{stroke:var(--iui-bg);stroke-width:2px;opacity:.88}.iui-geo-key{flex-wrap:wrap;align-items:center;gap:6px 14px;margin-top:10px;padding:2px 0;display:flex}.iui-geo-key-item{min-width:0;max-width:100%;color:var(--iui-muted);text-overflow:ellipsis;white-space:nowrap;align-items:center;gap:6px;font-size:11px;line-height:1.35;display:inline-flex;overflow:hidden}.iui-geo-key-dot{border-radius:50%;flex:0 0 7px;width:7px;height:7px}.iui-geo-key-more{color:var(--iui-muted);font-size:11px}@container iui (width<=520px){.iui-dashboard-grid{grid-template-columns:minmax(0,1fr);gap:16px}.iui-heatmap-grid{grid-template-columns:minmax(70px, 1fr) repeat(var(--iui-heatmap-columns), minmax(40px, 1fr));gap:4px}.iui-heatmap-cell{min-height:30px;font-size:10px}.iui-geo-key{gap:5px 10px}}",Ud=".iui-root .iui-card:not(.iui-dashboard-visual){box-sizing:border-box;box-shadow:none;border:0;border-radius:14px;background:#fff!important}.iui-root[data-theme=dark] .iui-card:not(.iui-dashboard-visual){background:#09090b!important}.iui-root .iui-card>.iui-title{color:var(--iui-text);letter-spacing:-.01em;margin:0 0 10px;font-size:14px;font-weight:650;line-height:1.4}.iui-root .iui-chart-table-view .iui-table-card,.iui-root .iui-table-chart-view .iui-chart-card{box-shadow:none;border:0;padding:0;background:0 0!important}.iui-root .iui-chart-table-view .iui-table-card>.iui-title,.iui-root .iui-table-chart-view .iui-chart-card .iui-chart-controls{display:none}.iui-root .iui-card :-webkit-any(button,input,select,textarea):focus-visible{outline:2px solid var(--iui-accent,var(--iui-text));outline-offset:2px}.iui-root .iui-card :is(button,input,select,textarea):focus-visible{outline:2px solid var(--iui-accent,var(--iui-text));outline-offset:2px}.iui-root[data-theme=dark] .iui-card{--lightningcss-light: ;--lightningcss-dark:initial;color-scheme:dark}.iui-root:not([data-theme=dark]) .iui-card{--lightningcss-light:initial;--lightningcss-dark: ;color-scheme:light}.iui-root .iui-compare-panel{min-width:0;padding:10px 16px}.iui-root .iui-compare-panel+.iui-compare-panel{border-left-color:color-mix(in srgb, var(--iui-text) 9%, transparent)}.iui-root .iui-stepper-card .iui-stepper-list{gap:14px}.iui-root .iui-stepper-card .iui-stepper-step{gap:12px;min-width:0}.iui-root .iui-stepper-card .iui-stepper-circle{width:24px;height:24px;font-size:11px}.iui-root .iui-stepper-card .iui-stepper-track{width:24px}.iui-root .iui-stats-grid{gap:18px 28px}.iui-root .iui-stat-item{min-width:min(100%,96px)}.iui-root .iui-stat-value{letter-spacing:-.035em;font-size:clamp(20px,2.5vw,25px)}.iui-root .iui-table-card,.iui-root .iui-chart-card,.iui-root .iui-tree-card,.iui-root .iui-compare-card,.iui-root .iui-stepper-card,.iui-root .iui-stats-card,.iui-root .iui-tabs-card,.iui-root .iui-checklist-card,.iui-root .iui-quiz-card,.iui-root .iui-form-card,.iui-root .iui-callout-card,.iui-root .iui-math-card,.iui-root .iui-generic-card,.iui-root .iui-dashboard-card,.iui-root .iui-image-card{min-width:0}@container iui (width<=520px){.iui-root .iui-card:not(.iui-dashboard-visual){border-radius:12px}.iui-root .iui-compare-panel{padding:10px 0}.iui-root .iui-stats-grid{gap:14px 20px}}",Gd=[Md,Td,Ld,zd,_d,Bd,Id,Fd,$d,jd,Nd,qd,Od,Dd,Rd,Pd,Vd,Hd,Wd,Ud],Ue=[Ad,...Gd],Bt=null;function Yd(e){try{if(typeof CSSStyleSheet<"u"&&"replaceSync"in CSSStyleSheet.prototype){Bt||(Bt=Ue.map(t=>{const i=new CSSStyleSheet;return i.replaceSync(t),i})),e.adoptedStyleSheets=Bt;return}}catch{}for(const t of Ue){const i=document.createElement("style");i.textContent=t,e.appendChild(i)}}function Kd(e,t){const i=u("div",{class:"iui-host","data-iui":"1"});t.insert==="inside"?e.appendChild(i):t.insert==="before"?e.parentNode?e.parentNode.insertBefore(i,e):e.appendChild(i):e.parentNode?e.parentNode.insertBefore(i,e.nextSibling):e.appendChild(i);const n=i.attachShadow({mode:"open"});Yd(n);let o=t.theme;const r={class:"iui-root","data-theme":o};t.host&&(r["data-host"]=t.host);const a=u("div",r);n.appendChild(a);const s=mi(e);vi(a,t.host,o,s);let l="skeleton",c=[],d=null,p=null,h="",f="",g=null,b="",m=!1,C=null,v=null,w=!0;ti().then(j=>{w=j.watermark!==!1}).catch(()=>{}),c.push(Wn(j=>{w=j.watermark!==!1}));function x(){for(const j of c)try{j()}catch($){console.error("Error during render cleanup:",$)}c=[]}async function y(j){try{if(typeof navigator<"u"&&navigator.clipboard?.writeText){await navigator.clipboard.writeText(j);return}}catch{}const $=document.createElement("textarea");$.value=j,$.setAttribute("readonly",""),$.style.position="fixed",$.style.opacity="0",$.style.pointerEvents="none",document.body.appendChild($),$.select();const _=typeof document.execCommand=="function"&&document.execCommand("copy");if($.remove(),!_)throw new Error("Clipboard access is unavailable")}function k(j,$,_,I){const M=bt[j.type]||{icon:"sparkle",color:"stone",label:"UI"};if(M.color,j.type==="callout"){const Z=j.tone}const q=u("div",{class:"iui-card-header"}),V=u("div",{class:"iui-header-left"}),U=u("div",{class:"iui-type-iconbox","aria-hidden":"true"},io(j.type,16));V.appendChild(U);const G=u("div",{class:"iui-title-group"}),te=u("div",{class:"iui-title",role:"heading","aria-level":"3"},$||M.label);G.appendChild(te);const H=j,J=H.subtitle||H.sub;J&&G.appendChild(u("div",{class:"iui-sub"},String(J))),V.appendChild(G),q.appendChild(V);const oe=u("div",{class:"iui-card-toolbar"}),ae=u("span",{class:"iui-tooltip",role:"tooltip"},"Copy data"),fe=u("button",{class:"iui-tool-btn",type:"button","aria-label":"Copy data",onClick:async Z=>{Z.stopPropagation();try{await y(h),de(fe),fe.appendChild(K("check",16)),ae.textContent="Copied",fe.appendChild(ae),setTimeout(()=>{de(fe),fe.appendChild(K("copy",16)),ae.textContent="Copy data",fe.appendChild(ae)},1500)}catch{}}},K("copy",16),ae),ue=u("div",{class:"iui-export-wrap"}),ie=u("div",{class:"iui-export-menu is-hidden",role:"menu"});function ve(Z){if(Z.key==="Escape"){Z.preventDefault(),Z.stopPropagation(),he(),Y.focus();return}if(Z.key==="ArrowDown"||Z.key==="ArrowUp"){Z.preventDefault(),Z.stopPropagation();const ne=Array.from(ie.querySelectorAll(".iui-export-item"));if(ne.length===0)return;const ke=n.activeElement||document.activeElement,Qe=ke?ne.indexOf(ke):-1;ne[Z.key==="ArrowDown"?(Qe+1)%ne.length:(Qe-1+ne.length)%ne.length].focus()}}function he(){ie.classList.add("is-hidden"),Y.setAttribute("aria-expanded","false"),oe.classList.remove("is-open"),document.removeEventListener("click",he),ie.removeEventListener("keydown",ve)}function Me(){if(ie.classList.contains("is-hidden")){de(ie);const Z=_(),ne=Z?["flow","mermaid","chart"].includes(Z.type):!1;if(Z?.type==="table"){const Se=u("button",{class:"iui-export-item",type:"button",role:"menuitem",onClick:async be=>{be.stopPropagation(),he();const Be=I();try{await y(so(Z.columns||[],Z.rows||[])),Be&&Ae(Be,"Table values copied")}catch{Be&&Ae(Be,"Could not access clipboard")}}},K("table",16,"iui-export-item-icon"),document.createTextNode("Copy table values"));ie.appendChild(Se)}const ke=u("button",{class:"iui-export-item",type:"button",role:"menuitem",onClick:async Se=>{Se.stopPropagation(),he();const be=I();be&&await vt(be,"copy",{watermark:w,theme:o,allStyles:Ue,cardType:Z?.type,title:Z?.title,host:t.host})}},K("image",16,"iui-export-item-icon"),document.createTextNode("Copy as image")),Qe=u("button",{class:"iui-export-item",type:"button",role:"menuitem",onClick:async Se=>{Se.stopPropagation(),he();const be=I();be&&await vt(be,"png",{watermark:w,theme:o,allStyles:Ue,cardType:Z?.type,title:Z?.title,host:t.host})}},K("download-simple",16,"iui-export-item-icon"),document.createTextNode("Download PNG")),Do=u("button",{class:"iui-export-item",type:"button",role:"menuitem",onClick:async Se=>{Se.stopPropagation(),he();try{await y(h);const be=I();be&&Ae(be,"JSON copied \u2713")}catch{}}},K("code",16,"iui-export-item-icon"),document.createTextNode("Copy JSON"));if(ie.appendChild(ke),ie.appendChild(Qe),ie.appendChild(Do),ne){const Se=u("button",{class:"iui-export-item",type:"button",role:"menuitem",onClick:async be=>{be.stopPropagation(),he();const Be=I();Be&&await vt(Be,"svg",{watermark:w,theme:o,allStyles:Ue,cardType:Z?.type,title:Z?.title,host:t.host})}},K("code",16,"iui-export-item-icon"),document.createTextNode("Download SVG"));ie.appendChild(Se)}ie.classList.remove("is-hidden"),Y.setAttribute("aria-expanded","true"),oe.classList.add("is-open"),ie.addEventListener("keydown",ve),setTimeout(()=>{document.addEventListener("click",he)},10)}else he()}const T=u("span",{class:"iui-tooltip",role:"tooltip"},"Export card"),Y=u("button",{class:"iui-tool-btn",type:"button","aria-label":"Export card","aria-haspopup":"menu","aria-expanded":"false",onClick:Z=>{Z.stopPropagation(),Me()},onKeydown:Z=>{const ne=Z;ne.key==="ArrowDown"&&ie.classList.contains("is-hidden")?(ne.preventDefault(),ne.stopPropagation(),Me(),ie.querySelector(".iui-export-item")?.focus()):ne.key==="Escape"&&!ie.classList.contains("is-hidden")&&(ne.preventDefault(),ne.stopPropagation(),he())}},K("export",16),T);ue.appendChild(Y),ue.appendChild(ie);const W=u("span",{class:"iui-tooltip",role:"tooltip"},"View source"),re=u("button",{class:"iui-tool-btn",type:"button","aria-label":"View source","aria-expanded":"false",onClick:Z=>{Z.stopPropagation(),ge.classList.contains("is-collapsed")?(ge.classList.remove("is-collapsed"),re.setAttribute("aria-expanded","true"),oe.classList.add("is-open")):(ge.classList.add("is-collapsed"),re.setAttribute("aria-expanded","false"),oe.classList.remove("is-open"))}},K("code",16),W),se=u("span",{class:"iui-tooltip",role:"tooltip"},"Expand"),pe=u("button",{class:"iui-tool-btn",type:"button","aria-label":"Expand card",onClick:Z=>{Z.stopPropagation(),A(pe,_)}},K("arrows-out",16),se);oe.appendChild(fe),oe.appendChild(ue),oe.appendChild(re),oe.appendChild(pe),q.appendChild(oe);const ge=u("div",{class:"iui-source-panel is-collapsed"}),le=u("pre",{class:"iui-source-pre"},h);return ge.appendChild(le),{header:q,sourcePanel:ge,sourcePre:le}}function A(j,$){v&&(v(),v=null),C&&(C.remove(),C=null);const _=$();if(!_)return;const I=[],M=u("div",{class:"iui-modal-overlay",role:"dialog","aria-modal":"true","aria-label":_.title||"Expanded view"}),q=u("div",{class:"iui-modal-backdrop",onClick:()=>ae()});M.appendChild(q);const V=u("div",{class:"iui-modal-container"}),U=u("div",{class:"iui-modal-header"}),G=u("div",{class:"iui-title"},_.title||"Expanded view");U.appendChild(G);const te=u("span",{class:"iui-modal-esc-hint","aria-hidden":"true"},"Esc");U.appendChild(te);const H=u("button",{class:"iui-modal-close",type:"button","aria-label":"Close dialog",onClick:()=>ae()},K("x",14));U.appendChild(H),V.appendChild(U);const J=u("div",{class:"iui-modal-body"});try{const ue={theme:o,host:t.host,onCleanup(ve){I.push(ve)}},ie=Xt[_.type];if(ie){const ve=ie(_,ue);J.appendChild(ve)}}catch{}V.appendChild(J),M.appendChild(V);function oe(){document.removeEventListener("keydown",fe);for(const ue of I)try{ue()}catch(ie){console.error("Error during modal cleanup:",ie)}I.length=0}function ae(){oe(),v=null,M.remove(),C=null,j.focus()}function fe(ue){if(ue.key==="Escape"){ue.preventDefault(),ae();return}if(ue.key==="Tab"){const ie=Array.from(V.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')).filter(T=>!T.matches(":disabled")&&!T.closest('[hidden], [inert], [aria-hidden="true"]'));if(ie.length===0)return;const ve=ie[0],he=ie[ie.length-1],Me=a.getRootNode().activeElement??document.activeElement;ue.shiftKey&&Me===ve?(ue.preventDefault(),he.focus()):!ue.shiftKey&&Me===he&&(ue.preventDefault(),ve.focus())}}document.addEventListener("keydown",fe),a.appendChild(M),C=M,v=oe,H.focus()}function S(j){const $=u("div",{class:"iui-card iui-skeleton-card",style:"height: 120px; min-height: 120px; max-height: 120px; overflow: hidden; box-sizing: border-box; display: flex; flex-direction: column; justify-content: space-between; padding: 14px;"}),_=u("div",{class:"iui-skel-header",style:"display: flex; align-items: center; gap: 8px;"}),I=u("div",{class:"iui-skel",style:"width: 22px; height: 22px; border-radius: 6px; flex-shrink: 0;"}),M=u("span",{class:"iui-skel-label",style:"font-size: 12px; font-weight: 500; color: var(--iui-muted, #737373);"},j?bt[j]?.label||j:"UI block");_.appendChild(I),_.appendChild(M),$.appendChild(_);const q=u("div",{style:"display: flex; flex-direction: column; gap: 8px;"}),V=u("div",{class:"iui-skel iui-skel-line",style:"width: 85%; height: 14px; margin: 0;"}),U=u("div",{class:"iui-skel iui-skel-line",style:"width: 55%; height: 14px; margin: 0;"});return q.appendChild(V),q.appendChild(U),$.appendChild(q),$}function E(j){if(l==="skeleton"){const I=a.querySelector(".iui-skeleton-card");if(I){if(j){const M=I.querySelector(".iui-skel-label");M&&(M.textContent=bt[j]?.label||j)}return}}x(),de(a);const $=u("div",{class:"iui-rendered-wrap"}),_=S(j);$.appendChild(_),a.appendChild($),l="skeleton",t.onStateChange?.("skeleton")}function z(j,$){x(),de(a);let _=!1;const I=u("pre",{class:"iui-fallback-pre"},$);I.style.display="none";const M=u("button",{type:"button",class:"iui-show-source-btn",onClick:()=>{_=!_,I.style.display=_?"":"none",M.textContent=_?"Hide source":"Show source"}},"Show source"),q=u("div",{class:"iui-fallback iui-fallback-collapsed"},M,I);a.appendChild(q),l="fallback",t.onStateChange?.("fallback")}function L(j,$){x();try{const _={theme:o,host:t.host,onCleanup(oe){c.push(oe)}},I=Xt[j.type];if(!I)throw new Error(`No renderer for type: ${j.type}`);const M=I(j,_),q=M.querySelector(".iui-title"),V=j.title||q?.textContent||"";q&&q.remove();const{header:U,sourcePanel:G,sourcePre:te}=k(j,V,()=>g,()=>M);m||M.setAttribute("data-animate","enter");const H=u("div",{class:"iui-card-body"});for(;M.firstChild;)H.appendChild(M.firstChild);M.appendChild(U),M.appendChild(G),M.appendChild(H);const J=u("div",{class:"iui-rendered-wrap"});J.appendChild(M),de(a),a.appendChild(J),l="rendered",m=!0,t.onStateChange?.("rendered"),g=j,b=JSON.stringify(j)}catch(_){const I=_ instanceof Error?_.message:String(_);m?R():z(I,$)}}let F=0,B=null,O=null,D="";function P(j,$){const _=Date.now(),I=_-F;I>=250?(B!==null&&(window.clearTimeout(B),B=null),O=null,F=_,L(j,$)):(O=j,D=$,B===null&&(B=window.setTimeout(()=>{if(B=null,O){F=Date.now();const M=O,q=D;O=null,L(M,q)}},250-I)))}function R(){if(!m||a.querySelector(".iui-partial-error-note"))return;const j=u("div",{class:"iui-partial-error-note"},"Some content couldn't be shown \u00b7 ",u("button",{class:"iui-partial-source-link",type:"button",onClick:()=>{const _=a.querySelector(".iui-source-panel");_&&_.classList.toggle("is-collapsed")}},"View source")),$=a.querySelector(".iui-card");$?$.appendChild(j):a.appendChild(j)}let Q=!1;if(t.initialText){p=t.initialText,h=t.initialText;const j=qe(t.initialText);if(j.ok&&typeof j.value=="object"&&j.value!==null){const $=ze(j.value);$.ok&&(L($.spec,t.initialText),Q=!0)}}Q||E();function ee(){if(d!==null&&(window.clearTimeout(d),d=null),B!==null&&(window.clearTimeout(B),B=null,O)){const _=O,I=D;O=null,L(_,I);return}let j=null;const $=qe(h);if($.ok&&typeof $.value=="object"&&$.value!==null){const _=ze($.value);_.ok&&(j=_.spec)}if(!j){const _=yi(h);if(_.ok&&_.value&&typeof _.value=="object"){const I=ze(_.value);I.ok&&(j=I.spec)}}if(!j&&$.ok&&typeof $.value=="object"&&$.value!==null&&!Array.isArray($.value)){const _=$.value;j={type:"generic",title:typeof _.title=="string"?_.title:void 0,originalType:typeof _.type=="string"?_.type:void 0,data:_}}if(j){L(j,h);return}m?R():z(f||"Could not parse or validate UI block",h)}function X(j){if(l==="rendered"){let _=null;const I=qe(j);if(I.ok&&typeof I.value=="object"&&I.value!==null){const M=ze(I.value);M.ok&&(_=M.spec)}if(!_){const M=yi(j);if(M.ok&&M.value&&typeof M.value=="object"){const q=ze(M.value);q.ok&&(_=q.spec)}}if(_)if(JSON.stringify(_)!==b)P(_,j);else{const M=a.querySelector(".iui-source-pre");M&&(M.textContent=j)}return}const $=qe(j);if($.ok&&typeof $.value=="object"&&$.value!==null){const _=ze($.value);if(_.ok){f="",L(_.spec,j);return}else f=_.error}else f="Parsing JSON";E(It(j))}return{update(j){j!==p&&(p=j,h=j,d!==null&&window.clearTimeout(d),d=window.setTimeout(()=>{ee()},1500),X(j))},finalize:ee,setTheme(j){o=j,a.setAttribute("data-theme",j);const $=mi(e);vi(a,t.host,j,$),l==="rendered"&&g&&L(g,h)},destroy(){d!==null&&(window.clearTimeout(d),d=null),B!==null&&(window.clearTimeout(B),B=null),v&&(v(),v=null),C&&(C.remove(),C=null),x(),i.remove()},get state(){return l}}}var We=new Map;function _n(e){if(We.set(e,!0),We.size>200){const t=We.keys().next().value;t!==void 0&&We.delete(t)}}function Xd(e,t,i){let n=i??e.chatRoot();const o=new WeakMap,r=new Set,a=new Set;let s=null,l=null,c=0,d=!1,p=!1;function h(y,k,A=!0){k.finalizeTimer!==void 0&&(window.clearTimeout(k.finalizeTimer),k.finalizeTimer=void 0),k.target.style.display="",k.target.removeAttribute("data-iui-hidden"),k.target.removeAttribute("data-betterview-handled"),y.removeAttribute("data-betterview-handled"),k.handle.destroy(),r.delete(k.handle);const S=e.languageOf(y);if(A&&(S==="ui"||A)&&!k.noteHost&&k.target.parentNode){const E=document.createElement("div");E.className="iui-host",E.setAttribute("data-iui","1");const z=E.attachShadow({mode:"open"}),L=document.createElement("div");L.className="iui-root",L.setAttribute("data-theme",t());const F=document.createElement("div");F.className="iui-fallback-note",F.style.fontSize="12.5px",F.style.color="var(--iui-muted, #6B6B6B)",F.style.margin="8px 0",F.textContent="Couldn't render this UI block",L.appendChild(F),z.appendChild(L),k.target.parentNode.insertBefore(E,k.target),k.noteHost=E}}function f(){if(p||!n&&(n=i??e.chatRoot(),!n))return;for(const k of Array.from(a))if(!document.contains(k)){const A=o.get(k);A&&(A.finalizeTimer!==void 0&&window.clearTimeout(A.finalizeTimer),A.handle.destroy(),A.noteHost?.remove(),r.delete(A.handle)),o.delete(k),a.delete(k)}const y=e.findCodeBlocks(n);for(const k of y){if(k.closest(".iui-host")||k.closest("[data-iui]"))continue;if(o.has(k)){const R=o.get(k),Q=Ft(e,k);if(Q!==R.lastText){R.lastText=Q;const ee=$t(Q,e.languageOf(k));R.handle.update(ee?pi(ee):Q),R.finalizeTimer!==void 0&&window.clearTimeout(R.finalizeTimer),R.finalizeTimer=window.setTimeout(()=>{if(R.handle.state==="fallback"){const X=e.languageOf(k);h(k,R,X==="ui")}},1600)}continue}const A=e.wrapperOf(k);if(k.getAttribute("data-betterview-handled")==="1"||A.getAttribute("data-betterview-handled")==="1"||!tr(e,k))continue;const S=Ft(e,k),E=$t(S,e.languageOf(k)),z=E?pi(E):S,L=ei(A,k)?A:k;let F;if(We.has(S))F=z;else{const R=qe(z);R.ok&&typeof R.value=="object"&&R.value!==null&&ze(R.value).ok&&(F=z)}let B=null,O=!1;const D=Kd(L,{theme:t(),host:e.id,insert:"before",initialText:F,onStateChange:R=>{R==="fallback"&&!p?B?h(k,B):O=!0:R==="rendered"&&(B&&_n(B.lastText),B?.noteHost&&(B.noteHost.remove(),B.noteHost=void 0))}});D.state==="rendered"&&_n(S),L.style.display="none",L.setAttribute("data-iui-hidden","1"),L.setAttribute("data-betterview-handled","1"),k.setAttribute("data-betterview-handled","1");const P={handle:D,target:L,lastText:S};B=P,P.finalizeTimer=window.setTimeout(()=>{if(D.state==="fallback"){const R=e.languageOf(k);h(k,P,R==="ui")}},1600),o.set(k,P),r.add(D),a.add(k),O&&h(k,P),F||D.update(z)}}function g(){l===null&&(l=window.requestAnimationFrame(()=>{l=null,c=Date.now(),f(),n&&v(n)}))}function b(){if(p)return;const y=120-(Date.now()-c);y<=0?(s!==null&&(window.clearTimeout(s),s=null),d=!1,g()):(d=!0,s===null&&(s=window.setTimeout(()=>{s=null,d&&!p&&(d=!1,g())},y)))}const m=typeof MutationObserver<"u"?new MutationObserver(y=>{y.every(k=>{const A=k.target instanceof Element?k.target:k.target.parentElement;return A&&(A.closest(".iui-host")||A.closest("[data-iui]"))})||b()}):null,C=new Set;function v(y){if(!m)return;const k=A=>{A.querySelectorAll("*").forEach(S=>{S.shadowRoot&&!C.has(S.shadowRoot)&&(C.add(S.shadowRoot),m.observe(S.shadowRoot,{childList:!0,subtree:!0,characterData:!0}),k(S.shadowRoot))})};k(y)}m&&n&&(m.observe(n,{childList:!0,subtree:!0,characterData:!0}),v(n)),f();let w=typeof window<"u"?window.location.href:"";const x=window.setInterval(()=>{if(!(typeof window>"u")&&window.location.href!==w){w=window.location.href;for(const y of r)try{y.destroy()}catch{}r.clear();for(const y of Array.from(a)){const k=o.get(y);k&&(k.finalizeTimer!==void 0&&window.clearTimeout(k.finalizeTimer),k.target.style.display="",k.target.removeAttribute("data-iui-hidden"),k.target.removeAttribute("data-betterview-handled"),y.removeAttribute("data-betterview-handled"),k.noteHost?.remove())}a.clear(),m&&(m.disconnect(),C.clear()),n=i??e.chatRoot(),m&&n&&(m.observe(n,{childList:!0,subtree:!0,characterData:!0}),v(n),f())}},500);return{stop(){p=!0,s!==null&&(window.clearTimeout(s),s=null),l!==null&&(window.cancelAnimationFrame(l),l=null),d=!1,window.clearInterval(x),m&&m.disconnect();for(const y of r)try{y.destroy()}catch{}r.clear();for(const y of Array.from(a)){const k=o.get(y);k&&(k.finalizeTimer!==void 0&&window.clearTimeout(k.finalizeTimer),k.target.style.display="",k.target.removeAttribute("data-iui-hidden"),k.target.removeAttribute("data-betterview-handled"),y.removeAttribute("data-betterview-handled"),k.noteHost?.remove())}a.clear()},rescan(){f()},setTheme(y){for(const k of r)k.setTheme(y);for(const k of Array.from(a)){const A=o.get(k);if(A?.noteHost?.shadowRoot){const S=A.noteHost.shadowRoot.querySelector(".iui-root");S&&S.setAttribute("data-theme",y)}}}}}function Zd(e,t){let i="";const n=o=>{try{if(typeof window>"u"||!e.isNewChat(window.location)||window.location.href===i)return;const r=e.composer();if(!r)return;if(o instanceof KeyboardEvent){if(o.key!=="Enter"||o.shiftKey||o.altKey||o.ctrlKey||o.metaKey)return;const s=o.target;if(!s||!r.contains(s)&&s!==r)return}else if(o instanceof MouseEvent){const s=e.sendButton();if(!s)return;const l=o.target;if(!l||!s.contains(l)&&l!==s)return}else return;const a=t.slice(0,40);if(r instanceof HTMLTextAreaElement){if(r.value.startsWith(a))return;const s=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value");s&&s.set?s.set.call(r,t+`

`+r.value):r.value=t+`

`+r.value,r.dispatchEvent(new Event("input",{bubbles:!0})),i=window.location.href}else{if((r.textContent||"").trim().startsWith(a))return;r.focus();const s=window.getSelection();if(s){const l=document.createRange();l.setStart(r,0),l.collapse(!0),s.removeAllRanges(),s.addRange(l)}document.execCommand("insertText",!1,t+`

`),i=window.location.href}}catch{}};return document.addEventListener("keydown",n,!0),document.addEventListener("click",n,!0),()=>{document.removeEventListener("keydown",n,!0),document.removeEventListener("click",n,!0)}}var Bn=[{version:"v0.1.0",tagline:"First release: 7 visual components, works on Gemini and Grok, light and dark mode, one-click setup, works fully offline: no data leaves your browser.",date:"Launch release",highlights:["7 visual components: Flow diagrams, Step-by-step guides, Tables, Comparisons, Charts, Mermaid diagrams, Quizzes","Native rendering directly inside Gemini and Grok chat streams","Polished light and dark mode with system theme detection","One-click automated instruction setup and manual copy fallback","Privacy first: works fully offline with no external servers or tracking"]}];function In(e,t=4){return Math.min(e+1,t-1)}function Fn(e){return Math.max(e-1,0)}function Qd(e,t=4){return Math.max(0,Math.min(e,t-1))}function Jd(e){return!!(e.pendingTour&&!e.tourSeen)}function eu(e){return!!(e.pendingUpdateModal&&!e.updateModalSeen)}var Ge=null,Ye=null;function $n(e){return typeof chrome<"u"&&chrome.runtime?.getURL?chrome.runtime.getURL(e):"/"+e}function Zt(e=28,t){const i=$n("brand/mark-white.png"),n=$n("brand/mark-black.png"),o=u("div",{class:"bv-modal-mark-wrap",style:`width: ${e}px; height: ${e}px;`}),r=u("img",{class:"bv-mark-dark",src:i,alt:"BetterView AI",width:e,height:e}),a=u("img",{class:"bv-mark-light",src:n,alt:"BetterView AI",width:e,height:e});return t==="dark"?(r.style.display="block",a.style.display="none"):t==="light"&&(r.style.display="none",a.style.display="block"),o.appendChild(r),o.appendChild(a),o}function ct(){Ye&&(document.removeEventListener("keydown",Ye,!0),Ye=null),Ge&&(Ge.remove(),Ge=null)}var Oo=`
:host {
  all: initial;
  position: fixed;
  inset: 0;
  z-index: 2147483647;
  display: flex;
  align-items: center;
  justify-content: center;
  font-family: Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, system-ui, sans-serif;
  box-sizing: border-box;
}

*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

[data-theme="light"] {
  --bg: #FFFFFF;
  --surface: #FAFAFA;
  --surface-2: #F4F4F5;
  --border: #E8E8EA;
  --text: #0A0A0A;
  --muted: #6B6B70;
  --faint: #A1A1AA;
  --primary: #0A0A0A;
  --on-primary: #FFFFFF;
  --mint-bg: #E9F7F0;
  --mint-fg: #1E6B48;
  --butter-bg: #FDF7E1;
  --butter-fg: #8A6A00;
  --rose-bg: #FCECEF;
  --rose-fg: #A3243B;
  --focus: 0 0 0 3px rgba(10,10,10,.12);
  --backdrop-bg: rgba(0, 0, 0, 0.40);
}

[data-theme="dark"] {
  --bg: #0A0A0A;
  --surface: #111113;
  --surface-2: #18181B;
  --border: #232326;
  --text: #FAFAFA;
  --muted: #A1A1AA;
  --faint: #6B6B70;
  --primary: #FAFAFA;
  --on-primary: #0A0A0A;
  --mint-bg: rgba(52,211,153,.12);
  --mint-fg: #6EE7B7;
  --butter-bg: rgba(250,204,21,.12);
  --butter-fg: #FDE68A;
  --rose-bg: rgba(251,113,133,.12);
  --rose-fg: #FDA4AF;
  --focus: 0 0 0 3px rgba(250,250,250,.16);
  --backdrop-bg: rgba(0, 0, 0, 0.60);
}

.modal-backdrop {
  position: absolute;
  inset: 0;
  background-color: var(--backdrop-bg, rgba(0, 0, 0, 0.40));
  backdrop-filter: blur(2px);
  -webkit-backdrop-filter: blur(2px);
  animation: backdrop-fade 160ms ease forwards;
}

@keyframes backdrop-fade {
  from { opacity: 0; }
  to { opacity: 1; }
}

.modal-card {
  position: relative;
  width: min(520px, calc(100vw - 32px));
  max-height: 85vh;
  border-radius: 16px;
  border: 1px solid var(--border);
  background-color: var(--surface);
  color: var(--text);
  box-shadow: 0 16px 40px rgba(0, 0, 0, 0.16);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  animation: modal-enter 160ms cubic-bezier(.2, .8, .2, 1) forwards;
}

@keyframes modal-enter {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@media (prefers-reduced-motion: reduce) {
  .modal-backdrop, .modal-card {
    animation: none !important;
  }
}

/* Header */
.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 52px;
  padding: 0 16px 0 20px;
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
  background-color: var(--surface);
}

.modal-header-left {
  display: flex;
  align-items: center;
  gap: 8px;
  white-space: nowrap;
}

.modal-brand-title {
  font-size: 15px;
  font-weight: 600;
  letter-spacing: -0.01em;
  color: var(--text);
}

.modal-close-btn {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  border: none;
  background: transparent;
  color: var(--muted);
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  transition: background-color 140ms ease, color 140ms ease;
}

.modal-close-btn:hover {
  background-color: var(--surface-2);
  color: var(--text);
}

.modal-close-btn:focus-visible {
  outline: 2px solid var(--primary);
  outline-offset: 1px;
}

/* Viewport & Carousel */
.carousel-viewport {
  position: relative;
  overflow: hidden;
  width: 100%;
  flex: 1;
}

.carousel-strip {
  display: flex;
  width: 400%;
  height: 100%;
  transition: transform 200ms cubic-bezier(.2, .8, .2, 1);
}

.carousel-slide {
  width: 25%;
  flex-shrink: 0;
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 12px;
  box-sizing: border-box;
  overflow-y: auto;
  max-height: 55vh;
}

.slide-heading {
  font-size: 18px;
  font-weight: 600;
  letter-spacing: -0.01em;
  color: var(--text);
  line-height: 1.3;
}

.slide-sub {
  font-size: 14px;
  line-height: 1.5;
  color: var(--muted);
}

.demo-stage {
  border: 1px solid var(--border);
  border-radius: 12px;
  background: var(--bg);
  padding: 16px;
  max-height: 50vh;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  justify-content: center;
  min-height: 180px;
}

.demo-skeleton {
  display: flex;
  flex-direction: column;
  gap: 8px;
  animation: skel-pulse 1.2s ease-in-out infinite alternate;
}

@keyframes skel-pulse {
  from { opacity: 0.45; }
  to { opacity: 0.85; }
}

.demo-skel-line {
  height: 12px;
  border-radius: 6px;
  background: var(--surface-2);
}

.demo-flow-preview {
  display: flex;
  flex-direction: column;
  gap: 8px;
  animation: preview-fade 160ms ease forwards;
}

@keyframes preview-fade {
  from { opacity: 0; transform: translateY(4px); }
  to { opacity: 1; transform: translateY(0); }
}

.demo-mini-node {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  border-radius: 8px;
  background: var(--surface);
  border: 1px solid var(--border);
  font-size: 12px;
  font-weight: 500;
  color: var(--text);
}

/* Slide 3: Feature Grid */
.features-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
  max-height: 50vh;
  overflow-y: auto;
}

.feature-mini-card {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px;
  border-radius: 12px;
  background: var(--bg);
  border: 1px solid var(--border);
}

.feature-icon-square {
  width: 28px;
  height: 28px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.feature-title {
  font-size: 13px;
  font-weight: 500;
  color: var(--text);
}

/* Slide 4: Setup */
.setup-action-card {
  border-radius: 12px;
  background: var(--bg);
  border: 1px solid var(--border);
  padding: 12px 14px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.setup-site-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.setup-site-name {
  font-size: 13.5px;
  font-weight: 600;
  color: var(--text);
}

.setup-action-btn {
  padding: 6px 14px;
  border-radius: 8px;
  border: 1px solid transparent;
  background: var(--primary);
  color: var(--on-primary);
  font-size: 12.5px;
  font-weight: 500;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  transition: opacity 140ms ease;
}

.setup-action-btn:hover {
  opacity: 0.9;
}

.setup-action-btn.is-success {
  background: var(--mint-bg);
  border-color: var(--mint-fg);
  color: var(--mint-fg);
}

.prompt-copy-btn {
  width: 100%;
  padding: 9px 12px;
  border-radius: 8px;
  border: 1px solid var(--border);
  background: var(--bg);
  color: var(--text);
  font-size: 12.5px;
  font-weight: 500;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  transition: background-color 140ms ease;
}

.prompt-copy-btn:hover {
  background: var(--surface-2);
}

/* Footer */
.modal-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 56px;
  padding: 0 20px;
  border-top: 1px solid var(--border);
  background: var(--surface);
  flex-shrink: 0;
}

.modal-footer-left {
  display: flex;
  align-items: center;
  gap: 12px;
}

.step-label {
  font-size: 12px;
  color: var(--muted);
  font-variant-numeric: tabular-nums;
}

.segments-track {
  display: flex;
  align-items: center;
  gap: 4px;
}

.carousel-dot,
.tour-segment {
  width: 16px;
  height: 4px;
  border-radius: 999px;
  background: var(--border);
  border: none;
  padding: 0;
  cursor: pointer;
  transition: background-color 140ms ease;
}

.carousel-dot.is-active,
.tour-segment.is-active {
  background: var(--primary);
}

.modal-footer-right {
  display: flex;
  align-items: center;
  gap: 8px;
}

.footer-btn {
  height: 32px;
  padding: 0 14px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: none;
  transition: background-color 140ms ease, color 140ms ease, opacity 140ms ease;
}

.footer-btn:focus-visible {
  outline: 2px solid var(--primary);
  outline-offset: 1px;
}

.back-btn {
  border: 1px solid var(--border);
  background: transparent;
  color: var(--text);
}

.back-btn.is-hidden {
  display: none !important;
}

.primary-btn {
  border: 1px solid transparent;
  background: var(--primary);
  color: var(--on-primary);
  font-weight: 600;
}

.primary-btn:hover {
  opacity: 0.92;
}

.modal-body-wrap {
  padding: 20px;
  display: flex;
  flex-direction: column;
  gap: 14px;
  max-height: 55vh;
  overflow-y: auto;
}

.version-chip {
  font-size: 11px;
  font-weight: 600;
  padding: 2px 7px;
  border-radius: 999px;
  background-color: var(--surface-2);
  color: var(--muted);
}

.whatsnew-list {
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 8px;
  font-size: 13.5px;
  line-height: 1.45;
}

.whatsnew-item {
  display: flex;
  align-items: flex-start;
  gap: 8px;
}

.whatsnew-check {
  color: var(--mint-fg);
  flex-shrink: 0;
  margin-top: 2px;
}

.bv-modal-mark-wrap {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  position: relative;
  flex-shrink: 0;
}

.bv-modal-mark-wrap img {
  width: 100%;
  height: 100%;
  object-fit: contain;
  display: block;
}

.bv-modal-mark-wrap .bv-mark-dark {
  display: none;
}
.bv-modal-mark-wrap .bv-mark-light {
  display: block;
}

@media (prefers-color-scheme: dark) {
  :host(:not([data-theme="light"])) .bv-modal-mark-wrap .bv-mark-dark,
  .modal-card:not([data-theme="light"]) .bv-modal-mark-wrap .bv-mark-dark {
    display: block;
  }
  :host(:not([data-theme="light"])) .bv-modal-mark-wrap .bv-mark-light,
  .modal-card:not([data-theme="light"]) .bv-modal-mark-wrap .bv-mark-light {
    display: none;
  }
}

[data-theme="dark"] .bv-modal-mark-wrap .bv-mark-dark,
.modal-card[data-theme="dark"] .bv-modal-mark-wrap .bv-mark-dark {
  display: block !important;
}
[data-theme="dark"] .bv-modal-mark-wrap .bv-mark-light,
.modal-card[data-theme="dark"] .bv-modal-mark-wrap .bv-mark-light {
  display: none !important;
}

[data-theme="light"] .bv-modal-mark-wrap .bv-mark-dark,
.modal-card[data-theme="light"] .bv-modal-mark-wrap .bv-mark-dark {
  display: none !important;
}
[data-theme="light"] .bv-modal-mark-wrap .bv-mark-light,
.modal-card[data-theme="light"] .bv-modal-mark-wrap .bv-mark-light {
  display: block !important;
}

.sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  padding: 0;
  margin: -1px;
  overflow: hidden;
  clip: rect(0, 0, 0, 0);
  border: 0;
}
`;function jn(e={}){ct();const t=e.theme||Oe(),i=u("div",{id:"betterview-tour-host",class:"iui-host","data-iui":"1"}),n=i.attachShadow({mode:"open"}),o=document.createElement("style");o.textContent=Oo,n.appendChild(o);const r=u("div",{class:"modal-backdrop"}),a=u("div",{class:"modal-card",role:"dialog","aria-modal":"true","aria-label":"BetterView AI Tour"});a.setAttribute("data-theme",t);let s=0;function l(){typeof chrome<"u"&&chrome.storage?.local&&chrome.storage.local.set({pendingTour:!1,tourSeen:!0})}function c(){l(),ct(),e.onComplete?.()}r.addEventListener("click",$=>{$.target===r&&c()});const d=u("div",{class:"modal-header"}),p=u("div",{class:"modal-header-left"},Zt(28,t),u("span",{class:"modal-brand-title"},"BetterView AI")),h=u("button",{class:"modal-close-btn",type:"button","aria-label":"Close",onClick:()=>c()},K("x",16));d.appendChild(p),d.appendChild(h),a.appendChild(d);const f=u("div",{class:"carousel-viewport"}),g=u("div",{class:"carousel-strip"}),b=u("div",{class:"carousel-slide slide-welcome"},u("h2",{class:"slide-heading"},"Welcome to BetterView AI"),u("p",{class:"slide-sub"},"Compact interactive visuals rendered directly inside Gemini, Grok, ChatGPT, and Claude."),u("div",{class:"demo-stage"},u("div",{style:"display: flex; flex-direction: column; gap: 10px; align-items: center; justify-content: center; text-align: center;"},Zt(48,t),u("span",{style:"font-size: 14px; font-weight: 500; color: var(--text);"},"Ready to supercharge your conversations")))),m=u("div",{class:"demo-stage"}),C=u("div",{class:"demo-skeleton"},u("div",{class:"demo-skel-line",style:"width: 40%;"}),u("div",{class:"demo-skel-line",style:"width: 85%; height: 50px; border-radius: 10px;"}),u("div",{class:"demo-skel-line",style:"width: 70%;"}));m.appendChild(C);let v=null;function w(){de(m),m.appendChild(C),v=window.setTimeout(()=>{de(m);const $=u("div",{class:"demo-flow-preview"},u("div",{class:"demo-mini-node"},K("desktop",15),u("span",{},"Client App")),u("div",{style:"padding-left: 20px; font-size: 11px; color: var(--muted);"},"\u2193 POST /shorten"),u("div",{class:"demo-mini-node",style:"border-color: var(--mint-fg); color: var(--mint-fg);"},K("server",15),u("span",{},"API Gateway")));m.appendChild($),v=window.setTimeout(()=>{de(m);const _=u("div",{class:"demo-flow-preview"},u("div",{style:"font-size: 12px; font-weight: 600;"},"Storage Estimates"),u("div",{style:"display: flex; justify-content: space-between; font-size: 12px; padding: 6px 0; border-bottom: 1px solid var(--border);"},u("span",{style:"color: var(--muted);"},"Writes/s"),u("span",{style:"font-weight: 500;"},"1,160 req/s")),u("div",{style:"display: flex; justify-content: space-between; font-size: 12px; padding: 6px 0;"},u("span",{style:"color: var(--muted);"},"5 Years"),u("span",{style:"font-weight: 500;"},"90 TB")));m.appendChild(_)},2200)},1200)}const x=u("div",{class:"carousel-slide slide-demo"},u("h3",{class:"slide-heading"},"See it in action"),u("p",{class:"slide-sub"},"Streams with smooth reveal animations directly in your conversation."),m),y=[{title:"Diagrams",type:"flow",bg:"var(--surface-2)",ink:"var(--text)"},{title:"Steps",type:"stepper",bg:"var(--surface-2)",ink:"var(--text)"},{title:"Tables",type:"table",bg:"var(--surface-2)",ink:"var(--text)"},{title:"Compare",type:"compare",bg:"var(--surface-2)",ink:"var(--text)"},{title:"Charts",type:"chart",bg:"var(--surface-2)",ink:"var(--text)"},{title:"Quizzes",type:"quiz",bg:"var(--surface-2)",ink:"var(--text)"}],k=u("div",{class:"features-grid"});y.forEach($=>{const _=u("div",{class:"feature-mini-card"},u("div",{class:"feature-icon-square",style:`background-color: ${$.bg}; color: ${$.ink};`},io($.type,16)),u("span",{class:"feature-title"},$.title));k.appendChild(_)});const A=u("div",{class:"carousel-slide slide-features"},u("h3",{class:"slide-heading"},"What you get"),u("p",{class:"slide-sub"},"12 interactive components styled automatically in light and dark mode."),k),S=["gemini","grok"].map($=>{const _=$==="grok"?"Grok":"Gemini",I=$==="grok"?Dr(22):Or(22),M=u("button",{class:"setup-action-btn",type:"button",onClick:async()=>{M.textContent="Setting up...";try{if($==="grok"){const q=await Hn();ce("grok",q)}else{if(window.location.pathname.replace(/\/+$/,"")!=="/saved-info"){const V=Date.now();chrome.storage.local.set({pendingSetup:{site:"gemini",ts:V}},()=>{window.location.assign("https://gemini.google.com/saved-info")});return}const q=await Vn();ce("gemini",q)}de(M),M.classList.add("is-success"),M.appendChild(K("check",14)),M.appendChild(document.createTextNode("You're all set \u2713"))}catch{M.textContent="Setup ready"}}},document.createTextNode("Enable on "+_));return u("div",{class:"setup-action-card"},u("div",{class:"setup-site-info"},I,u("span",{class:"setup-site-name"},_)),M)}),E=u("button",{class:"prompt-copy-btn",type:"button",onClick:async()=>{try{await navigator.clipboard.writeText("Teach me how OAuth 2.0 works, from the moment I click \u201cSign in with Google\u201d to the app receiving an access token. Explain each step in simple language, show the authorization code flow with a clear diagram, and explain where access tokens and refresh tokens fit in with a practical example."),de(E),E.appendChild(K("check",14)),E.appendChild(document.createTextNode("Copied \u2713")),setTimeout(()=>{de(E),E.appendChild(K("copy",14)),E.appendChild(document.createTextNode("Copy sample prompt"))},1500)}catch{}}},K("copy",14),document.createTextNode("Copy sample prompt")),z=u("div",{class:"carousel-slide slide-setup"},u("h3",{class:"slide-heading"},"Set up in one click"),u("p",{class:"slide-sub"},"Choose where you want to enable BetterView AI."),...S,E);g.appendChild(b),g.appendChild(x),g.appendChild(A),g.appendChild(z),f.appendChild(g),a.appendChild(f);const L=u("div",{class:"modal-footer"}),F=u("button",{class:"skip-btn sr-only",type:"button",onClick:()=>c()},"Skip");L.appendChild(F);const B=u("div",{class:"modal-footer-left"}),O=u("div",{class:"segments-track"}),D=[];for(let $=0;$<4;$++){const _=u("button",{class:`carousel-dot tour-segment${$===0?" is-active":""}`,type:"button","aria-label":`Go to slide ${$+1}`,onClick:()=>X($)});D.push(_),O.appendChild(_)}const P=u("span",{class:"step-label"},"Step 1 of 4");B.appendChild(O),B.appendChild(P);const R=u("div",{class:"modal-footer-right"}),Q=u("button",{class:"footer-btn back-btn is-hidden",type:"button",disabled:"true",onClick:()=>X(Fn(s))},"Back"),ee=u("button",{class:"footer-btn primary-btn next-btn",type:"button",onClick:()=>{s<3?X(In(s)):c()}},"Next");R.appendChild(Q),R.appendChild(ee),L.appendChild(B),L.appendChild(R),a.appendChild(L);function X($){s=Qd($),g.style.transform=`translateX(-${s*25}%)`,D.forEach((_,I)=>{_.classList.toggle("is-active",I<=s)}),P.textContent=`Step ${s+1} of 4`,s===0?(Q.classList.add("is-hidden"),Q.setAttribute("disabled","true")):(Q.classList.remove("is-hidden"),Q.removeAttribute("disabled")),s===3?ee.textContent="Done":ee.textContent="Next",s===1?w():v!==null&&(window.clearTimeout(v),v=null)}const j=$=>{if($.key==="Escape"){$.preventDefault(),c();return}if($.key==="ArrowLeft"){$.preventDefault(),X(Fn(s));return}if($.key==="ArrowRight"){$.preventDefault(),X(In(s));return}if($.key==="Tab"){const _=Array.from(a.querySelectorAll('button:not([disabled]):not(.sr-only):not(.is-hidden), [tabindex="0"]:not([disabled])'));if(_.length===0)return;const I=_[0],M=_[_.length-1];$.shiftKey&&document.activeElement===I?(M.focus(),$.preventDefault()):!$.shiftKey&&document.activeElement===M&&(I.focus(),$.preventDefault())}};return Ye=j,document.addEventListener("keydown",j,!0),n.appendChild(r),n.appendChild(a),document.body.appendChild(i),Ge=i,setTimeout(()=>{ee.focus()},50),()=>{v!==null&&window.clearTimeout(v),c()}}function Nn(e={}){ct();const t=e.theme||Oe(),i=u("div",{id:"betterview-whatsnew-host",class:"iui-host","data-iui":"1"}),n=i.attachShadow({mode:"open"}),o=document.createElement("style");o.textContent=Oo,n.appendChild(o);const r=u("div",{class:"modal-backdrop"}),a=u("div",{class:"modal-card",role:"dialog","aria-modal":"true","aria-label":"What's new in BetterView AI"});a.setAttribute("data-theme",t);function s(){typeof chrome<"u"&&chrome.storage?.local&&chrome.storage.local.set({pendingUpdateModal:!1,updateModalSeen:!0,hasUpdateDot:!1}),typeof chrome<"u"&&chrome.action?.setBadgeText&&chrome.action.setBadgeText({text:""}),ct(),e.onComplete?.()}r.addEventListener("click",v=>{v.target===r&&s()});const l=u("div",{class:"modal-header"}),c=u("div",{class:"modal-header-left"},Zt(28,t),u("span",{class:"modal-brand-title"},"BetterView AI")),d=u("button",{class:"modal-close-btn",type:"button","aria-label":"Close",onClick:()=>s()},K("x",16));l.appendChild(c),l.appendChild(d),a.appendChild(l);const p=u("div",{class:"modal-body-wrap"}),h=e.version||Bn[0]?.version||"v0.1.0",f=u("div",{style:"display: flex; align-items: center; justify-content: space-between; gap: 8px;"},u("h3",{class:"slide-heading"},"What's new in BetterView AI"),u("span",{class:"version-chip"},h));p.appendChild(f);const g=Bn[0];if(g){const v=u("ul",{class:"whatsnew-list"});for(const w of g.highlights)v.appendChild(u("li",{class:"whatsnew-item"},u("span",{class:"whatsnew-check"},K("check",14)),u("span",{},w)));p.appendChild(v)}a.appendChild(p);const b=u("div",{class:"modal-footer",style:"justify-content: flex-end;"}),m=u("button",{class:"footer-btn primary-btn",type:"button",onClick:()=>s()},"Done");b.appendChild(m),a.appendChild(b);const C=v=>{v.key==="Escape"&&(v.preventDefault(),s())};return Ye=C,document.addEventListener("keydown",C,!0),n.appendChild(r),n.appendChild(a),document.body.appendChild(i),Ge=i,setTimeout(()=>m.focus(),50),()=>s()}var qn=!1;async function On(){const e=Qo(window.location);if(!e)return;const t=e;let i=window.location.hash.includes("betterview-setup"),n,o=0;if(typeof chrome<"u"&&chrome.storage?.local)try{const p=(await new Promise(h=>{chrome.storage.local.get(["pendingSetup"],f=>h(f||{}))})).pendingSetup;p&&p.site===t.id&&typeof p.ts=="number"&&(Date.now()-p.ts<3e5?(i=!0,n=p.ts,o=typeof p.redirects=="number"?p.redirects:0):chrome.storage.local.remove("pendingSetup"))}catch{}if(i&&!qn&&(t.id==="gemini"||t.id==="grok")){qn=!0;const p=t.id==="gemini"?"gemini":"grok",h=()=>{typeof chrome<"u"&&chrome.storage?.local&&chrome.storage.local.remove("pendingSetup")};if(t.id==="gemini"&&!ar(window.location.pathname)&&o<1){const f={site:"gemini",ts:n??Date.now(),redirects:o+1};typeof chrome<"u"&&chrome.storage?.local?chrome.storage.local.set({pendingSetup:f},()=>{window.location.assign("https://gemini.google.com/saved-info")}):window.location.assign("https://gemini.google.com/saved-info");return}(p==="gemini"?Vn():Hn()).then(f=>{ce(p,f)}).catch(f=>{const g=f instanceof Error?f.message:String(f);ce(p,{status:"failed",error:g})}).finally(()=>{h()})}let r;try{r=await ti()}catch{return}let a=r.theme==="auto"?Oe():r.theme,s=null,l=null;function c(){r.renderEnabled?s||(s=Xd(t,()=>a)):s&&(s.stop(),s=null)}function d(){r.autoInject?l||(l=Zd(t,Wo)):l&&(l(),l=null)}c(),d(),typeof chrome<"u"&&chrome.storage?.local&&chrome.storage.local.get(["pendingTour","tourSeen","pendingUpdateModal","updateModalSeen"],p=>{Jd(p)&&(t.id==="gemini"||t.id==="grok")?jn({site:t.id,theme:a}):eu(p)&&Nn({theme:a})}),typeof chrome<"u"&&chrome.runtime?.onMessage&&chrome.runtime.onMessage.addListener((p,h,f)=>{if(p?.type==="OPEN_TOUR")return t.id==="gemini"||t.id==="grok"?(jn({site:t.id,theme:a}),f?.({ok:!0})):f?.({ok:!1}),!0;if(p?.type==="OPEN_WHATS_NEW")return Nn({theme:a}),f?.({ok:!0}),!0}),ur(p=>{r.theme==="auto"&&(a=p,s&&s.setTheme(p))}),Wn(p=>{r=p,a=r.theme==="auto"?Oe():r.theme,s&&s.setTheme(a),c(),d()}),console.log(`[IUI] active on ${t.id}`)}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",On):On();export{ni as t};
